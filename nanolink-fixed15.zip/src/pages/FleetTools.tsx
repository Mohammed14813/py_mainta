import { useEffect, useMemo, useRef, useState } from 'react';
import { Btn, Card, Field, inp } from '../components/ui';
import { MainView, parseMain } from '../services/airosView';
import { AUTH_LABEL, buildReport, checkUnit, CheckContext, FleetUnit, mergeUnits, readingFrom } from '../services/fleet';
import { buildCampaignReport, CampaignOutcome, runCampaign } from '../services/campaign';
import { describeUnit, findProfile, unconfirmedActions } from '../services/deviceActions';
import { DeviceProtocol, RealConnection } from '../services/real';
import { formatFingerprint } from '../services/pins';
import { buildBody, makeLearnedActions, learnWirelessForm, sanityProblem, WirelessForm } from '../services/wirelessForm';
import { discoverPaths, discoveryReport } from '../services/discovery';
import { buildRankingReport, rankUnits, sharedBest } from '../services/ranking';

const PENDING_KEY = 'nanolink.pendingRestore';
function readPending(): { mhz: number; at: string } | null {
  try { const raw = localStorage.getItem(PENDING_KEY); return raw ? JSON.parse(raw) : null; } catch { return null; }
}
function writePending(value: { mhz: number; at: string } | null) {
  try { if (value) localStorage.setItem(PENDING_KEY, JSON.stringify(value)); else localStorage.removeItem(PENDING_KEY); } catch { /* storage unavailable */ }
}
/** Last safety net before the text leaves the app: hide MAC addresses and private IPs if any slipped in. */
const scrub = (text: string) => text
  .replace(/\b(?:[0-9A-Fa-f]{2}[:-]){5}[0-9A-Fa-f]{2}\b/g, 'XX:XX:XX:XX:XX:XX')
  .replace(/\b(?:10|192\.168|172\.(?:1[6-9]|2\d|3[01]))\.\d{1,3}\.\d{1,3}(?:\.\d{1,3})?\b/g, 'x.x.x.x');
const isDfs = (mhz: number) => mhz >= 5250 && mhz <= 5725;
const pause = (ms: number) => new Promise<void>((resolve) => setTimeout(resolve, ms));

export default function FleetTools({ connection, main }: { connection: RealConnection; main: MainView }) {
  const [units, setUnits] = useState<FleetUnit[]>([]);
  const unitsRef = useRef<FleetUnit[]>([]);
  unitsRef.current = units;
  const connections = useRef(new Map<string, RealConnection>());
  const stopFlag = useRef(false);
  const [busy, setBusy] = useState<'' | 'check' | 'read' | 'campaign' | 'discover' | 'learn'>('');
  const [progress, setProgress] = useState('');
  const [trustNew, setTrustNew] = useState(false);
  // The units' own web service can differ from the main node's (e.g. main on HTTPS, units on HTTP port 80).
  const [unitProtocol, setUnitProtocol] = useState<DeviceProtocol>('http');
  const [unitPort, setUnitPort] = useState('80');
  const [sameUser, setSameUser] = useState('');
  const [samePass, setSamePass] = useState('');
  const [channelsText, setChannelsText] = useState('');
  const [understood, setUnderstood] = useState(false);
  const [outcome, setOutcome] = useState<CampaignOutcome | null>(null);
  const [windowMHz, setWindowMHz] = useState('100');
  const [stepMHz, setStepMHz] = useState('20');
  const [copied, setCopied] = useState(false);
  const [discovery, setDiscovery] = useState('');
  const [learned, setLearned] = useState<{ form: WirelessForm; problem: string | null } | null>(null);
  const [learnError, setLearnError] = useState('');
  const [useApply, setUseApply] = useState(false); // default: only «OK/Change», not Apply
  const [settleSec, setSettleSec] = useState('10');
  const [skipDfs, setSkipDfs] = useState(true);
  const [pending, setPending] = useState<{ mhz: number; at: string } | null>(() => readPending());
  const [fixMessage, setFixMessage] = useState('');
  const [pickChannel, setPickChannel] = useState('');

  // Keep the unit list in step with the main node's station list without losing typed credentials.
  useEffect(() => { setUnits((previous) => mergeUnits(previous, main.stations)); }, [main.stations]);

  const patch = (key: string, changes: Partial<FleetUnit>) => setUnits((previous) => previous.map((unit) => (unit.key === key ? { ...unit, ...changes } : unit)));
  const ctx = (): CheckContext => ({ protocol: unitProtocol, port: unitPort.trim(), trustNewCerts: trustNew });

  async function checkOne(unit: FleetUnit, approvedPin = '') {
    patch(unit.key, { auth: 'checking', message: 'جارٍ الفحص…', pendingCert: undefined });
    const result = await checkUnit(unit, ctx(), approvedPin);
    if (result.connection) connections.current.set(unit.key, result.connection); else connections.current.delete(unit.key);
    patch(unit.key, { auth: result.auth, message: result.message, pendingCert: result.pendingCert, reading: result.reading });
  }

  async function checkAll() {
    if (busy) return;
    setBusy('check');
    setProgress('');
    try {
      const targets = unitsRef.current.filter((unit) => unit.listed && !unit.excluded);
      for (let index = 0; index < targets.length; index += 1) {
        setProgress(`فحص ${index + 1} من ${targets.length}: ${targets[index].name}`);
        await checkOne(targets[index]);
        await pause(300); // one unit after the other, never in parallel
      }
    } finally { setBusy(''); setProgress(''); }
  }

  async function readAll() {
    if (busy) return;
    setBusy('read');
    try {
      const targets = unitsRef.current.filter((unit) => unit.auth === 'ok' && !unit.excluded && connections.current.has(unit.key));
      for (let index = 0; index < targets.length; index += 1) {
        const unit = targets[index];
        setProgress(`قراءة ${index + 1} من ${targets.length}: ${unit.name}`);
        try {
          const snapshot = await connections.current.get(unit.key)!.readStatus();
          patch(unit.key, { reading: readingFrom(snapshot), message: 'اليوزر والباسورد صحيحان.' });
        } catch (error) {
          patch(unit.key, { message: `تعذرت القراءة: ${error instanceof Error ? error.message : String(error)}` });
        }
      }
    } finally { setBusy(''); setProgress(''); }
  }

  const excludeInvalid = () => setUnits((previous) => previous.map((unit) => (unit.auth === 'ok' ? unit : { ...unit, excluded: true })));
  const includeAll = () => setUnits((previous) => previous.map((unit) => ({ ...unit, excluded: false })));
  const fillBlanks = () => setUnits((previous) => previous.map((unit) => ({ ...unit, username: unit.username || sameUser.trim(), password: unit.password || samePass })));

  const manualChannels = useMemo(() => {
    const list = channelsText.split(/[\s,،;]+/).map(Number).filter((value) => Number.isFinite(value) && value >= 2000 && value <= 7200);
    return [...new Set(list)];
  }, [channelsText]);
  // Automatic mode: a window around the current frequency. The device itself rejects channels its country/model does not allow.
  const autoChannels = useMemo(() => {
    const centre = main.frequencyMHz.value;
    const span = Number(windowMHz);
    const step = Number(stepMHz);
    if (centre === null || !(span > 0) || !(step >= 5)) return [] as number[];
    const list: number[] = [];
    if (learned) { // the device's own allowed options, inside the window
      [...learned.form.options.keys()].sort((a, b) => a - b).forEach((f) => { if (f !== centre && Math.abs(f - centre) <= span) list.push(f); });
      return list;
    }
    for (let f = centre - span; f <= centre + span; f += step) if (f !== centre && f >= 2000 && f <= 7200) list.push(f);
    return list;
  }, [main.frequencyMHz.value, windowMHz, stepMHz, learned]);
  const channels = (manualChannels.length ? manualChannels : autoChannels).filter((mhz) => !(skipDfs && isDfs(mhz)));
  const validUnits = units.filter((unit) => unit.auth === 'ok' && !unit.excluded && connections.current.has(unit.key));
  const combos = useMemo(() => {
    const seen = new Map<string, { text: string; supported: boolean; names: string[] }>();
    const add = (name: string, conn: RealConnection) => {
      const text = describeUnit(conn);
      const entry = seen.get(text) ?? { text, supported: findProfile(conn) !== null, names: [] };
      entry.names.push(name);
      seen.set(text, entry);
    };
    add('العلبة الرئيسية', connection);
    validUnits.forEach((unit) => add(unit.name, connections.current.get(unit.key)!));
    return [...seen.values()];
  }, [connection, validUnits.map((unit) => unit.key).join('|')]);
  const activeActions = useMemo(() => (learned && !learned.problem ? makeLearnedActions(useApply) : unconfirmedActions), [learned, useApply]);
  const canRun = activeActions.available && understood && channels.length > 0 && validUnits.length > 0 && !busy;

  async function learn() {
    if (busy) return;
    setBusy('learn'); setLearnError(''); setLearned(null);
    try {
      const form = await learnWirelessForm(connection);
      setLearned({ form, problem: await sanityProblem(connection, form) });
    } catch (error) { setLearnError(error instanceof Error ? error.message : String(error)); }
    finally { setBusy(''); }
  }

  async function gatherDiscovery() {
    const results = [];
    const targets: Array<[string, RealConnection]> = [['العلبة الرئيسية — ' + describeUnit(connection), connection]];
    const done = new Set([describeUnit(connection)]);
    for (const unit of validUnits) { // one representative per distinct type
      const conn = connections.current.get(unit.key)!;
      if (!done.has(describeUnit(conn))) { done.add(describeUnit(conn)); targets.push([`علبة فرعية — ${describeUnit(conn)}`, conn]); }
    }
    for (const [label, conn] of targets) {
      setProgress(`قراءة صفحات ${label}…`);
      try { results.push(await discoverPaths(conn, label)); }
      catch (error) { results.push({ label, indexStatus: 0, links: [], pages: [], forms: [], controls: [], scriptHints: [], notes: [error instanceof Error ? error.message : String(error)] }); }
    }
    return results;
  }

  async function discover() {
    if (busy) return;
    setBusy('discover'); setDiscovery('');
    try { setDiscovery(scrub(discoveryReport(await gatherDiscovery()))); }
    finally { setBusy(''); setProgress(''); }
  }

  /** One button: everything the app can learn about the network and the devices' web UI, read only, as one text to send. */
  async function extractAll() {
    if (busy) return;
    setBusy('discover'); setDiscovery('');
    const out: string[] = [`NanoLink — استخراج كامل (قراءة فقط) — ${new Date().toLocaleString('ar')}`, ''];
    try {
      out.push('## العلبة الرئيسية', describeUnit(connection),
        `التردد الحالي: ${main.frequencyMHz.value ?? '—'} MHz | عرض القناة: ${main.channelWidthMHz.value ?? '—'} MHz | عدد المحطات: ${main.stations.length}`,
        `الاتصال بالرئيسية: ${connection.protocol}:${connection.port} | الاتصال بالفرعية في التطبيق: ${unitProtocol}:${unitPort}`, '');
      out.push('## العلب الفرعية (دون IP أو MAC أو كلمات مرور)');
      unitsRef.current.forEach((unit, index) => out.push(`علبة ${index + 1}: ${unit.excluded ? 'مستبعدة' : AUTH_LABEL[unit.auth].text}${unit.auth !== 'ok' && unit.message ? ` — ${unit.message}` : ''}${unit.reading ? ` | ${unit.reading.model} | ${unit.reading.firmware} | ${unit.reading.frequencyMHz ?? '—'} MHz` : ''}`));
      out.push('', '## نموذج تغيير القناة (Wireless)');
      setProgress('التعرف على نموذج Wireless…');
      try {
        const form = await learnWirelessForm(connection);
        const problem = await sanityProblem(connection, form);
        setLearned({ form, problem });
        out.push(`الصفحة: ${form.page} | هدف الإرسال: ${form.action} | الترميز: ${form.enctype}`,
          `حقل التردد: ${form.freqField} | قيمته الحالية: ${form.currentMHz ?? '—'}`,
          `القنوات المتاحة في الجهاز: ${[...form.options.keys()].sort((x, y) => x - y).join(', ')}`,
          `عدد الحقول التي ستُرسل: ${form.pairs.length}`, `أسماء الحقول: ${form.pairs.map(([name]) => name).join(', ')}`,
          problem ? `فحص السلامة: فشل — ${problem}` : 'فحص السلامة: ناجح');
      } catch (error) { out.push(`فشل التعرف: ${error instanceof Error ? error.message : String(error)}`); }
      out.push('');
      out.push(discoveryReport(await gatherDiscovery()));
      setDiscovery(scrub(out.join('\n')));
    } catch (error) {
      out.push(`توقف الاستخراج: ${error instanceof Error ? error.message : String(error)}`);
      setDiscovery(scrub(out.join('\n')));
    } finally { setBusy(''); setProgress(''); }
  }

  /** Sets a channel (same «OK» path as the campaign) and waits until the real frequency matches. */
  async function setAndVerify(mhz: number): Promise<boolean> {
    await activeActions.setFrequency(connection, mhz);
    for (let waited = 0; waited <= 90_000; waited += 4_000) {
      try { if (parseMain((await connection.readStatus()).status).frequencyMHz.value === mhz) return true; } catch { /* still re-tuning */ }
      await pause(4_000);
    }
    return false;
  }
  async function restoreNow() {
    if (!pending || busy || !activeActions.available) { if (!activeActions.available) setFixMessage('اضغط «تعرّف تلقائيًا على تغيير القناة» أولًا ثم أعد المحاولة.'); return; }
    setBusy('learn'); setFixMessage('جارٍ إرجاع القناة الأصلية…');
    try {
      if (await setAndVerify(pending.mhz)) { writePending(null); setPending(null); setFixMessage('رجعت القناة الأصلية وتم التحقق منها.'); }
      else setFixMessage('لم يتأكد الرجوع. افتح العلبة الرئيسية يدويًا وأعد القناة.');
    } catch (error) { setFixMessage(error instanceof Error ? error.message : String(error)); }
    finally { setBusy(''); }
  }
  async function pinChannel() {
    const mhz = Number(pickChannel);
    if (!mhz || busy || !understood || !activeActions.available) return;
    setBusy('learn'); setFixMessage(`تثبيت ${mhz} MHz…`);
    try { setFixMessage((await setAndVerify(mhz)) ? `ثُبّتت القناة ${mhz} MHz وتم التحقق منها.` : `لم يتأكد تغيير القناة إلى ${mhz} MHz.`); }
    catch (error) { setFixMessage(error instanceof Error ? error.message : String(error)); }
    finally { setBusy(''); }
  }
  async function shareReport() {
    try { if (navigator.share) { await navigator.share({ title: 'تقرير NanoLink', text: report }); return; } } catch { /* cancelled */ }
    await copyReport();
  }

  async function startCampaign() {
    if (!canRun) return;
    stopFlag.current = false;
    setBusy('campaign');
    setOutcome(null);
    let wake: { release?: () => Promise<void> } | null = null;
    try { wake = (await (navigator as unknown as { wakeLock?: { request: (t: string) => Promise<{ release: () => Promise<void> }> } }).wakeLock?.request('screen')) ?? null; } catch { /* not supported */ }
    try {
      const result = await runCampaign({
        main: connection,
        units: validUnits.map((unit) => ({ key: unit.key, name: unit.name, connection: connections.current.get(unit.key)! })),
        channels, actions: activeActions, onProgress: setProgress, onUpdate: setOutcome,
        settleMs: Math.max(0, Number(settleSec) || 0) * 1000,
        onOriginal: (mhz) => { const value = { mhz, at: new Date().toISOString() }; writePending(value); setPending(value); },
        onSettledSafe: () => { writePending(null); setPending(null); },
        onChannelDone: (run) => setProgress(`اكتمل فحص ${run.frequencyMHz} MHz على كل العلب.`), shouldStop: () => stopFlag.current,
      });
      setOutcome(result);
    } finally { try { await wake?.release?.(); } catch { /* ignore */ } setBusy(''); setProgress(''); }
  }

  const report = useMemo(
    () => buildReport(units, { frequencyMHz: main.frequencyMHz.value, widthMHz: main.channelWidthMHz.value }) + (outcome ? `\n${buildCampaignReport(outcome)}\n${buildRankingReport(outcome)}` : ''),
    [units, main.frequencyMHz.value, main.channelWidthMHz.value, outcome],
  );
  async function copyReport() {
    try { await navigator.clipboard.writeText(report); setCopied(true); window.setTimeout(() => setCopied(false), 2000); }
    catch { /* the text stays selectable in the box below */ }
  }

  const checked = units.filter((unit) => unit.auth !== 'unset' || unit.excluded);

  return (
    <div className="space-y-4">
      {pending && <Card className="space-y-2 border-red-500/60">
        <h3 className="font-bold text-red-300">فحص سابق لم ينتهِ بأمان</h3>
        <p className="text-xs text-slate-300">القناة الأصلية كانت <b dir="ltr">{pending.mhz} MHz</b> (قبل الفحص). تأكد أنها رجعت الآن، أو أعدها بالزر.</p>
        <div className="flex flex-wrap gap-2"><Btn kind="red" onClick={restoreNow} disabled={!!busy}>إرجاع القناة الأصلية الآن</Btn><Btn kind="sec" onClick={() => { writePending(null); setPending(null); }}>تجاهل (رجعت يدويًا)</Btn></div>
        {!activeActions.available && <p className="text-xs text-amber-200">لإرجاعها من التطبيق اضغط أولًا «تعرّف تلقائيًا على تغيير القناة».</p>}
        {fixMessage && <p className="text-xs text-slate-200" dir="auto">{fixMessage}</p>}
      </Card>}
      <Card className="space-y-3">
        <h2 className="font-bold">الأدوات ← Speed Test: العلب وبيانات دخولها</h2>
        <p className="text-xs text-slate-400">تُؤخذ العلب وعناوين IP من قائمة المحطات المرتبطة بالعلبة الرئيسية. اليوزر والباسورد يبقيان في ذاكرة التطبيق فقط ويُمحيان عند قطع الاتصال، ولا يدخلان في التقرير.</p>
        <div className="grid grid-cols-2 gap-2">
          <Field label="يوزر مشترك (اختياري)"><input className={inp} dir="ltr" autoComplete="off" value={sameUser} onChange={(event) => setSameUser(event.target.value)} /></Field>
          <Field label="باسورد مشترك (اختياري)"><input className={inp} dir="ltr" type="password" autoComplete="off" value={samePass} onChange={(event) => setSamePass(event.target.value)} /></Field>
        </div>
        <div className="grid grid-cols-2 gap-2">
          <Field label="بروتوكول العلب الفرعية">
            <select className={inp} value={unitProtocol} onChange={(event) => { const value = event.target.value as DeviceProtocol; setUnitProtocol(value); setUnitPort(value === 'https' ? '443' : '80'); }}>
              <option value="http">HTTP</option>
              <option value="https">HTTPS</option>
            </select>
          </Field>
          <Field label="منفذ الويب (Remote WEB Port)"><input className={inp} dir="ltr" inputMode="numeric" value={unitPort} onChange={(event) => setUnitPort(event.target.value)} /></Field>
        </div>
        {unitProtocol === 'http' && <p className="rounded-lg bg-amber-500/10 p-2 text-xs text-amber-200">HTTP يرسل اليوزر والباسورد دون تشفير على الشبكة المحلية. مقبول إن كانت شبكة علبك خاصة.</p>}
        <div className="flex flex-wrap gap-2">
          <Btn kind="sec" onClick={fillBlanks} disabled={!sameUser.trim() && !samePass}>تعبئة الحقول الفارغة بهما</Btn>
        </div>
        {unitProtocol === 'https' && <label className="flex items-start gap-2 text-xs text-slate-300">
          <input type="checkbox" className="mt-0.5" checked={trustNew} onChange={(event) => setTrustNew(event.target.checked)} />
          <span>اعتماد شهادة أي علبة جديدة تلقائيًا عند أول اتصال (ثقة أول استخدام). إن تُرك فارغًا تظهر لكل علبة جديدة بصمتها لتوافق عليها. الشهادة المتغيّرة عن المعتمدة سابقًا لا تُعتمد تلقائيًا أبدًا.</span>
        </label>}
      </Card>

      {units.length === 0 && <Card><p className="text-sm text-slate-300">لا توجد علب مرتبطة ظاهرة في قائمة المحطات الآن. ارجع إلى «العلبة الرئيسية» وأعد الفحص الآمن.</p></Card>}

      {units.map((unit) => {
        const label = AUTH_LABEL[unit.auth];
        return (
          <Card key={unit.key} className={`space-y-2 ${unit.excluded ? 'opacity-50' : ''}`}>
            <div className="flex flex-wrap items-start justify-between gap-2">
              <div className="min-w-0">
                <div className="font-semibold">{unit.name}{!unit.listed && <span className="mr-2 text-xs text-amber-300">(لم تعد في القائمة)</span>}</div>
                <div className="text-xs text-slate-400" dir="ltr">{unit.ip || 'IP غير متاح'} · {unit.mac || 'MAC غير متاح'}</div>
              </div>
              <span className={`rounded px-2 py-0.5 text-xs ${label.cls}`}>{unit.excluded ? 'مستبعدة' : label.text}</span>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <input className={inp} dir="ltr" placeholder="اليوزر" autoComplete="off" disabled={unit.excluded} value={unit.username} onChange={(event) => patch(unit.key, { username: event.target.value, auth: unit.auth === 'unset' ? 'unset' : 'unset', message: '' })} />
              <input className={inp} dir="ltr" type="password" placeholder="الباسورد" autoComplete="off" disabled={unit.excluded} value={unit.password} onChange={(event) => patch(unit.key, { password: event.target.value, auth: 'unset', message: '' })} />
            </div>
            {unit.message && unit.auth !== 'ok' && <p className="text-xs text-slate-300" dir="auto">{unit.message}</p>}
            {unit.auth === 'needs-cert' && unit.pendingCert && (
              <div className="space-y-2 rounded-lg bg-amber-500/10 p-2 text-xs text-amber-100">
                <div>بصمة SHA-256 للشهادة الحالية:</div>
                <div dir="ltr" className="break-all font-mono">{formatFingerprint(unit.pendingCert.sha256)}</div>
                <Btn kind={unit.pendingCert.changed ? 'red' : 'pri'} disabled={!!busy} onClick={() => { void checkOne(unit, unit.pendingCert!.sha256); }}>{unit.pendingCert.changed ? 'أثق بالشهادة الجديدة وأجرّب' : 'أثق بهذه الشهادة وأجرّب'}</Btn>
              </div>
            )}
            <label className="flex items-center gap-2 text-xs text-slate-400"><input type="checkbox" checked={unit.excluded} onChange={(event) => patch(unit.key, { excluded: event.target.checked })} />استبعاد هذه العلبة</label>
          </Card>
        );
      })}

      <Card className="space-y-3">
        <div className="flex flex-wrap gap-2">
          <Btn onClick={checkAll} disabled={!!busy || units.length === 0}>{busy === 'check' ? 'جارٍ فحص الباسوردات…' : 'فحص الباسوردات'}</Btn>
          <Btn kind="sec" onClick={excludeInvalid} disabled={!!busy || units.length === 0}>استبعاد غير الصحيحة والفارغة</Btn>
          <Btn kind="sec" onClick={includeAll} disabled={!!busy || units.length === 0}>إرجاع الكل</Btn>
        </div>
        <p className="text-xs text-slate-400">الفحص يجرّب علبة واحدة بعد الأخرى وبمحاولة واحدة لكل علبة (حتى لا يُحظر الحساب مؤقتًا بعد محاولات خاطئة متكررة). العلب بلا يوزر/باسورد لا تُجرَّب.</p>
        {progress && <p className="text-sm text-blue-300">{progress}</p>}
      </Card>

      {checked.length > 0 && (
        <Card className="space-y-2">
          <h3 className="font-bold">نتيجة فحص الباسوردات</h3>
          {checked.map((unit) => (
            <div key={unit.key} className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-700 pb-2 text-sm last:border-0">
              <div className="min-w-0"><div>{unit.name}</div><div className="text-xs text-slate-400" dir="ltr">{unit.ip || '—'} · {unit.mac || '—'}</div></div>
              <div className="flex flex-wrap items-center gap-2 text-xs"><span dir="ltr" className="text-slate-400">{unit.username || '—'}</span><span className={`rounded px-2 py-0.5 ${unit.excluded ? 'bg-slate-600/40 text-slate-300' : AUTH_LABEL[unit.auth].cls}`}>{unit.excluded ? 'مستبعدة' : AUTH_LABEL[unit.auth].text}</span></div>
            </div>
          ))}
        </Card>
      )}

      <Card className="space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <h3 className="font-bold">قراءة العلب الصحيحة (القناة الحالية)</h3>
          <Btn onClick={readAll} disabled={!!busy || validUnits.length === 0}>{busy === 'read' ? 'جارٍ القراءة…' : `قراءة ${validUnits.length} علبة`}</Btn>
        </div>
        {validUnits.map((unit) => unit.reading && (
          <div key={unit.key} className="space-y-1 rounded-lg bg-slate-900 p-3 text-sm">
            <div className="font-semibold">{unit.name}</div>
            <div className="text-xs text-slate-400" dir="ltr">{unit.reading.model} · {unit.reading.firmware} · {unit.reading.frequencyMHz ?? '—'} MHz</div>
            <div className="grid grid-cols-2 gap-x-3 gap-y-1 text-xs">
              {unit.reading.fields.map((field) => <div key={field.label} className="flex justify-between gap-2"><span className="text-slate-400">{field.label}</span><b dir="ltr" className="break-all">{field.value}</b></div>)}
            </div>
          </div>
        ))}
      </Card>

      <Card className="space-y-3 border-amber-500/40">
        <h3 className="font-bold">الفحص عبر قنوات MHz أخرى (تغيير مؤقت + Speed Test)</h3>
        {!activeActions.available && <div className="rounded-lg bg-amber-500/10 p-3 text-xs text-amber-100" dir="auto">اضغط «تعرّف تلقائيًا على تغيير القناة» أولًا. إن فشل التعرف فالسبب موضّح هناك. Speed Test نفسه غير مفعّل؛ الترتيب حسب جودة الرابط.</div>}
        <div className="space-y-1 rounded-lg bg-slate-900 p-3 text-xs">
          <div className="font-semibold">الأنواع الموجودة في شبكتك (كل نوع مختلف يحتاج سجل HAR واحد)</div>
          {combos.map((combo) => <div key={combo.text} className="flex flex-wrap items-center justify-between gap-2"><span dir="ltr" className="text-slate-300">{combo.text} <span className="text-slate-500">×{combo.names.length}</span></span><span className={`rounded px-2 py-0.5 ${combo.supported ? 'bg-emerald-500/20 text-emerald-300' : 'bg-amber-500/20 text-amber-300'}`}>{combo.supported ? 'مدعوم' : 'غير مدعوم بعد'}</span></div>)}
        </div>
        <p className="text-xs text-slate-400">الخطوات المبرمجة: حفظ القناة الأصلية ← تغيير مؤقت لكل قناة ← انتظار عودة كل العلب (مهلة تراجع) ← قراءة وSpeed Test لكل علبة صحيحة ← إرجاع القناة الأصلية والتحقق منها دائمًا، حتى عند الفشل أو الإيقاف.</p>
        <div className="space-y-2 rounded-lg bg-slate-900 p-3 text-xs text-slate-300">
          <label className="flex items-start gap-2"><input type="checkbox" className="mt-0.5" checked={useApply} onChange={(event) => setUseApply(event.target.checked)} /><span>استخدم Apply أيضًا بعد «موافق». اتركه مطفأً: يضغط «موافق» فقط. فعّله فقط إن ظهر أن التردد لا يتغيّر بـ«موافق» وحدها على جهازك.</span></label>
          <label className="flex items-start gap-2"><input type="checkbox" className="mt-0.5" checked={skipDfs} onChange={(event) => setSkipDfs(event.target.checked)} /><span>تخطّي قنوات DFS (5250–5725 MHz): تحتاج فحص رادار وقد تتأخر العودة أو تُترك فجأة.</span></label>
          <Field label="انتظار استقرار الرابط بعد كل قناة (ثوانٍ)"><input className={inp} dir="ltr" inputMode="numeric" value={settleSec} onChange={(event) => setSettleSec(event.target.value)} /></Field>
        </div>
        <div className="grid grid-cols-2 gap-2">
          <Field label="تلقائي: نافذة ± MHz حول القناة الحالية"><input className={inp} dir="ltr" inputMode="numeric" value={windowMHz} onChange={(event) => setWindowMHz(event.target.value)} /></Field>
          <Field label="تلقائي: الخطوة MHz"><input className={inp} dir="ltr" inputMode="numeric" value={stepMHz} onChange={(event) => setStepMHz(event.target.value)} /></Field>
        </div>
        <p className="text-xs text-slate-400" dir="ltr">{manualChannels.length ? 'يدوي' : 'تلقائي'}: {channels.length ? channels.join(', ') : '—'} MHz</p>
        <div className="space-y-2 rounded-lg bg-emerald-500/10 p-3">
          <Btn onClick={extractAll} disabled={!!busy}>{busy === 'discover' ? 'جارٍ الاستخراج…' : 'استخراج كل شيء (قراءة فقط)'}</Btn>
          <ol className="list-decimal space-y-1 pr-5 text-xs text-slate-300">
            <li>أدخل بيانات العلب واضغط «فحص الباسوردات» أولًا (ليشمل الاستخراج أنواعها).</li>
            <li>اضغط «استخراج كل شيء» وانتظر حتى ينتهي (دقيقة تقريبًا).</li>
            <li>اضغط «نسخ نتيجة الاكتشاف» أو «مشاركة»، والصقها في المحادثة معي.</li>
          </ol>
          <p className="text-xs text-slate-400">لا يكتب شيئًا على الجهاز ولا يشغّل أي اختبار، ولا يضع كلمات المرور أو MAC أو IP في النتيجة.</p>
        </div>
        <div className="space-y-2 rounded-lg bg-slate-900 p-3">
          <Btn kind="sec" onClick={learn} disabled={!!busy}>{busy === 'learn' ? 'جارٍ التعرف…' : 'تعرّف تلقائيًا على تغيير القناة (قراءة فقط)'}</Btn>
          <p className="text-xs text-slate-400">يقرأ نموذج Wireless من الجهاز نفسه ويتحقق أن قيمه كاملة (التردد في النموذج = التردد الحقيقي). لا يرسل شيئًا في هذه الخطوة. بعد نجاحه يُفعَّل الزر أدناه، وتأتي قنوات الفحص التلقائي من خيارات الجهاز نفسه، والترتيب حسب جودة الرابط.</p>
          {learnError && <p className="text-xs text-red-300" dir="auto">{learnError}</p>}
          {learned && <div className={`rounded-lg p-2 text-xs ${learned.problem ? 'bg-red-500/10 text-red-200' : 'bg-emerald-500/10 text-emerald-200'}`} dir="auto">
            {learned.problem ?? `تم التعرف: النموذج في ${learned.form.page} ← ${learned.form.action}، حقل التردد ${learned.form.freqField}، ${learned.form.pairs.length} حقلًا سيُعاد إرسالها كما هي مع تغيير التردد فقط. القنوات المتاحة في الجهاز: ${learned.form.options.size}.`}
            {!learned.problem && (() => { const t = [...learned.form.options.keys()].find((f) => f !== learned.form.currentMHz); if (t === undefined) return null; try { const b = buildBody(learned.form, t); return <div className="mt-1" dir="ltr">معاينة: {learned.form.freqField}: {b.from} → {b.to}</div>; } catch { return null; } })()}
          </div>}
          <Btn kind="sec" onClick={discover} disabled={!!busy}>{busy === 'discover' ? 'جارٍ الاكتشاف…' : 'اكتشاف مسارات الجهاز تلقائيًا (قراءة فقط)'}</Btn>
          <p className="text-xs text-slate-400">يقرأ صفحات واجهة كل نوع (Wireless وTools) ويستخرج منها عناوين النماذج وأسماء الحقول بنفسه، دون أي كتابة على الجهاز. انسخ النتيجة وأرسلها لي بدل سجل HAR إن كان الجهاز airOS 5/6.</p>
          {discovery && <><textarea readOnly dir="ltr" value={discovery} className="h-56 w-full rounded-lg bg-slate-950 p-3 font-mono text-xs text-slate-300" /><div className="flex gap-2"><Btn kind="sec" onClick={() => { void navigator.clipboard.writeText(discovery); }}>نسخ نتيجة الاكتشاف</Btn><Btn kind="sec" onClick={async () => { try { if (navigator.share) await navigator.share({ title: 'استخراج NanoLink', text: discovery }); else await navigator.clipboard.writeText(discovery); } catch { /* cancelled */ } }}>مشاركة</Btn></div></>}
        </div>
        <Field label="أو حدّد القنوات يدويًا (يلغي التلقائي)"><input className={inp} dir="ltr" placeholder="5640, 5660, 5680" value={channelsText} onChange={(event) => setChannelsText(event.target.value)} /></Field>
        <label className="flex items-start gap-2 text-xs text-slate-300"><input type="checkbox" className="mt-0.5" checked={understood} onChange={(event) => setUnderstood(event.target.checked)} /><span>أفهم أن تغيير قناة العلبة الرئيسية قد يقطع العلب الفرعية مؤقتًا.</span></label>
        <div className="flex flex-wrap gap-2">
          <Btn kind="red" onClick={startCampaign} disabled={!canRun}>{busy === 'campaign' ? 'جارٍ الفحص…' : 'ابدأ الفحص عبر القنوات'}</Btn>
          {busy === 'campaign' && <Btn kind="sec" onClick={() => { stopFlag.current = true; }}>إيقاف وإرجاع القناة</Btn>}
        </div>
        {outcome && busy !== 'campaign' && <div className="rounded-lg bg-slate-900 p-3 text-xs text-slate-200" dir="auto">{outcome.aborted ?? 'اكتمل الفحص.'}{!outcome.untouched && ` — القناة الأصلية: ${outcome.restored ? 'رجعت وتم التحقق منها' : 'لم يتأكد الرجوع! أعدها فورًا'}.`}{!useApply && outcome.runs[0] && !outcome.runs[0].recovered && ' لم يظهر التردد الجديد بعد «موافق»؛ ربما يلزم Apply على جهازك: فعّل خيار Apply أعلاه وأعد المحاولة.'}</div>}
        {outcome && busy !== 'campaign' && outcome.runs.some((run) => run.recovered) && (
          <div className="space-y-2 rounded-lg bg-slate-900 p-3 text-xs">
            <div className="font-semibold">تثبيت قناة بعد الفحص (اختياري)</div>
            <select className={inp} value={pickChannel} onChange={(event) => setPickChannel(event.target.value)}>
              <option value="">اختر قناة…</option>
              {outcome.runs.filter((run) => run.recovered).map((run) => <option key={run.frequencyMHz} value={run.frequencyMHz}>{run.frequencyMHz} MHz</option>)}
            </select>
            <Btn kind="red" onClick={pinChannel} disabled={!pickChannel || !!busy || !understood}>تثبيت هذه القناة بدل الأصلية</Btn>
            {fixMessage && <p className="text-slate-200" dir="auto">{fixMessage}</p>}
          </div>
        )}
        {outcome && <RankingView outcome={outcome} />}
      </Card>

      <Card className="space-y-2">
        <div className="flex flex-wrap items-center justify-between gap-2"><h3 className="font-bold">التقرير</h3><div className="flex gap-2"><Btn kind="sec" onClick={shareReport}>مشاركة</Btn><Btn kind="sec" onClick={copyReport}>{copied ? 'تم النسخ' : 'نسخ التقرير'}</Btn></div></div>
        <textarea readOnly dir="auto" value={report} className="h-72 w-full rounded-lg bg-slate-950 p-3 font-mono text-xs text-slate-300" />
      </Card>
    </div>
  );
}

function RankingView({ outcome }: { outcome: CampaignOutcome }) {
  const rankings = rankUnits(outcome);
  const best = sharedBest(rankings);
  if (!rankings.length) return null;
  return (
    <div className="space-y-2">
      <h4 className="text-sm font-bold">أقوى القنوات لكل علبة (يتحدث بعد كل فحص)</h4>
      {rankings.map((unit) => (
        <div key={unit.unitKey} className="rounded-lg bg-slate-900 p-3 text-xs">
          <div className="mb-1 font-semibold text-sm">{unit.unitName} <span className="text-slate-500">({unit.ranked[0].basis === 'speed' ? 'حسب Speed Test' : 'حسب جودة الرابط'})</span></div>
          {unit.ranked.slice(0, 3).map((r, i) => <div key={r.frequencyMHz} className="flex justify-between" dir="ltr"><span>{i + 1}. {r.frequencyMHz} MHz</span><b>{r.score}</b></div>)}
        </div>
      ))}
      {best && <div className="rounded-lg bg-emerald-500/10 p-3 text-sm text-emerald-200">أفضل قناة مشتركة: <b dir="ltr">{best.frequencyMHz} MHz</b> (أسوأ ترتيب عند أي علبة: {best.worstRank})</div>}
    </div>
  );
}
