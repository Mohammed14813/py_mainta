import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.nanolink.channelanalyzer',
  appName: 'NanoLink Channel Analyzer',
  webDir: 'dist',
  bundledWebRuntime: false,
  plugins: {
    CapacitorHttp: {
      enabled: true
    }
  },
  android: {
    backgroundColor: '#020617'
  }
};

export default config;
