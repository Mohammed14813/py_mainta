package com.nanolink.channelanalyzer;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import java.net.URL;
import java.security.cert.X509Certificate;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;

/** Thin Capacitor bridge. All networking and TLS logic lives in {@link AirOsHttpCore}. */
@CapacitorPlugin(name = "AirOsHttp")
public class AirOsHttpPlugin extends Plugin {

    @PluginMethod
    public void probeCertificate(PluginCall call) {
        try {
            URL url = new URL(call.getString("url", ""));
            AirOsHttpCore.requirePrivateLanHttps(url);
            int port = url.getPort() == -1 ? 443 : url.getPort();
            // TLS handshake only; no HTTP request is made and no credentials are involved.
            X509Certificate leaf = AirOsHttpCore.fetchLeafCertificate(url.getHost(), port);
            JSObject result = new JSObject();
            result.put("sha256", AirOsHttpCore.sha256Fingerprint(leaf));
            result.put("subject", leaf.getSubjectX500Principal().getName());
            result.put("issuer", leaf.getIssuerX500Principal().getName());
            result.put("validUntil", leaf.getNotAfter().toString());
            call.resolve(result);
        } catch (Exception error) {
            call.reject(AirOsHttpCore.safeMessage(error), error);
        }
    }

    @PluginMethod
    public void request(PluginCall call) {
        try {
            Map<String, String> headers = new LinkedHashMap<>();
            JSObject requested = call.getObject("headers", new JSObject());
            Iterator<String> keys = requested.keys();
            while (keys.hasNext()) {
                String key = keys.next();
                headers.put(key, requested.optString(key, ""));
            }
            AirOsHttpCore.Response response = AirOsHttpCore.execute(
                call.getString("url", ""),
                call.getString("method", "GET"),
                headers,
                call.getString("data", null),
                call.getString("tlsPin", "")
            );
            JSObject responseHeaders = new JSObject();
            for (Map.Entry<String, String> header : response.headers.entrySet()) responseHeaders.put(header.getKey(), header.getValue());
            JSArray setCookies = new JSArray();
            for (String cookie : response.setCookies) setCookies.put(cookie);
            JSObject result = new JSObject();
            result.put("status", response.status);
            result.put("headers", responseHeaders);
            result.put("setCookies", setCookies);
            result.put("data", response.body);
            call.resolve(result);
        } catch (Exception error) {
            call.reject(AirOsHttpCore.safeMessage(error), error);
        }
    }
}
