# بناء APK لتطبيق NanoLink

المشروع يستخدم Capacitor لتغليف لوحة NanoLink داخل تطبيق Android.

## المعماريات المدعومة

يولد GitHub Actions ملفات Debug للمعماريات التالية:

- `armeabi-v7a`
- `arm64-v8a`
- `x86`
- `x86_64`
- Universal APK يحتوي المعماريات الأربع

## البناء عبر GitHub

1. ادفع المشروع إلى فرع `main`.
2. افتح تبويب **Actions** في GitHub.
3. اختر **Build Android APK**.
4. اضغط **Run workflow** عند الحاجة.
5. بعد انتهاء البناء، نزّل Artifact باسم `nanolink-apks`.

هذه النسخة تعمل بوضع المحاكاة ولا تتصل بأجهزة NanoStation الحقيقية. تكامل الأجهزة يحتاج خادم API داخل الشبكة ومعلومات الموديلات وإصدارات airOS.
