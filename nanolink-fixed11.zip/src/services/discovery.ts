// Read-only discovery of the device's OWN web UI: which pages exist and which forms (target URL + field names)
// the Wireless / Tools pages use. Nothing is written. Values are never copied except an allow-list of
// radio-setting names, and anything that looks like a secret or identity is dropped.
import type { RealConnection } from './real';

export interface FormInfo { page: string; action: string; method: string; fields: Array<{ name: string; type: string; value?: string }>; selects: Array<{ name: string; options: string[] }>; }
export interface DiscoveryResult { label: string; indexStatus: number; links: string[]; pages: Array<{ path: string; status: number }>; forms: FormInfo[]; notes: string[]; }

const INTEREST = /wireless|wlan|wifi|speed|ping|tool|ptest|airview|link|channel|radio|config/i;
/** Pages that CHANGE the device when merely opened (apply.cgi commits pending config). Never fetched. */
export const NEVER_OPEN = /apply|discard|reboot|reset|restart|upgrade|firmware|fwupdate|logout|kick|default|cfg|backup|delete|remove|signal-?test|ping.?test.*action/i;
const SECRET_NAME = /pass|pwd|key|psk|wpa|secret|token|user|login|serial|mac|ssid|essid|name/i;
const SAFE_VALUE_NAME = /freq|chan|width|bw|country|mode|ieee|dfs/i;
const PATH = /^\/?[A-Za-z0-9_\-./]+\.(?:cgi|php|html?|asp)(?:\?[A-Za-z0-9_=&.\-]*)?$/i;

const normalise = (href: string): string | null => {
  const clean = href.trim().replace(/^https?:\/\/[^/]+/i, '').replace(/^\.\//, '');
  if (!clean || clean.startsWith('#') || /^(javascript|mailto):/i.test(clean) || !PATH.test(clean)) return null;
  return clean.startsWith('/') ? clean : `/${clean}`;
};

function collectLinks(html: string, doc: Document): string[] {
  const found = new Set<string>();
  doc.querySelectorAll('a[href],iframe[src],frame[src]').forEach((element) => {
    const path = normalise(element.getAttribute('href') ?? element.getAttribute('src') ?? '');
    if (path) found.add(path);
  });
  for (const match of html.matchAll(/["']([A-Za-z0-9_\-./]+\.cgi(?:\?[A-Za-z0-9_=&.\-]*)?)["']/g)) { const path = normalise(match[1]); if (path) found.add(path); }
  return [...found];
}

function collectForms(page: string, doc: Document): FormInfo[] {
  return [...doc.querySelectorAll('form')].map((form) => ({
    page, action: form.getAttribute('action') || page, method: (form.getAttribute('method') || 'GET').toUpperCase(),
    fields: [...form.querySelectorAll('input,textarea')].filter((el) => el.getAttribute('name')).map((el) => {
      const name = el.getAttribute('name') as string;
      const type = (el.getAttribute('type') || 'text').toLowerCase();
      const showValue = type !== 'password' && !SECRET_NAME.test(name.replace(SAFE_VALUE_NAME, '')) && SAFE_VALUE_NAME.test(name);
      return { name, type, value: showValue ? el.getAttribute('value') ?? undefined : undefined };
    }),
    selects: [...form.querySelectorAll('select')].filter((el) => el.getAttribute('name')).map((el) => ({
      name: el.getAttribute('name') as string,
      options: SAFE_VALUE_NAME.test(el.getAttribute('name') as string) ? [...el.querySelectorAll('option')].map((o) => o.getAttribute('value') ?? '').slice(0, 60) : [],
    })),
  }));
}

export async function discoverPaths(connection: RealConnection, label: string): Promise<DiscoveryResult> {
  const result: DiscoveryResult = { label, indexStatus: 0, links: [], pages: [], forms: [], notes: [] };
  const parser = new DOMParser();
  const index = await connection.getPage('/index.cgi');
  result.indexStatus = index.status;
  const indexDoc = parser.parseFromString(index.text, 'text/html');
  result.links = collectLinks(index.text, indexDoc).slice(0, 80);
  result.forms.push(...collectForms('/index.cgi', indexDoc));
  if (!result.links.length) result.notes.push(connection.flavor === 'v8'
    ? 'واجهة airOS 8 تُبنى بجافاسكربت ولا تكشف صفحاتها ونماذجها في HTML؛ يلزم سجل HAR لهذا النوع.'
    : 'لم تظهر روابط صفحات في index.cgi.');
  for (const path of result.links.filter((link) => INTEREST.test(link) && !NEVER_OPEN.test(link)).slice(0, 10)) {
    try {
      const page = await connection.getPage(path);
      result.pages.push({ path, status: page.status });
      if (page.status === 200) result.forms.push(...collectForms(path, parser.parseFromString(page.text, 'text/html')));
    } catch (error) { result.notes.push(`تعذرت قراءة ${path}: ${error instanceof Error ? error.message : String(error)}`); }
  }
  return result;
}

export function discoveryReport(results: DiscoveryResult[]): string {
  const lines: string[] = ['— اكتشاف مسارات واجهة الجهاز (قراءة فقط، دون أسرار) —'];
  for (const r of results) {
    lines.push('', `## ${r.label}`, `index.cgi: HTTP ${r.indexStatus}`, `الروابط: ${r.links.join(' ، ') || '—'}`);
    r.pages.forEach((p) => lines.push(`صفحة ${p.path}: HTTP ${p.status}`));
    r.forms.forEach((f) => {
      lines.push(`نموذج في ${f.page} → ${f.method} ${f.action}`);
      lines.push(`  حقول: ${f.fields.map((x) => `${x.name}[${x.type}]${x.value !== undefined ? `=${x.value}` : ''}`).join(' , ') || '—'}`);
      f.selects.filter((x) => x.options.length).forEach((x) => lines.push(`  قائمة ${x.name}: ${x.options.join(' , ')}`));
    });
    r.notes.forEach((n) => lines.push(`ملاحظة: ${n}`));
  }
  return lines.join('\n');
}
