// Remembers the certificate fingerprint the user approved for each device (trust on first use).
// A fingerprint is public information (not a secret), so plain localStorage is enough here.
const STORAGE_KEY = 'nanolink.tlsPins.v1';
type PinMap = Record<string, string>;

function load(): PinMap {
  try {
    const parsed: unknown = JSON.parse(window.localStorage.getItem(STORAGE_KEY) ?? '{}');
    return parsed && typeof parsed === 'object' && !Array.isArray(parsed) ? parsed as PinMap : {};
  } catch { return {}; }
}
const keyFor = (ip: string, port: string | number) => `${ip.trim()}:${Number(port)}`;

export function getPin(ip: string, port: string | number): string {
  const value = load()[keyFor(ip, port)];
  return typeof value === 'string' && /^[A-Fa-f0-9]{64}$/.test(value) ? value.toUpperCase() : '';
}
export function savePin(ip: string, port: string | number, sha256: string): void {
  if (!/^[A-Fa-f0-9]{64}$/.test(sha256)) return;
  try {
    const pins = load();
    pins[keyFor(ip, port)] = sha256.toUpperCase();
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(pins));
  } catch { /* storage unavailable: the user will simply be asked again next time */ }
}
/** AA:BB:CC… for display and for comparing against the device's own certificate page. */
export function formatFingerprint(sha256: string): string {
  return sha256.toUpperCase().match(/.{1,2}/g)?.join(':') ?? sha256;
}
