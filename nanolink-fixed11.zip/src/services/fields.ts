// Friendly labels for the status.cgi fields that every airOS generation reports under the same key.
const labels: Record<string, string> = {
  uptime: 'مدة التشغيل',
  hostname: 'اسم الجهاز',
  board: 'الموديل',
  boardname: 'الموديل',
  firmware: 'إصدار النظام',
  version: 'إصدار النظام',
  essid: 'اسم الشبكة اللاسلكية',
  frequency: 'التردد',
  channel: 'القناة',
  signal: 'قوة الإشارة',
  noise: 'مستوى التشويش',
  ccq: 'CCQ',
  tx_rate: 'معدل الإرسال TX',
  rx_rate: 'معدل الاستقبال RX',
  txrate: 'معدل الإرسال TX',
  rxrate: 'معدل الاستقبال RX',
  noise_floor: 'Noise Floor',
  airmax: 'airMAX',
  mode: 'وضع الشبكة',
  clients: 'الأجهزة المتصلة',
};

function displayValue(value: unknown): string {
  if (value === null || value === undefined || value === '') return '—';
  if (typeof value === 'object') return JSON.stringify(value);
  return String(value);
}

export function readFields(data: Record<string, unknown>) {
  const found: Array<{ label: string; value: string }> = [];
  const seen = new Set<string>();
  const walk = (value: unknown) => {
    if (!value || typeof value !== 'object') return;
    if (Array.isArray(value)) { value.forEach(walk); return; }
    for (const [key, item] of Object.entries(value as Record<string, unknown>)) {
      const normalized = key.toLowerCase().replace(/[^a-z0-9_]/g, '');
      const label = labels[normalized];
      if (label && !seen.has(label) && (typeof item !== 'object' || item === null)) {
        found.push({ label, value: displayValue(item) });
        seen.add(label);
      }
      if (typeof item === 'object' && item !== null) walk(item);
    }
  };
  walk(data);
  return found;
}

