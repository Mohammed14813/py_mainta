// Read-only extraction of the "Main" (associated stations) and "Wireless" (frequency, channel width)
// data out of a status.cgi JSON document.
//
// IMPORTANT: key names differ between airOS generations and have NOT been verified against
// airOS XW.v2.0.0 (Build 33033) yet. Each value is therefore read from an ordered list of candidate
// JSON paths, remembers which path produced it, and is null ("غير متاح") when nothing plausible is found.
// Nothing is guessed, scaled or converted: units are shown as the device reports them.

export interface Sourced<T> { value: T | null; source: string | null; }
export interface StationRow {
  name: Sourced<string>;
  mac: Sourced<string>;
  ip: Sourced<string>;
  signalDbm: Sourced<number>;
  noiseDbm: Sourced<number>;
  distance: Sourced<number>;
  tx: Sourced<number>;
  rx: Sourced<number>;
  ccq: Sourced<number>;
  uptimeSec: Sourced<number>;
}
export interface MainView {
  stations: StationRow[];
  /** JSON path of the station list, or null when the document has none. */
  stationsSource: string | null;
  frequencyMHz: Sourced<number>;
  channelWidthMHz: Sourced<number>;
  /** Human-readable reasons for anything that could not be read. */
  notes: string[];
}

const STATION_LIST_PATHS = ['wireless.sta', 'sta', 'stations'];
const MAC = /^[0-9A-F]{2}([:-][0-9A-F]{2}){5}$/i;
const KNOWN_WIDTHS = new Set([5, 10, 20, 30, 40, 60, 80, 160]);

function getPath(root: unknown, path: string): unknown {
  let current: unknown = root;
  for (const part of path.split('.')) {
    if (!current || typeof current !== 'object' || Array.isArray(current)) return undefined;
    current = (current as Record<string, unknown>)[part];
  }
  return current;
}
/** Leading number of a number or a string such as "5180 MHz" / "72.2 Mbps"; null otherwise. */
function toNumber(value: unknown): number | null {
  if (typeof value === 'number') return Number.isFinite(value) ? value : null;
  if (typeof value === 'string') {
    const match = /^\s*(-?\d+(?:\.\d+)?)/.exec(value);
    return match ? Number(match[1]) : null;
  }
  return null;
}
function toText(value: unknown): string | null {
  if (Array.isArray(value)) return toText(value.find((item) => typeof item === 'string' && item.trim() !== ''));
  return typeof value === 'string' && value.trim() !== '' ? value.trim() : null;
}
function toMac(value: unknown): string | null {
  const text = toText(value);
  return text && MAC.test(text) ? text.toUpperCase().replace(/-/g, ':') : null;
}
function pickFrom<T>(root: unknown, paths: string[], convert: (value: unknown) => T | null, accept: (value: T) => boolean = () => true): Sourced<T> {
  for (const path of paths) {
    const converted = convert(getPath(root, path));
    if (converted !== null && accept(converted)) return { value: converted, source: path };
  }
  return { value: null, source: null };
}

function parseStation(raw: Record<string, unknown>): StationRow {
  const nonNegative = (n: number) => n >= 0;
  return {
    name: pickFrom(raw, ['name', 'hostname', 'remote.hostname', 'remote.name'], toText),
    mac: pickFrom(raw, ['mac', 'remote.mac'], toMac),
    ip: pickFrom(raw, ['lastip', 'ip', 'ipaddr', 'remote.ipaddr', 'remote.lastip', 'remote.ip', 'remote.ipv4'], toText),
    // Signal and noise are plausibility-checked so a unit or key mix-up shows as "غير متاح", not as a wrong number.
    signalDbm: pickFrom(raw, ['signal', 'rssi', 'remote.signal', 'remote.rssi'], toNumber, (n) => n >= -130 && n <= 0),
    noiseDbm: pickFrom(raw, ['noisefloor', 'noise', 'remote.noisefloor'], toNumber, (n) => n >= -130 && n <= 0),
    distance: pickFrom(raw, ['distance', 'remote.distance'], toNumber, nonNegative),
    tx: pickFrom(raw, ['tx', 'tx_rate', 'txrate', 'remote.tx_rate'], toNumber, nonNegative),
    rx: pickFrom(raw, ['rx', 'rx_rate', 'rxrate', 'remote.rx_rate'], toNumber, nonNegative),
    ccq: pickFrom(raw, ['ccq', 'remote.ccq'], toNumber, nonNegative),
    uptimeSec: pickFrom(raw, ['uptime', 'remote.uptime'], toNumber, nonNegative),
  };
}

export function parseMain(status: Record<string, unknown>, extraStations: unknown[] = []): MainView {
  const notes: string[] = [];
  let stations: StationRow[] = [];
  let stationsSource: string | null = null;
  for (const path of STATION_LIST_PATHS) {
    const list = getPath(status, path);
    if (Array.isArray(list)) {
      stationsSource = path;
      stations = list.filter((item): item is Record<string, unknown> => !!item && typeof item === 'object' && !Array.isArray(item)).map(parseStation);
      break;
    }
  }
  if (stationsSource === null) {
    notes.push('لم تحتوِ استجابة status.cgi على قائمة محطات (جُرّبت: ' + STATION_LIST_PATHS.join('، ') + '). قد تكون في طلب منفصل على هذا الإصدار، أو أن الجهاز في وضع Station.');
  } else if (stations.length === 0) {
    notes.push('قائمة المحطات موجودة لكنها فارغة: لا محطات مرتبطة الآن، أو أن الجهاز يعمل كمحطة وليس كنقطة وصول.');
  }
  // Merge the optional /sta.cgi list: fill only what status.cgi did not provide (matched by MAC).
  const extraRows = extraStations.filter((item): item is Record<string, unknown> => !!item && typeof item === 'object' && !Array.isArray(item)).map(parseStation);
  if (extraRows.length) {
    if (stationsSource === null) { stations = extraRows; stationsSource = 'sta.cgi'; }
    else {
      const byMac = new Map(extraRows.filter((row) => row.mac.value).map((row) => [row.mac.value as string, row]));
      stations = stations.map((row) => {
        const extra = row.mac.value ? byMac.get(row.mac.value) : undefined;
        if (!extra) return row;
        const merged = { ...row } as StationRow;
        for (const key of Object.keys(row) as Array<keyof StationRow>) {
          if (merged[key].value === null && extra[key].value !== null) (merged as unknown as Record<string, unknown>)[key] = { value: extra[key].value, source: `sta.cgi:${extra[key].source}` };
        }
        return merged;
      });
    }
    const idx = notes.findIndex((n) => n.startsWith('لم تحتوِ') || n.startsWith('قائمة المحطات موجودة لكنها فارغة'));
    if (idx >= 0 && stations.length) notes.splice(idx, 1);
  }
  const frequencyMHz = pickFrom(status, ['wireless.frequency', 'wireless.freq'], toNumber, (n) => n >= 2000 && n <= 7200);
  if (frequencyMHz.value === null) {
    const rawFrequency = getPath(status, 'wireless.frequency');
    notes.push(rawFrequency === undefined
      ? 'التردد غير موجود في الاستجابة (wireless.frequency).'
      : `قيمة التردد التي أعادها الجهاز (${JSON.stringify(rawFrequency)}) خارج النطاق المتوقع بوحدة MHz، فلم تُعرض.`);
  }
  const channelWidthMHz = pickFrom(status, ['wireless.chanbw', 'wireless.channel_width', 'wireless.chwidth'], toNumber, (n) => KNOWN_WIDTHS.has(n));
  if (channelWidthMHz.value === null) notes.push('عرض القناة غير مؤكد في الاستجابة (wireless.chanbw). قد يتطلب هذا الإصدار قراءته من طلب آخر.');
  return { stations, stationsSource, frequencyMHz, channelWidthMHz, notes };
}

/** Signal quality label from dBm (display helper only; the raw dBm value is always shown too). */
export function signalQuality(dbm: number): { label: string; tone: 'good' | 'ok' | 'weak' | 'bad' } {
  if (dbm >= -65) return { label: 'ممتازة', tone: 'good' };
  if (dbm >= -75) return { label: 'جيدة', tone: 'ok' };
  if (dbm >= -85) return { label: 'ضعيفة', tone: 'weak' };
  return { label: 'سيئة', tone: 'bad' };
}

export function formatUptime(seconds: number): string {
  const total = Math.max(0, Math.floor(seconds));
  const days = Math.floor(total / 86400);
  const hours = Math.floor((total % 86400) / 3600);
  const minutes = Math.floor((total % 3600) / 60);
  return `${days ? `${days}ي ` : ''}${hours}س ${minutes}د`;
}

/* ───── sharing: hide identifying values before the JSON is copied or sent to anyone ───── */

const SENSITIVE_KEYS = /^(mac|apmac|hwaddr|bssid|lastip|ip|ipaddr|ip6addr|hostname|name|essid|ssid|device_id|serial|uuid|remote_mac)$/i;
const MAC_VALUE = /\b[0-9A-F]{2}([:-][0-9A-F]{2}){5}\b/gi;
const IPV4_VALUE = /\b\d{1,3}(\.\d{1,3}){3}\b/g;
export function redactForSharing(value: unknown): unknown {
  if (Array.isArray(value)) return value.map(redactForSharing);
  if (value && typeof value === 'object') {
    return Object.fromEntries(Object.entries(value as Record<string, unknown>).map(([key, item]) =>
      [key, SENSITIVE_KEYS.test(key) && (typeof item === 'string' || Array.isArray(item)) ? '<redacted>' : redactForSharing(item)]));
  }
  if (typeof value === 'string') return value.replace(MAC_VALUE, '<mac>').replace(IPV4_VALUE, '<ip>');
  return value;
}
