// طبقة المحاكاة فقط. لا اتصال بأي جهاز حقيقي.
// TODO: تكامل NanoStation الحقيقي سيضاف لاحقًا في real.ts بعد معرفة الموديلات وإصدار airOS.
import { ChannelResult, Device, Radio } from '../types';
import { sleep } from '../utils/format';

export const CHANNELS = [{ ch: 36, f: 5180 }, { ch: 40, f: 5200 }, { ch: 44, f: 5220 }, { ch: 48, f: 5240 }, { ch: 149, f: 5745 }, { ch: 153, f: 5765 }, { ch: 157, f: 5785 }, { ch: 161, f: 5805 }];
const OFFSET: Record<number, number> = { 36: -20, 40: 4, 44: 10, 48: -6, 149: 8, 153: 14, 157: -28, 161: 0 };
const r = (a: number, b: number) => a + Math.random() * (b - a);
const clamp = (v: number, a = 2, b = 99) => Math.min(b, Math.max(a, v));
const n = (v: number, d = 1) => +v.toFixed(d);
export const freqOf = (ch: number) => CHANNELS.find((c) => c.ch === ch)?.f ?? 5180;

export function synth(q0: number, channel: number, jit = 0): Radio {
  const q = clamp(q0 + r(-jit, jit));
  return {
    channel, freq: freqOf(channel), width: q > 60 ? 40 : 20,
    signal: Math.round(-42 - (100 - q) * 0.5), noise: Math.round(-98 + (100 - q) * 0.25),
    ccq: Math.round(clamp(q + 4, 0, 100)), amq: Math.round(q), amc: Math.round(clamp(q - 3, 0, 100)),
    tx: Math.round(q * 3.4), rx: Math.round(q * 3.1), dl: n(q * 1.9), ul: n(q * 1.1),
    ping: n(2 + (100 - q) * 0.6), loss: n(Math.max(0, (70 - q) * 0.12)), jitter: n(0.4 + (100 - q) * 0.08), eff: Math.round(q),
  };
}

export async function scan(d: Device): Promise<Device> {
  await sleep(250);
  if (d.status === 'timeout') throw new Error(`${d.name}: Timeout تجريبي`);
  if (d.status === 'offline') return d;
  const m = synth(d.q, d.channel, 4);
  return { ...d, ...m, status: m.eff < 50 ? 'problem' : 'connected' };
}

export async function testChannel(d: Device, ch: number): Promise<ChannelResult> {
  await sleep(250);
  if (d.status === 'offline' || d.status === 'timeout') throw new Error('الجهاز لا يستجيب (محاكاة)');
  const m = synth(d.q + (OFFSET[ch] ?? 0), ch, 10);
  const { channel, freq, eff, dl, ul, signal, noise, ccq, tx, rx, ping, loss, jitter } = m;
  return { channel, freq, eff, dl, ul, signal, noise, ccq, tx, rx, ping, loss, jitter, status: eff >= 50 ? 'connected' : 'problem' };
}

export function avgResults(rs: ChannelResult[]): ChannelResult {
  const k = (f: (x: ChannelResult) => number, d = 1) => n(rs.reduce((s, x) => s + f(x), 0) / rs.length, d);
  const eff = Math.round(k((x) => x.eff));
  return { ...rs[0], eff, status: eff >= 50 ? 'connected' : 'problem', dl: k((x) => x.dl), ul: k((x) => x.ul), signal: Math.round(k((x) => x.signal)), noise: Math.round(k((x) => x.noise)), ccq: Math.round(k((x) => x.ccq)), tx: Math.round(k((x) => x.tx)), rx: Math.round(k((x) => x.rx)), ping: k((x) => x.ping), loss: k((x) => x.loss), jitter: k((x) => x.jitter) };
}

export async function speedTest(d: Device) {
  await sleep(900);
  if (d.status === 'offline' || d.status === 'timeout') throw new Error('الجهاز لا يستجيب (محاكاة)');
  const s = Array.from({ length: 6 }, () => synth(d.q, d.channel, 6));
  const dl = s.map((x) => x.dl); const ul = s.map((x) => x.ul);
  const all = [...dl, ...ul];
  const m = s[0];
  return { dl: n(dl.reduce((a, b) => a + b, 0) / dl.length), ul: n(ul.reduce((a, b) => a + b, 0) / ul.length), avg: n(all.reduce((a, b) => a + b, 0) / all.length), min: n(Math.min(...all)), max: n(Math.max(...all)), ping: m.ping, loss: m.loss, jitter: m.jitter, tx: m.tx, rx: m.rx };
}
