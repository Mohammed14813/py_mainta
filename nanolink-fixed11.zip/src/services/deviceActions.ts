import { ActionsUnavailable, DeviceActions } from './campaign';
import type { RealConnection } from './real';

/**
 * The two device WRITES the campaign needs: change the radio frequency, and start the Speed Test tool.
 *
 * Their airOS endpoints on XW.v2.0.0 (Build 33033) are NOT confirmed, and the app must not invent a request
 * that changes a radio. Until they are confirmed, `available` is false, the campaign refuses to start, and the
 * read-only guard in real.ts (POST only to /api/auth and /login.cgi) stays fully in force.
 *
 * To finish this file, a HAR capture from the device web UI is needed (password and cookies removed) while:
 *   1) changing the channel/frequency in Wireless and pressing Apply, and
 *   2) opening Tools → Speed Test, entering a unit's address/user/password, and running it.
 * Then: add the confirmed paths to POST_ALLOWED_PATHS in real.ts (only those), expose a `post` helper on
 * RealConnection, and implement the two functions below. runCampaign() already handles backup of the original
 * channel, waiting for the units to return, the rollback timeout, and verified restore.
 */
const REASON = 'تغيير القناة وتشغيل Speed Test على الجهاز غير مفعّلين بعد: مساراتهما على هذا الإصدار غير مؤكدة. يلزم سجل شبكة (HAR) من واجهة الجهاز أثناء تغيير القناة وأثناء تشغيل Speed Test.';

export const unconfirmedActions: DeviceActions = {
  available: false,
  reason: REASON,
  async setFrequency() { throw new ActionsUnavailable(REASON); },
  async runSpeedTest() { throw new ActionsUnavailable(REASON); },
};

/* ───────────── per-model support registry ───────────── */

export interface ActionProfile {
  id: string;
  label: string;
  /** true only for the exact airOS generation/model family this profile was recorded and verified on. */
  matches(unit: Pick<RealConnection, 'flavor' | 'family' | 'model' | 'firmware'>): boolean;
  actions: DeviceActions;
}
/** Empty until a HAR is verified for a given flavor/model/firmware. One entry per verified combination. */
export const PROFILES: ActionProfile[] = [];

export function describeUnit(unit: Pick<RealConnection, 'flavor' | 'family' | 'model' | 'firmware'>): string {
  return `${unit.flavor === 'v8' ? 'airOS 8' : 'airOS 5/6'} · ${unit.family} · ${unit.model} · ${unit.firmware}`;
}
export function findProfile(unit: Pick<RealConnection, 'flavor' | 'family' | 'model' | 'firmware'>): ActionProfile | null {
  return PROFILES.find((profile) => profile.matches(unit)) ?? null;
}
