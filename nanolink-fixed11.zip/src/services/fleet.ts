// Multi-unit tools: list the units behind the main node, test each unit's username/password one by one
// (login + GET only), read each valid unit's status, and build a text report.
//
// Credentials live only in React state (memory). They are never written to storage, and never put in a report.

import { AuthRejected, AirOsSnapshot, CertificateInfo, connectReal, ConnectInput, DeviceProtocol, probeDeviceCertificate, RealConnection } from './real';
import { getPin, savePin } from './pins';
import { parseMain, signalQuality, StationRow } from './airosView';
import { readFields } from './fields';

export type AuthState = 'unset' | 'checking' | 'ok' | 'bad' | 'unsure' | 'needs-cert' | 'error';

export interface UnitReading {
  model: string;
  firmware: string;
  frequencyMHz: number | null;
  widthMHz: number | null;
  fields: Array<{ label: string; value: string }>;
  readAt: string;
}
export interface PendingCert extends CertificateInfo { changed: boolean; }

export interface FleetUnit {
  /** MAC when known, otherwise IP, otherwise name. Stable across refreshes. */
  key: string;
  name: string;
  mac: string;
  ip: string;
  /** The unit is in the latest station list of the main node. */
  listed: boolean;
  /** Signal of this unit as seen by the main node (dBm), for the report. */
  signalDbm: number | null;
  username: string;
  password: string;
  auth: AuthState;
  message: string;
  excluded: boolean;
  pendingCert?: PendingCert;
  reading?: UnitReading;
}

export interface CheckContext { protocol: DeviceProtocol; port: string; trustNewCerts: boolean; }
export interface CheckOutcome {
  auth: AuthState;
  message: string;
  connection?: RealConnection;
  reading?: UnitReading;
  pendingCert?: PendingCert;
}

export function unitFromStation(station: StationRow): FleetUnit {
  const mac = station.mac.value ?? '';
  const ip = station.ip.value ?? '';
  const name = station.name.value ?? '';
  return {
    key: mac || ip || name || `unit-${Math.random().toString(16).slice(2, 8)}`,
    name: name || '(بدون اسم)', mac, ip, listed: true,
    signalDbm: station.signalDbm.value,
    username: '', password: '', auth: 'unset', message: '', excluded: false,
  };
}

/** Keeps what the user already typed (credentials, results) when the station list refreshes. */
export function mergeUnits(previous: FleetUnit[], stations: StationRow[]): FleetUnit[] {
  const fresh = stations.map(unitFromStation);
  const freshKeys = new Set(fresh.map((unit) => unit.key));
  const byKey = new Map(previous.map((unit) => [unit.key, unit]));
  const merged = fresh.map((unit) => {
    const old = byKey.get(unit.key);
    return old ? { ...old, name: unit.name, mac: unit.mac || old.mac, ip: unit.ip || old.ip, signalDbm: unit.signalDbm, listed: true } : unit;
  });
  const missing = previous.filter((unit) => !freshKeys.has(unit.key)).map((unit) => ({ ...unit, listed: false }));
  return [...merged, ...missing];
}

export function readingFrom(snapshot: AirOsSnapshot): UnitReading {
  const view = parseMain(snapshot.status, snapshot.extraStations);
  return {
    model: snapshot.model, firmware: snapshot.firmware,
    frequencyMHz: view.frequencyMHz.value, widthMHz: view.channelWidthMHz.value,
    fields: readFields(snapshot.status), readAt: snapshot.readAt,
  };
}

/**
 * Tests one unit: certificate pin, then login + first status read. One attempt only (a wrong password is
 * never retried, so a lockout counter on the unit is not pushed further).
 */
export async function checkUnit(unit: FleetUnit, ctx: CheckContext, approvedPin = ''): Promise<CheckOutcome> {
  if (!unit.ip) return { auth: 'error', message: 'لا يوجد IP لهذه العلبة في قائمة المحطات، فلا يمكن فحصها.' };
  if (!unit.username.trim() || !unit.password) return { auth: 'unset', message: 'لم تُدخل اليوزر أو الباسورد.' };
  const input: ConnectInput = { ip: unit.ip, username: unit.username.trim(), password: unit.password, protocol: ctx.protocol, port: ctx.port };
  try {
    let pin = '';
    if (ctx.protocol === 'https') {
      if (approvedPin) pin = approvedPin.toUpperCase();
      else {
        const info = await probeDeviceCertificate(input);
        const current = info.sha256.toUpperCase();
        const saved = getPin(unit.ip, ctx.port);
        if (saved === current) pin = current;
        else if (saved === '' && ctx.trustNewCerts) pin = current;
        else {
          return {
            auth: 'needs-cert',
            message: saved ? 'تغيّرت شهادة هذه العلبة عن المعتمدة سابقًا. لم تُرسل أي بيانات دخول.' : 'شهادة هذه العلبة غير معتمدة بعد. لم تُرسل أي بيانات دخول.',
            pendingCert: { ...info, changed: saved !== '' },
          };
        }
      }
    }
    const connection = await connectReal(input, pin);
    if (pin) savePin(unit.ip, ctx.port, pin); // remembered only after a successful login
    return { auth: 'ok', message: 'اليوزر والباسورد صحيحان.', connection, reading: readingFrom(connection.initialSnapshot) };
  } catch (error) {
    if (error instanceof AuthRejected) {
      return error.definitive
        ? { auth: 'bad', message: 'اليوزر أو الباسورد خطأ.' }
        : { auth: 'unsure', message: error.message };
    }
    return { auth: 'error', message: error instanceof Error ? error.message : 'تعذر الاتصال بالعلبة.' };
  }
}

export const AUTH_LABEL: Record<AuthState, { text: string; cls: string }> = {
  unset: { text: 'لم يُفحص', cls: 'bg-slate-600/40 text-slate-300' },
  checking: { text: 'جارٍ الفحص', cls: 'bg-blue-500/20 text-blue-300' },
  ok: { text: 'صحيح', cls: 'bg-emerald-500/20 text-emerald-300' },
  bad: { text: 'خطأ', cls: 'bg-red-500/20 text-red-300' },
  unsure: { text: 'غير مؤكد', cls: 'bg-amber-500/20 text-amber-300' },
  'needs-cert': { text: 'شهادة تحتاج موافقة', cls: 'bg-amber-500/20 text-amber-300' },
  error: { text: 'تعذر الاتصال', cls: 'bg-red-500/20 text-red-300' },
};

/* ───────────── report ───────────── */

export interface MainInfo { frequencyMHz: number | null; widthMHz: number | null; }

export function buildReport(units: FleetUnit[], main: MainInfo, when: Date = new Date()): string {
  const lines: string[] = [];
  lines.push(`تقرير NanoLink — ${when.toLocaleString('ar')}`);
  lines.push(`القناة الحالية للعلبة الرئيسية: ${main.frequencyMHz ?? 'غير متاح'} MHz${main.widthMHz ? ` (عرض ${main.widthMHz} MHz)` : ''}`);
  lines.push('');
  const active = units.filter((unit) => !unit.excluded);
  const okCount = active.filter((unit) => unit.auth === 'ok').length;
  lines.push(`العلب: ${units.length} — مفحوصة: ${active.length} — بيانات دخولها صحيحة: ${okCount} — مستبعدة: ${units.length - active.length}`);
  lines.push('');
  units.forEach((unit, index) => {
    lines.push(`${index + 1}) ${unit.name} | IP ${unit.ip || '—'} | MAC ${unit.mac || '—'}`);
    if (unit.excluded) { lines.push('   مستبعدة من الفحص.'); lines.push(''); return; }
    lines.push(`   الدخول: ${AUTH_LABEL[unit.auth].text}${unit.auth === 'ok' ? '' : unit.message ? ` — ${unit.message}` : ''}`);
    if (unit.signalDbm !== null) lines.push(`   الإشارة كما تراها العلبة الرئيسية: ${unit.signalDbm} dBm (${signalQuality(unit.signalDbm).label})`);
    if (unit.reading) {
      lines.push(`   الموديل: ${unit.reading.model} | الإصدار: ${unit.reading.firmware}`);
      lines.push(`   التردد: ${unit.reading.frequencyMHz ?? 'غير متاح'} MHz`);
      unit.reading.fields.forEach((field) => lines.push(`   ${field.label}: ${field.value}`));
    }
    lines.push('');
  });
  return lines.join('\n');
}
