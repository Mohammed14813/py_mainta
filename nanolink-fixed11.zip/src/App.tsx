import { useState } from 'react';
import Connect from './pages/Connect';
import RealDashboard from './pages/RealDashboard';
import { RealConnection } from './services/real';

export default function App() {
  const [connection, setConnection] = useState<RealConnection | null>(null);
  if (!connection) return <Connect onConnected={setConnection} />;
  return <RealDashboard connection={connection} onDisconnect={() => setConnection(null)} />;
}
