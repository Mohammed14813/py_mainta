import { ReactNode } from 'react';
import { rating } from '../utils/format';
import { Status } from '../types';

export const inp = 'w-full rounded-lg bg-slate-900 border border-slate-600 px-3 py-2 text-sm';
export const Card = ({ children, className = '' }: { children: ReactNode; className?: string }) => (
  <div className={`rounded-xl bg-slate-800/80 border border-slate-700 p-4 ${className}`}>{children}</div>
);
export function Btn({ children, onClick, kind = 'pri', disabled }: { children: ReactNode; onClick?: () => void; kind?: 'pri' | 'sec' | 'red'; disabled?: boolean }) {
  const c = kind === 'pri' ? 'bg-blue-600 hover:bg-blue-500' : kind === 'red' ? 'bg-red-600 hover:bg-red-500' : 'bg-slate-600 hover:bg-slate-500';
  return <button disabled={disabled} onClick={onClick} className={`${c} rounded-lg px-4 py-2 text-sm font-medium disabled:opacity-40`}>{children}</button>;
}
export const Field = ({ label, children }: { label: string; children: ReactNode }) => (
  <label className="block text-sm"><span className="mb-1 block text-slate-300">{label}</span>{children}</label>
);
export const Scroll = ({ children }: { children: ReactNode }) => <div className="overflow-x-auto"><table className="w-full min-w-max text-sm text-right">{children}</table></div>;
export const Th = ({ children }: { children: ReactNode }) => <th className="whitespace-nowrap border-b border-slate-600 px-3 py-2 font-semibold text-slate-300">{children}</th>;
export const Td = ({ children }: { children: ReactNode }) => <td className="whitespace-nowrap border-b border-slate-700 px-3 py-2">{children}</td>;
export function Badge({ eff, status }: { eff: number; status?: Status }) {
  const r = rating(eff, status);
  return <span className={`rounded-full px-2 py-0.5 text-xs ${r.cls}`}>{r.label}</span>;
}
export const Stat = ({ label, value, color = 'text-white' }: { label: string; value: ReactNode; color?: string }) => (
  <Card><div className="text-xs text-slate-400">{label}</div><div className={`mt-1 text-2xl font-bold ${color}`}>{value}</div></Card>
);
