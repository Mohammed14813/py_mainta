import { ChannelResult } from '../types';
import { Badge, Card, Scroll, Td, Th } from './ui';
import { statusLabel } from '../utils/format';

export default function ResultsTable({ results }: { results: ChannelResult[] }) {
  if (!results.length) return null;
  const s = [...results].sort((a, b) => b.eff - a.eff);
  const best = s[0]; const worst = s[s.length - 1];
  return (
    <>
      <div className="grid grid-cols-2 gap-3">
        <Card><div className="text-xs text-slate-400">أفضل قناة</div><div className="text-xl font-bold text-emerald-400">{best.channel} ({best.eff}%)</div></Card>
        <Card><div className="text-xs text-slate-400">أضعف قناة</div><div className="text-xl font-bold text-red-400">{worst.channel} ({worst.eff}%)</div></Card>
      </div>
      <Card>
        <Scroll>
          <thead><tr>{['القناة', 'التردد MHz', 'الكفاءة %', 'التنزيل Mbps', 'الرفع Mbps', 'الإشارة dBm', 'Noise Floor dBm', 'CCQ %', 'TX Rate Mbps', 'RX Rate Mbps', 'Ping ms', 'Packet Loss %', 'Jitter ms', 'التقييم', 'الحالة'].map((h) => <Th key={h}>{h}</Th>)}</tr></thead>
          <tbody>{s.map((r) => (
            <tr key={r.channel}>
              <Td>{r.channel}</Td><Td>{r.freq}</Td><Td>{r.eff}%</Td><Td>{r.dl}</Td><Td>{r.ul}</Td><Td>{r.signal}</Td><Td>{r.noise}</Td><Td>{r.ccq}%</Td>
              <Td>{r.tx}</Td><Td>{r.rx}</Td><Td>{r.ping}</Td><Td>{r.loss}%</Td><Td>{r.jitter}</Td><Td><Badge eff={r.eff} status={r.status} /></Td><Td>{statusLabel[r.status]}</Td>
            </tr>))}
          </tbody>
        </Scroll>
      </Card>
    </>
  );
}
