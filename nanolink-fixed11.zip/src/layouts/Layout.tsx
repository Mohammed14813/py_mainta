import { ReactNode, useState } from 'react';
import { PageId } from '../types';
import { useStore } from '../hooks/useStore';

export const NAV: [PageId, string][] = [
  ['dashboard', 'لوحة التحكم'], ['main', 'العلبة الرئيسية'], ['nodes', 'العلب المرتبطة'], ['tree', 'شجرة الشبكة'],
  ['safe', 'الفحص الآمن بدون فصل'], ['test', 'اختبار القنوات مع فصل مؤقت'], ['speed', 'اختبار السرعة'], ['reports', 'التقارير'], ['settings', 'الإعدادات'],
];

export default function Layout({ page, setPage, children }: { page: PageId; setPage: (p: PageId) => void; children: ReactNode }) {
  const { sim } = useStore();
  const [open, setOpen] = useState(false);
  const [msg, setMsg] = useState('');
  const toggle = () => { setMsg('الوضع الحقيقي غير متاح في هذا الإصدار — سيُضاف تكامل NanoStation لاحقًا.'); setTimeout(() => setMsg(''), 4000); };
  return (
    <div className="flex min-h-screen bg-slate-950">
      <aside className={`fixed inset-y-0 right-0 z-30 w-64 transform border-l border-slate-700 bg-slate-900 p-4 transition md:static md:translate-x-0 ${open ? '' : 'translate-x-full'}`}>
        <div className="mb-4 text-lg font-bold text-blue-400">محلل شبكة NanoLink</div>
        <nav className="space-y-1">
          {NAV.map(([id, label]) => (
            <button key={id} onClick={() => { setPage(id); setOpen(false); }} className={`block w-full rounded-lg px-3 py-2 text-right text-sm ${page === id ? 'bg-blue-600' : 'hover:bg-slate-800'}`}>{label}</button>
          ))}
        </nav>
        <button onClick={toggle} className="mt-6 w-full rounded-lg bg-yellow-500/20 px-3 py-2 text-sm text-yellow-300">وضع المحاكاة: {sim ? 'مفعّل' : 'معطّل'}</button>
      </aside>
      <main className="min-w-0 flex-1">
        <header className="sticky top-0 z-20 flex items-center gap-3 border-b border-slate-700 bg-slate-900/95 p-3">
          <button className="rounded bg-slate-700 px-3 py-1 md:hidden" onClick={() => setOpen(!open)}>☰</button>
          <span className="text-sm text-yellow-300">وضع المحاكاة فعال — لن يتم الاتصال بأي جهاز حقيقي.</span>
        </header>
        {msg && <div className="m-4 rounded-lg bg-red-500/20 p-3 text-sm text-red-200">{msg}</div>}
        <div className="space-y-4 p-4">{children}</div>
      </main>
    </div>
  );
}
