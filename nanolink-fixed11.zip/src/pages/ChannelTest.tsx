import { useRef, useState } from 'react';
import { useStore } from '../hooks/useStore';
import { Btn, Card, Field, inp } from '../components/ui';
import ResultsTable from '../components/ResultsTable';
import { ChannelResult } from '../types';
import { avgResults, CHANNELS, testChannel } from '../services/simulator';
import { bestShared, sleep } from '../utils/format';

type Phase = 'idle' | 'running' | 'paused' | 'done' | 'stopped';
const LIMS: [string, string][] = [['eff', 'أقل كفاءة مقبولة %'], ['dl', 'أقل Download Mbps'], ['ul', 'أقل Upload Mbps'], ['ping', 'أقصى Ping ms'], ['loss', 'أقصى Packet Loss %'], ['ccq', 'أقل CCQ %']];

export default function ChannelTest() {
  const { devices, runs, addRun } = useStore();
  const cand = devices.filter((d) => !d.isMain);
  const [dev, setDev] = useState(cand[0].id);
  const [chs, setChs] = useState<number[]>(CHANNELS.map((c) => c.ch));
  const [dur, setDur] = useState('10');
  const [reps, setReps] = useState('3');
  const [all, setAll] = useState(true);
  const [stopFirst, setStopFirst] = useState(false);
  const [lim, setLim] = useState<Record<string, string>>({});
  const [phase, setPhase] = useState<Phase>('idle');
  const [res, setRes] = useState<ChannelResult[]>([]);
  const [errs, setErrs] = useState<string[]>([]);
  const [found, setFound] = useState(false);
  const [warn, setWarn] = useState(false);
  const ctl = useRef({ pause: false, stop: false });

  const has = (k: string) => lim[k] !== undefined && lim[k] !== '';
  const meets = (r: ChannelResult) => {
    const any = LIMS.some(([k]) => has(k));
    if (!any) return false;
    return (!has('eff') || r.eff >= +lim.eff) && (!has('dl') || r.dl >= +lim.dl) && (!has('ul') || r.ul >= +lim.ul) && (!has('ping') || r.ping <= +lim.ping) && (!has('loss') || r.loss <= +lim.loss) && (!has('ccq') || r.ccq >= +lim.ccq);
  };

  async function run() {
    setWarn(false); ctl.current = { pause: false, stop: false };
    setRes([]); setErrs([]); setFound(false); setPhase('running');
    const d = devices.find((x) => x.id === dev)!;
    const list = all ? CHANNELS.map((c) => c.ch) : chs;
    const n = Math.max(1, parseInt(reps) || 1);
    const start = new Date().toISOString();
    const out: ChannelResult[] = []; const errors: string[] = [];
    for (const ch of list) {
      while (ctl.current.pause && !ctl.current.stop) await sleep(200);
      if (ctl.current.stop) break;
      try {
        const rs: ChannelResult[] = [];
        for (let i = 0; i < n; i++) rs.push(await testChannel(d, ch));
        await sleep(Math.min(2000, Math.max(250, (parseFloat(dur) || 1) * 100)));
        const a = avgResults(rs);
        out.push(a);
        if (meets(a)) { setFound(true); if (stopFirst) { ctl.current.pause = true; setPhase('paused'); } }
      } catch (e) { errors.push(`القناة ${ch}: ${(e as Error).message}`); }
      setRes([...out]); setErrs([...errors]);
    }
    const stopped = ctl.current.stop;
    addRun({ id: String(Date.now()), deviceId: d.id, deviceName: d.name, start, end: new Date().toISOString(), results: out, errors });
    setPhase(stopped ? 'stopped' : 'done');
  }
  const pause = () => { ctl.current.pause = true; setPhase('paused'); };
  const resume = () => { ctl.current.pause = false; setFound(false); setPhase('running'); };
  const stop = () => { ctl.current.stop = true; ctl.current.pause = false; };
  const busy = phase === 'running' || phase === 'paused';
  const shared = bestShared(runs);

  return (
    <>
      <h1 className="text-xl font-bold">اختبار القنوات مع فصل مؤقت</h1>
      <Card className="grid gap-3 md:grid-cols-2">
        <Field label="الفرع المراد اختباره"><select className={inp} value={dev} onChange={(e) => setDev(e.target.value)}>{cand.map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}</select></Field>
        <Field label="مدة اختبار كل قناة (ثانية)"><input className={inp} dir="ltr" value={dur} onChange={(e) => setDur(e.target.value)} /></Field>
        <Field label="عدد مرات القياس"><input className={inp} dir="ltr" value={reps} onChange={(e) => setReps(e.target.value)} /></Field>
        <div className="space-y-2 text-sm">
          <label className="flex items-center gap-2"><input type="checkbox" checked={all} onChange={(e) => setAll(e.target.checked)} /> اختبار جميع القنوات</label>
          <label className="flex items-center gap-2"><input type="checkbox" checked={stopFirst} onChange={(e) => setStopFirst(e.target.checked)} /> التوقف عند أول قناة تحقق الشروط</label>
        </div>
        {!all && (
          <div className="md:col-span-2"><div className="mb-1 text-sm text-slate-300">القنوات المراد اختبارها</div>
            <div className="flex flex-wrap gap-2">{CHANNELS.map((c) => (
              <label key={c.ch} className="flex items-center gap-1 rounded bg-slate-900 px-2 py-1 text-sm"><input type="checkbox" checked={chs.includes(c.ch)} onChange={(e) => setChs((x) => (e.target.checked ? [...x, c.ch] : x.filter((y) => y !== c.ch)))} />{c.ch} ({c.f})</label>))}
            </div></div>
        )}
        <div className="grid grid-cols-2 gap-3 md:col-span-2 md:grid-cols-3">
          {LIMS.map(([k, l]) => <Field key={k} label={`${l} (اختياري)`}><input className={inp} dir="ltr" inputMode="decimal" value={lim[k] ?? ''} onChange={(e) => setLim((x) => ({ ...x, [k]: e.target.value }))} /></Field>)}
        </div>
      </Card>
      {warn && (
        <Card className="space-y-3 border-yellow-500">
          <div className="text-sm text-yellow-200">في الوضع الحقيقي قد يؤدي اختبار القنوات إلى انقطاع مؤقت. الوضع الحالي محاكاة ولن يؤثر على أي شبكة.</div>
          <div className="flex gap-2"><Btn onClick={run}>بدء الاختبار</Btn><Btn kind="sec" onClick={() => setWarn(false)}>إلغاء</Btn></div>
        </Card>
      )}
      <div className="flex flex-wrap gap-2">
        {!busy && <Btn onClick={() => setWarn(true)}>اختبار القنوات مع فصل مؤقت</Btn>}
        {phase === 'running' && <Btn kind="sec" onClick={pause}>إيقاف مؤقت</Btn>}
        {phase === 'paused' && <Btn onClick={resume}>متابعة</Btn>}
        {busy && <Btn kind="red" onClick={stop}>إيقاف الاختبار</Btn>}
        {(phase === 'stopped' || phase === 'done') && <Btn kind="sec" onClick={run}>إعادة المحاولة</Btn>}
      </div>
      {busy && <div className="text-sm text-slate-300">{phase === 'paused' ? 'الاختبار متوقف مؤقتًا' : 'جارٍ الاختبار (محاكاة)...'} — تم اختبار {res.length} قناة</div>}
      {found && (
        <Card className="space-y-2 border-emerald-500">
          <div className="text-emerald-300">تم العثور على قناة تحقق الحدود المحددة.</div>
          {phase === 'paused' && <div className="flex gap-2"><Btn kind="red" onClick={stop}>إيقاف الاختبار</Btn><Btn onClick={resume}>متابعة اختبار باقي القنوات</Btn></div>}
        </Card>
      )}
      {phase === 'stopped' && <div className="text-sm text-yellow-300">تم إيقاف الاختبار. النتائج المعروضة هي ما تم جمعه حتى لحظة الإيقاف.</div>}
      {errs.map((e) => <div key={e} className="rounded-lg bg-red-500/20 p-2 text-sm text-red-200">{e}</div>)}
      <ResultsTable results={res} />
      {shared && <Card className="text-sm text-slate-300">أفضل قناة مشتركة محافظة للشبكة: <b className="text-emerald-300">{shared.channel}</b> — الحد الأدنى للكفاءة {shared.eff}%، التنزيل الأدنى {shared.dl} Mbps، الرفع الأدنى {shared.ul} Mbps، أعلى Ping {shared.ping} ms، أعلى فقدان {shared.loss}%. تم احتسابها بناءً على أضعف وصلة، وليس المتوسط فقط.</Card>}
    </>
  );
}
