import { ReactNode, useState } from 'react';
import { useStore } from '../hooks/useStore';
import { Badge, Btn, Card, Scroll, Td, Th } from '../components/ui';
import { Device } from '../types';
import { scan } from '../services/simulator';

export default function SafeScan() {
  const { devices, setDevices, setLastScan } = useStore();
  const [busy, setBusy] = useState(false);
  const [errs, setErrs] = useState<string[]>([]);
  const [done, setDone] = useState(false);

  async function run() {
    setBusy(true); setErrs([]);
    const out: Device[] = []; const e: string[] = [];
    for (const d of devices) { try { out.push(await scan(d)); } catch (x) { e.push((x as Error).message); out.push({ ...d, status: 'timeout' }); } }
    setDevices(out); setErrs(e); setLastScan(new Date().toLocaleString('ar-EG')); setDone(true); setBusy(false);
  }
  const name = (id: string | null) => devices.find((x) => x.id === id)?.name ?? '—';
  const v = (f: (d: Device) => ReactNode) => (d: Device) => (d.status === 'offline' || d.status === 'timeout' ? '—' : f(d));
  const cols: [string, (d: Device) => ReactNode][] = [
    ['الاسم', (d) => d.name], ['IP Address', (d) => d.ip], ['MAC Address', (d) => d.mac], ['الموديل', (d) => d.model], ['إصدار airOS', (d) => d.airos],
    ['الدور', (d) => d.role], ['العلبة الأب', (d) => name(d.parentId)], ['القناة الحالية', v((d) => d.channel)], ['التردد', v((d) => `${d.freq} MHz`)],
    ['عرض القناة', v((d) => `${d.width} MHz`)], ['الإشارة', v((d) => `${d.signal} dBm`)], ['التشويش', v((d) => `${d.noise} dBm`)], ['CCQ', v((d) => `${d.ccq}%`)],
    ['AirMAX Quality', v((d) => `${d.amq}%`)], ['AirMAX Capacity', v((d) => `${d.amc}%`)], ['TX Rate', v((d) => `${d.tx} Mbps`)], ['RX Rate', v((d) => `${d.rx} Mbps`)],
    ['التنزيل', v((d) => `${d.dl} Mbps`)], ['الرفع', v((d) => `${d.ul} Mbps`)], ['Ping', v((d) => `${d.ping} ms`)], ['فقدان الحزم', v((d) => `${d.loss}%`)],
    ['Jitter', v((d) => `${d.jitter} ms`)], ['Uptime', v((d) => d.uptime)], ['عدد العملاء', v((d) => d.clients)], ['الكفاءة', v((d) => `${d.eff}%`)],
    ['التقييم', (d) => <Badge eff={d.eff} status={d.status} />],
  ];
  return (
    <>
      <h1 className="text-xl font-bold">الفحص الآمن بدون فصل</h1>
      <div className="rounded-lg bg-blue-500/20 p-3 text-sm text-blue-200">هذا فحص آمن لقراءة الحالة الحالية، ولا يختبر القنوات البديلة فعليًا.</div>
      <Btn onClick={run} disabled={busy}>{busy ? 'جارٍ الفحص...' : 'فحص آمن بدون فصل'}</Btn>
      {errs.map((e) => <div key={e} className="rounded-lg bg-red-500/20 p-2 text-sm text-red-200">{e}</div>)}
      {done && <Card><Scroll><thead><tr>{cols.map(([h]) => <Th key={h}>{h}</Th>)}</tr></thead><tbody>{devices.map((d) => <tr key={d.id}>{cols.map(([h, f]) => <Td key={h}>{f(d)}</Td>)}</tr>)}</tbody></Scroll></Card>}
    </>
  );
}
