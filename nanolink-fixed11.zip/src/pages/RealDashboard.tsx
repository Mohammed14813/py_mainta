import { useState } from 'react';
import { Btn, Card, Scroll, Td, Th } from '../components/ui';
import { AirOsSnapshot, RealConnection } from '../services/real';
import { formatUptime, parseMain, redactForSharing, signalQuality, Sourced } from '../services/airosView';
import { readFields } from '../services/fields';
import FleetTools from './FleetTools';

const NA = <span className="text-slate-500">غير متاح</span>;
function cell<T extends string | number>(field: Sourced<T>, render: (value: T) => string = String) {
  return field.value === null ? NA : <span title={`المصدر: ${field.source}`}>{render(field.value)}</span>;
}

const TONE: Record<string, string> = { good: 'bg-emerald-500/20 text-emerald-300', ok: 'bg-lime-500/20 text-lime-300', weak: 'bg-amber-500/20 text-amber-300', bad: 'bg-red-500/20 text-red-300' };
function signalCell(field: Sourced<number>) {
  if (field.value === null) return NA;
  const q = signalQuality(field.value);
  return <span title={`المصدر: ${field.source}`} className="inline-flex items-center gap-1"><b dir="ltr">{field.value} dBm</b><span className={`rounded px-1.5 py-0.5 text-[10px] ${TONE[q.tone]}`}>{q.label}</span></span>;
}

export default function RealDashboard({ connection, onDisconnect }: { connection: RealConnection; onDisconnect: () => void }) {
  const [snapshot, setSnapshot] = useState<AirOsSnapshot>(connection.initialSnapshot);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [showRaw, setShowRaw] = useState(false);
  const [redact, setRedact] = useState(true);
  const [copied, setCopied] = useState(false);
  const [tab, setTab] = useState<'main' | 'tools'>('main');
  const fields = readFields(snapshot.status);
  const main = parseMain(snapshot.status, snapshot.extraStations);
  const tally = { good: 0, ok: 0, weak: 0, bad: 0, unknown: 0 };
  main.stations.forEach((station) => { if (station.signalDbm.value === null) tally.unknown += 1; else tally[signalQuality(station.signalDbm.value).tone] += 1; });
  const weakest = main.stations.map((station) => station.signalDbm.value).filter((value): value is number => value !== null).sort((a, b) => a - b)[0];
  const rawText = JSON.stringify(redact ? redactForSharing({ publicInfo: snapshot.publicInfo, status: snapshot.status }) : { publicInfo: snapshot.publicInfo, status: snapshot.status }, null, 2);

  async function copyRaw() {
    try { await navigator.clipboard.writeText(rawText); setCopied(true); window.setTimeout(() => setCopied(false), 2000); }
    catch { setError('تعذّر النسخ تلقائيًا. حدّد النص في المربع وانسخه يدويًا.'); }
  }

  async function safeScan() {
    if (busy) return;
    setBusy(true);
    setError('');
    try { setSnapshot(await connection.readStatus()); }
    catch (reason) { setError(reason instanceof Error ? reason.message : 'تعذر قراءة الحالة الحالية.'); }
    finally { setBusy(false); }
  }

  return (
    <main className="min-h-screen bg-slate-950 p-4 text-white" dir="rtl">
      <div className="mx-auto max-w-4xl space-y-4">
        <header className="flex flex-wrap items-center justify-between gap-3">
          <div><div className="text-lg font-bold text-blue-400">NanoLink</div><h1 className="text-xl font-bold">اتصال مباشر بالعلبة</h1></div>
          <Btn kind="sec" onClick={onDisconnect}>قطع الاتصال</Btn>
        </header>
        <div className="flex gap-2">
          <button onClick={() => setTab('main')} className={`flex-1 rounded-lg px-3 py-2 text-sm ${tab === 'main' ? 'bg-blue-600' : 'bg-slate-800'}`}>العلبة الرئيسية</button>
          <button onClick={() => setTab('tools')} className={`flex-1 rounded-lg px-3 py-2 text-sm ${tab === 'tools' ? 'bg-blue-600' : 'bg-slate-800'}`}>الأدوات — Speed Test</button>
        </div>
        <div hidden={tab !== 'tools'}><FleetTools connection={connection} main={main} /></div>
        <div hidden={tab !== 'main'} className="space-y-4">
        <Card className="space-y-2">
          <div className="flex flex-wrap items-center gap-x-5 gap-y-1 text-sm">
            <span>العنوان: <b dir="ltr">{connection.ip}</b></span>
            <span>الموديل المكتشف: <b>{snapshot.model || connection.model}</b></span>
            <span>العائلة: <b>{snapshot.family || connection.family}</b></span>
            <span>إصدار النظام: <b>{snapshot.firmware || connection.firmware}</b></span>
            <span>نمط المصادقة: <b>{connection.flavor === 'v8' ? 'airOS 8 (API)' : 'airOS 5/6 (login.cgi)'}</b></span>
          </div>
          <div className="text-xs text-emerald-300">تم اجتياز تسجيل الدخول وقراءة بيانات مباشرة من الجهاز.</div>
          <div className="text-xs text-slate-400">آخر تحديث: {new Date(snapshot.readAt).toLocaleString('ar')}</div>
        </Card>
        <Card className="space-y-3">
          <h2 className="font-bold">Wireless — التردد وعرض القناة</h2>
          <div className="grid gap-2 sm:grid-cols-2">
            <div className="rounded-lg bg-slate-900 p-3"><div className="text-xs text-slate-400">التردد الحالي</div><div className="mt-1 text-lg font-semibold" dir="ltr">{cell(main.frequencyMHz, (v) => `${v} MHz`)}</div></div>
            <div className="rounded-lg bg-slate-900 p-3"><div className="text-xs text-slate-400">عرض القناة</div><div className="mt-1 text-lg font-semibold" dir="ltr">{cell(main.channelWidthMHz, (v) => `${v} MHz`)}</div></div>
          </div>
        </Card>
        {main.stations.length > 0 && <Card className="space-y-2">
          <h2 className="font-bold">جودة الربط مع كل العلب</h2>
          <div className="flex flex-wrap gap-2 text-xs">
            <span className={`rounded px-2 py-1 ${TONE.good}`}>ممتازة: {tally.good}</span>
            <span className={`rounded px-2 py-1 ${TONE.ok}`}>جيدة: {tally.ok}</span>
            <span className={`rounded px-2 py-1 ${TONE.weak}`}>ضعيفة: {tally.weak}</span>
            <span className={`rounded px-2 py-1 ${TONE.bad}`}>سيئة: {tally.bad}</span>
            {tally.unknown > 0 && <span className="rounded bg-slate-700 px-2 py-1 text-slate-300">غير متاحة: {tally.unknown}</span>}
          </div>
          {weakest !== undefined && <p className="text-xs text-slate-400">أضعف علبة: <b dir="ltr">{weakest} dBm</b> ({signalQuality(weakest).label}). التقييم من قوة الإشارة فقط؛ CCQ وTX/RX في الجدول أدناه.</p>}
        </Card>}
        <Card className="space-y-3">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <h2 className="font-bold">Main — المحطات المرتبطة{main.stationsSource ? ` (${main.stations.length})` : ''}</h2>
            {main.stationsSource && <span className="text-xs text-slate-400" dir="ltr">المصدر: {main.stationsSource}</span>}
          </div>
          {main.stations.length > 0 && <Scroll>
            <thead><tr><Th>الجهاز</Th><Th>MAC</Th><Th>IP</Th><Th>قوة الإشارة</Th><Th>Noise (dBm)</Th><Th>المسافة</Th><Th>TX</Th><Th>RX</Th><Th>CCQ</Th><Th>مدة الاتصال</Th></tr></thead>
            <tbody>{main.stations.map((station, index) => (
              <tr key={station.mac.value ?? `row-${index}`}>
                <Td>{cell(station.name)}</Td>
                <Td><span dir="ltr">{cell(station.mac)}</span></Td>
                <Td><span dir="ltr">{cell(station.ip)}</span></Td>
                <Td>{signalCell(station.signalDbm)}</Td>
                <Td>{cell(station.noiseDbm)}</Td>
                <Td>{cell(station.distance)}</Td>
                <Td>{cell(station.tx)}</Td>
                <Td>{cell(station.rx)}</Td>
                <Td>{cell(station.ccq)}</Td>
                <Td>{cell(station.uptimeSec, formatUptime)}</Td>
              </tr>))}</tbody>
          </Scroll>}
          {main.notes.map((note) => <p key={note} className="text-xs text-amber-200">{note}</p>)}
          <p className="text-xs text-slate-500">القيم تُعرض كما يعيدها الجهاز دون تحويل. وحدات المسافة وTX/RX وCCQ على هذا الإصدار لم تُؤكَّد بعد. مرّر المؤشر على أي قيمة لرؤية مسار الحقل الذي قُرئت منه.</p>
        </Card>
        <section className="grid gap-4 md:grid-cols-2">
          <Card className="space-y-3">
            <div><h2 className="font-bold">الفحص الآمن — دون فصل</h2><p className="mt-1 text-sm text-slate-300">وضع قراءة فقط: يعيد قراءة الحالة الحالية من العلبة. لا يغيّر القناة ولا الإعدادات، ويرفض التطبيق برمجيًا أي POST بعد الدخول.</p></div>
            <Btn onClick={safeScan} disabled={busy}>{busy ? 'جارٍ قراءة الحالة...' : 'فحص آمن الآن'}</Btn>
          </Card>
          <Card className="space-y-3">
            <div><h2 className="font-bold">فحص الطيف — قد يفصل الرابط اللاسلكي</h2><p className="mt-1 text-sm text-slate-300">airView في أجهزة M-series قد يوقف اتصال الواي فاي طوال الاختبار، رغم بقاء العلبة مشغّلة. لن يُشغّل هذا الفحص قبل تأكيد آلية الإيقاف واستعادة الاتصال على هذا الطراز.</p></div>
            <Btn kind="red" disabled>فحص القنوات مع فصل مؤقت — غير مفعّل بعد</Btn>
          </Card>
        </section>
        {!!snapshot.warnings?.length && <div className="rounded-lg border border-amber-500/30 bg-amber-500/10 p-3 text-xs text-amber-200">{snapshot.warnings.map((warning) => <p key={warning} dir="auto">{warning}</p>)}</div>}
        {error && <div role="alert" className="rounded-lg border border-red-500/30 bg-red-500/10 p-3 text-sm text-red-200">{error}</div>}
        <Card>
          <div className="mb-3 flex items-center justify-between gap-3"><h2 className="font-bold">البيانات التي قرأها التطبيق</h2><button className="text-xs text-blue-300 underline" onClick={() => setShowRaw((value) => !value)}>{showRaw ? 'إخفاء الاستجابة الأصلية' : 'عرض الاستجابة الأصلية للتشخيص'}</button></div>
          {fields.length ? <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">{fields.map((field) => <div key={field.label} className="rounded-lg bg-slate-900 p-3"><div className="text-xs text-slate-400">{field.label}</div><div className="mt-1 break-all text-sm font-semibold" dir="auto">{field.value}</div></div>)}</div> : <p className="text-sm text-slate-400">لم يتوفر حقل حالة معروف بعد. يمكن فتح الاستجابة الأصلية للمساعدة في توافق إصدار airOS.</p>}
          {showRaw && <div className="mt-3 space-y-2">
            <label className="flex items-center gap-2 text-xs text-slate-300"><input type="checkbox" checked={redact} onChange={(event) => setRedact(event.target.checked)} />إخفاء MAC وعناوين IP والأسماء قبل النسخ أو المشاركة</label>
            <textarea readOnly dir="ltr" value={rawText} className="h-72 w-full rounded-lg bg-slate-950 p-3 font-mono text-xs text-slate-300" />
            <Btn kind="sec" onClick={copyRaw}>{copied ? 'تم النسخ' : 'نسخ JSON'}</Btn>
          </div>}
        </Card>
        </div>
        <p className="text-center text-xs text-slate-500">بيانات الدخول تبقى في ذاكرة التطبيق مؤقتًا لإبقاء جلسة الاتصال، وتُمحى عند قطع الاتصال أو إغلاق التطبيق.</p>
      </div>
    </main>
  );
}
