import { useEffect, useMemo, useRef, useState } from 'react';
import { Btn, Card, Field, inp } from '../components/ui';
import { MainView } from '../services/airosView';
import { AUTH_LABEL, buildReport, checkUnit, CheckContext, FleetUnit, mergeUnits, readingFrom } from '../services/fleet';
import { buildCampaignReport, CampaignOutcome, runCampaign } from '../services/campaign';
import { describeUnit, findProfile, unconfirmedActions } from '../services/deviceActions';
import { RealConnection } from '../services/real';
import { formatFingerprint } from '../services/pins';
import { buildBody, learnedActions, learnWirelessForm, sanityProblem, WirelessForm } from '../services/wirelessForm';
import { discoverPaths, discoveryReport } from '../services/discovery';
import { buildRankingReport, rankUnits, sharedBest } from '../services/ranking';

const pause = (ms: number) => new Promise<void>((resolve) => setTimeout(resolve, ms));

export default function FleetTools({ connection, main }: { connection: RealConnection; main: MainView }) {
  const [units, setUnits] = useState<FleetUnit[]>([]);
  const unitsRef = useRef<FleetUnit[]>([]);
  unitsRef.current = units;
  const connections = useRef(new Map<string, RealConnection>());
  const stopFlag = useRef(false);
  const [busy, setBusy] = useState<'' | 'check' | 'read' | 'campaign' | 'discover' | 'learn'>('');
  const [progress, setProgress] = useState('');
  const [trustNew, setTrustNew] = useState(false);
  const [sameUser, setSameUser] = useState('');
  const [samePass, setSamePass] = useState('');
  const [channelsText, setChannelsText] = useState('');
  const [understood, setUnderstood] = useState(false);
  const [outcome, setOutcome] = useState<CampaignOutcome | null>(null);
  const [windowMHz, setWindowMHz] = useState('100');
  const [stepMHz, setStepMHz] = useState('20');
  const [copied, setCopied] = useState(false);
  const [discovery, setDiscovery] = useState('');
  const [learned, setLearned] = useState<{ form: WirelessForm; problem: string | null } | null>(null);
  const [learnError, setLearnError] = useState('');

  // Keep the unit list in step with the main node's station list without losing typed credentials.
  useEffect(() => { setUnits((previous) => mergeUnits(previous, main.stations)); }, [main.stations]);

  const patch = (key: string, changes: Partial<FleetUnit>) => setUnits((previous) => previous.map((unit) => (unit.key === key ? { ...unit, ...changes } : unit)));
  const ctx = (): CheckContext => ({ protocol: connection.protocol, port: String(connection.port), trustNewCerts: trustNew });

  async function checkOne(unit: FleetUnit, approvedPin = '') {
    patch(unit.key, { auth: 'checking', message: 'جارٍ الفحص…', pendingCert: undefined });
    const result = await checkUnit(unit, ctx(), approvedPin);
    if (result.connection) connections.current.set(unit.key, result.connection); else connections.current.delete(unit.key);
    patch(unit.key, { auth: result.auth, message: result.message, pendingCert: result.pendingCert, reading: result.reading });
  }

  async function checkAll() {
    if (busy) return;
    setBusy('check');
    setProgress('');
    try {
      const targets = unitsRef.current.filter((unit) => unit.listed && !unit.excluded);
      for (let index = 0; index < targets.length; index += 1) {
        setProgress(`فحص ${index + 1} من ${targets.length}: ${targets[index].name}`);
        await checkOne(targets[index]);
        await pause(300); // one unit after the other, never in parallel
      }
    } finally { setBusy(''); setProgress(''); }
  }

  async function readAll() {
    if (busy) return;
    setBusy('read');
    try {
      const targets = unitsRef.current.filter((unit) => unit.auth === 'ok' && !unit.excluded && connections.current.has(unit.key));
      for (let index = 0; index < targets.length; index += 1) {
        const unit = targets[index];
        setProgress(`قراءة ${index + 1} من ${targets.length}: ${unit.name}`);
        try {
          const snapshot = await connections.current.get(unit.key)!.readStatus();
          patch(unit.key, { reading: readingFrom(snapshot), message: 'اليوزر والباسورد صحيحان.' });
        } catch (error) {
          patch(unit.key, { message: `تعذرت القراءة: ${error instanceof Error ? error.message : String(error)}` });
        }
      }
    } finally { setBusy(''); setProgress(''); }
  }

  const excludeInvalid = () => setUnits((previous) => previous.map((unit) => (unit.auth === 'ok' ? unit : { ...unit, excluded: true })));
  const includeAll = () => setUnits((previous) => previous.map((unit) => ({ ...unit, excluded: false })));
  const fillBlanks = () => setUnits((previous) => previous.map((unit) => ({ ...unit, username: unit.username || sameUser.trim(), password: unit.password || samePass })));

  const manualChannels = useMemo(() => {
    const list = channelsText.split(/[\s,،;]+/).map(Number).filter((value) => Number.isFinite(value) && value >= 2000 && value <= 7200);
    return [...new Set(list)];
  }, [channelsText]);
  // Automatic mode: a window around the current frequency. The device itself rejects channels its country/model does not allow.
  const autoChannels = useMemo(() => {
    const centre = main.frequencyMHz.value;
    const span = Number(windowMHz);
    const step = Number(stepMHz);
    if (centre === null || !(span > 0) || !(step >= 5)) return [] as number[];
    const list: number[] = [];
    if (learned) { // the device's own allowed options, inside the window
      [...learned.form.options.keys()].sort((a, b) => a - b).forEach((f) => { if (f !== centre && Math.abs(f - centre) <= span) list.push(f); });
      return list;
    }
    for (let f = centre - span; f <= centre + span; f += step) if (f !== centre && f >= 2000 && f <= 7200) list.push(f);
    return list;
  }, [main.frequencyMHz.value, windowMHz, stepMHz, learned]);
  const channels = manualChannels.length ? manualChannels : autoChannels;
  const validUnits = units.filter((unit) => unit.auth === 'ok' && !unit.excluded && connections.current.has(unit.key));
  const combos = useMemo(() => {
    const seen = new Map<string, { text: string; supported: boolean; names: string[] }>();
    const add = (name: string, conn: RealConnection) => {
      const text = describeUnit(conn);
      const entry = seen.get(text) ?? { text, supported: findProfile(conn) !== null, names: [] };
      entry.names.push(name);
      seen.set(text, entry);
    };
    add('العلبة الرئيسية', connection);
    validUnits.forEach((unit) => add(unit.name, connections.current.get(unit.key)!));
    return [...seen.values()];
  }, [connection, validUnits.map((unit) => unit.key).join('|')]);
  const activeActions = learned && !learned.problem ? learnedActions : unconfirmedActions;
  const canRun = activeActions.available && understood && channels.length > 0 && validUnits.length > 0 && !busy;

  async function learn() {
    if (busy) return;
    setBusy('learn'); setLearnError(''); setLearned(null);
    try {
      const form = await learnWirelessForm(connection);
      setLearned({ form, problem: await sanityProblem(connection, form) });
    } catch (error) { setLearnError(error instanceof Error ? error.message : String(error)); }
    finally { setBusy(''); }
  }

  async function discover() {
    if (busy) return;
    setBusy('discover');
    setDiscovery('');
    const results = [];
    try {
      const targets: Array<[string, RealConnection]> = [['العلبة الرئيسية — ' + describeUnit(connection), connection]];
      const done = new Set([describeUnit(connection)]);
      for (const unit of validUnits) { // one representative per distinct type
        const conn = connections.current.get(unit.key)!;
        if (!done.has(describeUnit(conn))) { done.add(describeUnit(conn)); targets.push([`${unit.name} — ${describeUnit(conn)}`, conn]); }
      }
      for (const [label, conn] of targets) {
        setProgress(`قراءة صفحات ${label}…`);
        try { results.push(await discoverPaths(conn, label)); }
        catch (error) { results.push({ label, indexStatus: 0, links: [], pages: [], forms: [], notes: [error instanceof Error ? error.message : String(error)] }); }
      }
      setDiscovery(discoveryReport(results));
    } finally { setBusy(''); setProgress(''); }
  }

  async function startCampaign() {
    if (!canRun) return;
    stopFlag.current = false;
    setBusy('campaign');
    setOutcome(null);
    try {
      const result = await runCampaign({
        main: connection,
        units: validUnits.map((unit) => ({ key: unit.key, name: unit.name, connection: connections.current.get(unit.key)! })),
        channels, actions: activeActions, onProgress: setProgress, onUpdate: setOutcome, shouldStop: () => stopFlag.current,
      });
      setOutcome(result);
    } finally { setBusy(''); setProgress(''); }
  }

  const report = useMemo(
    () => buildReport(units, { frequencyMHz: main.frequencyMHz.value, widthMHz: main.channelWidthMHz.value }) + (outcome ? `\n${buildCampaignReport(outcome)}\n${buildRankingReport(outcome)}` : ''),
    [units, main.frequencyMHz.value, main.channelWidthMHz.value, outcome],
  );
  async function copyReport() {
    try { await navigator.clipboard.writeText(report); setCopied(true); window.setTimeout(() => setCopied(false), 2000); }
    catch { /* the text stays selectable in the box below */ }
  }

  const checked = units.filter((unit) => unit.auth !== 'unset' || unit.excluded);

  return (
    <div className="space-y-4">
      <Card className="space-y-3">
        <h2 className="font-bold">الأدوات ← Speed Test: العلب وبيانات دخولها</h2>
        <p className="text-xs text-slate-400">تُؤخذ العلب وعناوين IP من قائمة المحطات المرتبطة بالعلبة الرئيسية. اليوزر والباسورد يبقيان في ذاكرة التطبيق فقط ويُمحيان عند قطع الاتصال، ولا يدخلان في التقرير.</p>
        <div className="grid grid-cols-2 gap-2">
          <Field label="يوزر مشترك (اختياري)"><input className={inp} dir="ltr" autoComplete="off" value={sameUser} onChange={(event) => setSameUser(event.target.value)} /></Field>
          <Field label="باسورد مشترك (اختياري)"><input className={inp} dir="ltr" type="password" autoComplete="off" value={samePass} onChange={(event) => setSamePass(event.target.value)} /></Field>
        </div>
        <div className="flex flex-wrap gap-2">
          <Btn kind="sec" onClick={fillBlanks} disabled={!sameUser.trim() && !samePass}>تعبئة الحقول الفارغة بهما</Btn>
        </div>
        {connection.protocol === 'https' && <label className="flex items-start gap-2 text-xs text-slate-300">
          <input type="checkbox" className="mt-0.5" checked={trustNew} onChange={(event) => setTrustNew(event.target.checked)} />
          <span>اعتماد شهادة أي علبة جديدة تلقائيًا عند أول اتصال (ثقة أول استخدام). إن تُرك فارغًا تظهر لكل علبة جديدة بصمتها لتوافق عليها. الشهادة المتغيّرة عن المعتمدة سابقًا لا تُعتمد تلقائيًا أبدًا.</span>
        </label>}
      </Card>

      {units.length === 0 && <Card><p className="text-sm text-slate-300">لا توجد علب مرتبطة ظاهرة في قائمة المحطات الآن. ارجع إلى «العلبة الرئيسية» وأعد الفحص الآمن.</p></Card>}

      {units.map((unit) => {
        const label = AUTH_LABEL[unit.auth];
        return (
          <Card key={unit.key} className={`space-y-2 ${unit.excluded ? 'opacity-50' : ''}`}>
            <div className="flex flex-wrap items-start justify-between gap-2">
              <div className="min-w-0">
                <div className="font-semibold">{unit.name}{!unit.listed && <span className="mr-2 text-xs text-amber-300">(لم تعد في القائمة)</span>}</div>
                <div className="text-xs text-slate-400" dir="ltr">{unit.ip || 'IP غير متاح'} · {unit.mac || 'MAC غير متاح'}</div>
              </div>
              <span className={`rounded px-2 py-0.5 text-xs ${label.cls}`}>{unit.excluded ? 'مستبعدة' : label.text}</span>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <input className={inp} dir="ltr" placeholder="اليوزر" autoComplete="off" disabled={unit.excluded} value={unit.username} onChange={(event) => patch(unit.key, { username: event.target.value, auth: unit.auth === 'unset' ? 'unset' : 'unset', message: '' })} />
              <input className={inp} dir="ltr" type="password" placeholder="الباسورد" autoComplete="off" disabled={unit.excluded} value={unit.password} onChange={(event) => patch(unit.key, { password: event.target.value, auth: 'unset', message: '' })} />
            </div>
            {unit.message && unit.auth !== 'ok' && <p className="text-xs text-slate-300" dir="auto">{unit.message}</p>}
            {unit.auth === 'needs-cert' && unit.pendingCert && (
              <div className="space-y-2 rounded-lg bg-amber-500/10 p-2 text-xs text-amber-100">
                <div>بصمة SHA-256 للشهادة الحالية:</div>
                <div dir="ltr" className="break-all font-mono">{formatFingerprint(unit.pendingCert.sha256)}</div>
                <Btn kind={unit.pendingCert.changed ? 'red' : 'pri'} disabled={!!busy} onClick={() => { void checkOne(unit, unit.pendingCert!.sha256); }}>{unit.pendingCert.changed ? 'أثق بالشهادة الجديدة وأجرّب' : 'أثق بهذه الشهادة وأجرّب'}</Btn>
              </div>
            )}
            <label className="flex items-center gap-2 text-xs text-slate-400"><input type="checkbox" checked={unit.excluded} onChange={(event) => patch(unit.key, { excluded: event.target.checked })} />استبعاد هذه العلبة</label>
          </Card>
        );
      })}

      <Card className="space-y-3">
        <div className="flex flex-wrap gap-2">
          <Btn onClick={checkAll} disabled={!!busy || units.length === 0}>{busy === 'check' ? 'جارٍ فحص الباسوردات…' : 'فحص الباسوردات'}</Btn>
          <Btn kind="sec" onClick={excludeInvalid} disabled={!!busy || units.length === 0}>استبعاد غير الصحيحة والفارغة</Btn>
          <Btn kind="sec" onClick={includeAll} disabled={!!busy || units.length === 0}>إرجاع الكل</Btn>
        </div>
        <p className="text-xs text-slate-400">الفحص يجرّب علبة واحدة بعد الأخرى وبمحاولة واحدة لكل علبة (حتى لا يُحظر الحساب مؤقتًا بعد محاولات خاطئة متكررة). العلب بلا يوزر/باسورد لا تُجرَّب.</p>
        {progress && <p className="text-sm text-blue-300">{progress}</p>}
      </Card>

      {checked.length > 0 && (
        <Card className="space-y-2">
          <h3 className="font-bold">نتيجة فحص الباسوردات</h3>
          {checked.map((unit) => (
            <div key={unit.key} className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-700 pb-2 text-sm last:border-0">
              <div className="min-w-0"><div>{unit.name}</div><div className="text-xs text-slate-400" dir="ltr">{unit.ip || '—'} · {unit.mac || '—'}</div></div>
              <div className="flex flex-wrap items-center gap-2 text-xs"><span dir="ltr" className="text-slate-400">{unit.username || '—'}</span><span className={`rounded px-2 py-0.5 ${unit.excluded ? 'bg-slate-600/40 text-slate-300' : AUTH_LABEL[unit.auth].cls}`}>{unit.excluded ? 'مستبعدة' : AUTH_LABEL[unit.auth].text}</span></div>
            </div>
          ))}
        </Card>
      )}

      <Card className="space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <h3 className="font-bold">قراءة العلب الصحيحة (القناة الحالية)</h3>
          <Btn onClick={readAll} disabled={!!busy || validUnits.length === 0}>{busy === 'read' ? 'جارٍ القراءة…' : `قراءة ${validUnits.length} علبة`}</Btn>
        </div>
        {validUnits.map((unit) => unit.reading && (
          <div key={unit.key} className="space-y-1 rounded-lg bg-slate-900 p-3 text-sm">
            <div className="font-semibold">{unit.name}</div>
            <div className="text-xs text-slate-400" dir="ltr">{unit.reading.model} · {unit.reading.firmware} · {unit.reading.frequencyMHz ?? '—'} MHz</div>
            <div className="grid grid-cols-2 gap-x-3 gap-y-1 text-xs">
              {unit.reading.fields.map((field) => <div key={field.label} className="flex justify-between gap-2"><span className="text-slate-400">{field.label}</span><b dir="ltr" className="break-all">{field.value}</b></div>)}
            </div>
          </div>
        ))}
      </Card>

      <Card className="space-y-3 border-amber-500/40">
        <h3 className="font-bold">الفحص عبر قنوات MHz أخرى (تغيير مؤقت + Speed Test)</h3>
        {!activeActions.available && <div className="rounded-lg bg-amber-500/10 p-3 text-xs text-amber-100" dir="auto">اضغط «تعرّف تلقائيًا على تغيير القناة» أولًا. إن فشل التعرف فالسبب موضّح هناك. Speed Test نفسه غير مفعّل؛ الترتيب حسب جودة الرابط.</div>}
        <div className="space-y-1 rounded-lg bg-slate-900 p-3 text-xs">
          <div className="font-semibold">الأنواع الموجودة في شبكتك (كل نوع مختلف يحتاج سجل HAR واحد)</div>
          {combos.map((combo) => <div key={combo.text} className="flex flex-wrap items-center justify-between gap-2"><span dir="ltr" className="text-slate-300">{combo.text} <span className="text-slate-500">×{combo.names.length}</span></span><span className={`rounded px-2 py-0.5 ${combo.supported ? 'bg-emerald-500/20 text-emerald-300' : 'bg-amber-500/20 text-amber-300'}`}>{combo.supported ? 'مدعوم' : 'غير مدعوم بعد'}</span></div>)}
        </div>
        <p className="text-xs text-slate-400">الخطوات المبرمجة: حفظ القناة الأصلية ← تغيير مؤقت لكل قناة ← انتظار عودة كل العلب (مهلة تراجع) ← قراءة وSpeed Test لكل علبة صحيحة ← إرجاع القناة الأصلية والتحقق منها دائمًا، حتى عند الفشل أو الإيقاف.</p>
        <div className="grid grid-cols-2 gap-2">
          <Field label="تلقائي: نافذة ± MHz حول القناة الحالية"><input className={inp} dir="ltr" inputMode="numeric" value={windowMHz} onChange={(event) => setWindowMHz(event.target.value)} /></Field>
          <Field label="تلقائي: الخطوة MHz"><input className={inp} dir="ltr" inputMode="numeric" value={stepMHz} onChange={(event) => setStepMHz(event.target.value)} /></Field>
        </div>
        <p className="text-xs text-slate-400" dir="ltr">{manualChannels.length ? 'يدوي' : 'تلقائي'}: {channels.length ? channels.join(', ') : '—'} MHz</p>
        <div className="space-y-2 rounded-lg bg-slate-900 p-3">
          <Btn onClick={learn} disabled={!!busy}>{busy === 'learn' ? 'جارٍ التعرف…' : 'تعرّف تلقائيًا على تغيير القناة (قراءة فقط)'}</Btn>
          <p className="text-xs text-slate-400">يقرأ نموذج Wireless من الجهاز نفسه ويتحقق أن قيمه كاملة (التردد في النموذج = التردد الحقيقي). لا يرسل شيئًا في هذه الخطوة. بعد نجاحه يُفعَّل الزر أدناه، وتأتي قنوات الفحص التلقائي من خيارات الجهاز نفسه، والترتيب حسب جودة الرابط.</p>
          {learnError && <p className="text-xs text-red-300" dir="auto">{learnError}</p>}
          {learned && <div className={`rounded-lg p-2 text-xs ${learned.problem ? 'bg-red-500/10 text-red-200' : 'bg-emerald-500/10 text-emerald-200'}`} dir="auto">
            {learned.problem ?? `تم التعرف: النموذج في ${learned.form.page} ← ${learned.form.action}، حقل التردد ${learned.form.freqField}، ${learned.form.pairs.length} حقلًا سيُعاد إرسالها كما هي مع تغيير التردد فقط. القنوات المتاحة في الجهاز: ${learned.form.options.size}.`}
            {!learned.problem && (() => { const t = [...learned.form.options.keys()].find((f) => f !== learned.form.currentMHz); if (t === undefined) return null; try { const b = buildBody(learned.form, t); return <div className="mt-1" dir="ltr">معاينة: {learned.form.freqField}: {b.from} → {b.to}</div>; } catch { return null; } })()}
          </div>}
          <Btn kind="sec" onClick={discover} disabled={!!busy}>{busy === 'discover' ? 'جارٍ الاكتشاف…' : 'اكتشاف مسارات الجهاز تلقائيًا (قراءة فقط)'}</Btn>
          <p className="text-xs text-slate-400">يقرأ صفحات واجهة كل نوع (Wireless وTools) ويستخرج منها عناوين النماذج وأسماء الحقول بنفسه، دون أي كتابة على الجهاز. انسخ النتيجة وأرسلها لي بدل سجل HAR إن كان الجهاز airOS 5/6.</p>
          {discovery && <><textarea readOnly dir="ltr" value={discovery} className="h-56 w-full rounded-lg bg-slate-950 p-3 font-mono text-xs text-slate-300" /><Btn kind="sec" onClick={() => { void navigator.clipboard.writeText(discovery); }}>نسخ نتيجة الاكتشاف</Btn></>}
        </div>
        <Field label="أو حدّد القنوات يدويًا (يلغي التلقائي)"><input className={inp} dir="ltr" placeholder="5640, 5660, 5680" value={channelsText} onChange={(event) => setChannelsText(event.target.value)} /></Field>
        <label className="flex items-start gap-2 text-xs text-slate-300"><input type="checkbox" className="mt-0.5" checked={understood} onChange={(event) => setUnderstood(event.target.checked)} /><span>أفهم أن تغيير قناة العلبة الرئيسية قد يقطع العلب الفرعية مؤقتًا.</span></label>
        <div className="flex flex-wrap gap-2">
          <Btn kind="red" onClick={startCampaign} disabled={!canRun}>{busy === 'campaign' ? 'جارٍ الفحص…' : 'ابدأ الفحص عبر القنوات'}</Btn>
          {busy === 'campaign' && <Btn kind="sec" onClick={() => { stopFlag.current = true; }}>إيقاف وإرجاع القناة</Btn>}
        </div>
        {outcome && busy !== 'campaign' && <div className="rounded-lg bg-slate-900 p-3 text-xs text-slate-200" dir="auto">{outcome.aborted ?? 'اكتمل الفحص.'}</div>}
        {outcome && <RankingView outcome={outcome} />}
      </Card>

      <Card className="space-y-2">
        <div className="flex flex-wrap items-center justify-between gap-2"><h3 className="font-bold">التقرير</h3><Btn kind="sec" onClick={copyReport}>{copied ? 'تم النسخ' : 'نسخ التقرير'}</Btn></div>
        <textarea readOnly dir="auto" value={report} className="h-72 w-full rounded-lg bg-slate-950 p-3 font-mono text-xs text-slate-300" />
      </Card>
    </div>
  );
}

function RankingView({ outcome }: { outcome: CampaignOutcome }) {
  const rankings = rankUnits(outcome);
  const best = sharedBest(rankings);
  if (!rankings.length) return null;
  return (
    <div className="space-y-2">
      <h4 className="text-sm font-bold">أقوى القنوات لكل علبة (يتحدث بعد كل فحص)</h4>
      {rankings.map((unit) => (
        <div key={unit.unitKey} className="rounded-lg bg-slate-900 p-3 text-xs">
          <div className="mb-1 font-semibold text-sm">{unit.unitName} <span className="text-slate-500">({unit.ranked[0].basis === 'speed' ? 'حسب Speed Test' : 'حسب جودة الرابط'})</span></div>
          {unit.ranked.slice(0, 3).map((r, i) => <div key={r.frequencyMHz} className="flex justify-between" dir="ltr"><span>{i + 1}. {r.frequencyMHz} MHz</span><b>{r.score}</b></div>)}
        </div>
      ))}
      {best && <div className="rounded-lg bg-emerald-500/10 p-3 text-sm text-emerald-200">أفضل قناة مشتركة: <b dir="ltr">{best.frequencyMHz} MHz</b> (أسوأ ترتيب عند أي علبة: {best.worstRank})</div>}
    </div>
  );
}
