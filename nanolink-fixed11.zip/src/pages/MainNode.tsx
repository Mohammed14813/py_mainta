import { useState } from 'react';
import { useStore } from '../hooks/useStore';
import { Btn, Card, Field, inp } from '../components/ui';

export default function MainNode() {
  const { devices, setDevices } = useStore();
  const main = devices.find((d) => d.isMain)!;
  const [f, setF] = useState({ name: main.name, ip: main.ip, user: '', pass: '', model: main.model, airos: main.airos, method: 'SSH', port: '22', timeout: '10' });
  const [saved, setSaved] = useState(false);
  const set = (k: string, v: string) => setF((x) => ({ ...x, [k]: v }));
  const save = () => {
    setDevices((ds) => ds.map((d) => (d.isMain ? { ...d, name: f.name, ip: f.ip, model: f.model, airos: f.airos } : d)));
    setF((x) => ({ ...x, user: '', pass: '' })); // لا تُحفظ بيانات الدخول
    setSaved(true);
  };
  return (
    <>
      <h1 className="text-xl font-bold">العلبة الرئيسية</h1>
      <div className="rounded-lg bg-yellow-500/20 p-3 text-sm text-yellow-200">وضع المحاكاة فعال — لن يتم الاتصال بأي جهاز حقيقي.</div>
      <Card className="grid gap-3 md:grid-cols-2">
        <Field label="اسم العلبة"><input className={inp} value={f.name} onChange={(e) => set('name', e.target.value)} /></Field>
        <Field label="عنوان IP"><input className={inp} dir="ltr" value={f.ip} onChange={(e) => set('ip', e.target.value)} /></Field>
        <Field label="اسم المستخدم"><input className={inp} dir="ltr" value={f.user} onChange={(e) => set('user', e.target.value)} /></Field>
        <Field label="كلمة المرور"><input type="password" autoComplete="off" className={inp} value={f.pass} onChange={(e) => set('pass', e.target.value)} /></Field>
        <Field label="نوع الجهاز"><input className={inp} value={f.model} onChange={(e) => set('model', e.target.value)} /></Field>
        <Field label="إصدار airOS"><input className={inp} value={f.airos} onChange={(e) => set('airos', e.target.value)} /></Field>
        <Field label="طريقة الاتصال">
          <select className={inp} value={f.method} onChange={(e) => set('method', e.target.value)}><option>SSH</option><option>HTTP</option><option>HTTPS</option></select>
        </Field>
        <Field label="منفذ الاتصال"><input className={inp} dir="ltr" value={f.port} onChange={(e) => set('port', e.target.value)} /></Field>
        <Field label="مهلة الاتصال (ثانية)"><input className={inp} dir="ltr" value={f.timeout} onChange={(e) => set('timeout', e.target.value)} /></Field>
        <div className="flex items-end"><Btn onClick={save}>حفظ</Btn></div>
      </Card>
      {saved && <div className="text-sm text-emerald-300">تم الحفظ محليًا. لم تُحفظ بيانات الدخول ولم يتم الاتصال بأي جهاز.</div>}
    </>
  );
}
