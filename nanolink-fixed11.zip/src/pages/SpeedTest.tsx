import { useState } from 'react';
import { useStore } from '../hooks/useStore';
import { Btn, Card, Field, Stat, inp } from '../components/ui';
import { speedTest } from '../services/simulator';

type R = Awaited<ReturnType<typeof speedTest>>;
export default function SpeedTest() {
  const { devices } = useStore();
  const [dev, setDev] = useState(devices[1].id);
  const [r, setR] = useState<R | null>(null);
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);
  const [cfg, setCfg] = useState({ server: '192.168.88.2', user: '', pass: '', port: '5201', duration: '10', repeats: '3' });
  const set = (k: string, v: string) => setCfg((x) => ({ ...x, [k]: v }));
  async function run() {
    setBusy(true); setErr(''); setR(null);
    try { setR(await speedTest(devices.find((d) => d.id === dev)!)); } catch (e) { setErr((e as Error).message); }
    setBusy(false);
  }
  return (
    <>
      <h1 className="text-xl font-bold">اختبار السرعة</h1>
      <Card className="flex flex-wrap items-end gap-3">
        <Field label="العلبة"><select className={inp} value={dev} onChange={(e) => setDev(e.target.value)}>{devices.map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}</select></Field>
        <Field label="IP جهاز اختبار السرعة"><input className={inp} dir="ltr" value={cfg.server} onChange={(e) => set('server', e.target.value)} /></Field>
        <Field label="منفذ الاختبار"><input className={inp} dir="ltr" value={cfg.port} onChange={(e) => set('port', e.target.value)} /></Field>
        <Field label="اسم المستخدم (اختياري)"><input className={inp} dir="ltr" value={cfg.user} onChange={(e) => set('user', e.target.value)} /></Field>
        <Field label="كلمة المرور (لا تُحفظ)"><input type="password" autoComplete="off" className={inp} value={cfg.pass} onChange={(e) => set('pass', e.target.value)} /></Field>
        <Field label="مدة الاختبار (ثانية)"><input className={inp} dir="ltr" value={cfg.duration} onChange={(e) => set('duration', e.target.value)} /></Field>
        <Field label="عدد التكرارات"><input className={inp} dir="ltr" value={cfg.repeats} onChange={(e) => set('repeats', e.target.value)} /></Field>
        <Btn onClick={run} disabled={busy}>{busy ? 'جارٍ القياس...' : 'ابدأ اختبار السرعة'}</Btn>
      </Card>
      <div className="rounded-lg bg-blue-500/20 p-3 text-sm text-blue-200">في هذه النسخة لا يتم الاتصال بجهاز الاختبار فعليًا؛ الحقول للتهيئة المستقبلية، والنتائج التالية محاكاة.</div>
      {err && <div className="rounded-lg bg-red-500/20 p-3 text-sm text-red-200">{err}</div>}
      {r && (
        <>
          <div className="rounded-lg bg-yellow-500/20 p-3 text-sm text-yellow-200">النتيجة محاكاة وليست قياسًا من جهاز حقيقي.</div>
          <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
            <Stat label="Download" value={`${r.dl} Mbps`} /><Stat label="Upload" value={`${r.ul} Mbps`} />
            <Stat label="Average" value={`${r.avg} Mbps`} /><Stat label="Minimum" value={`${r.min} Mbps`} />
            <Stat label="Maximum" value={`${r.max} Mbps`} /><Stat label="Ping" value={`${r.ping} ms`} />
            <Stat label="Packet Loss" value={`${r.loss}%`} /><Stat label="Jitter" value={`${r.jitter} ms`} />
          </div>
          <Card className="space-y-2 text-sm">
            <div><b>TX/RX Radio Rate:</b> {r.tx} / {r.rx} Mbps — سرعة الربط اللاسلكي النظرية، وليست سرعة فعلية.</div>
            <div><b>Throughput الفعلي:</b> {r.dl} / {r.ul} Mbps — ما ينقله الرابط فعليًا.</div>
            <div><b>سرعة الإنترنت:</b> {Math.min(r.dl, r.ul + 5).toFixed(1)} Mbps تقريبًا — تعتمد أيضًا على خط الإنترنت نفسه.</div>
          </Card>
        </>
      )}
    </>
  );
}
