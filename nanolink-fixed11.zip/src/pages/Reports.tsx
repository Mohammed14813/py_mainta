import { useState } from 'react';
import { useStore } from '../hooks/useStore';
import { Btn, Card } from '../components/ui';
import ResultsTable from '../components/ResultsTable';
import { bestShared, download } from '../utils/format';

export default function Reports() {
  const { runs } = useStore();
  const [msg, setMsg] = useState('');
  const csv = () => {
    const h = 'device,start,end,channel,freq,eff,dl,ul,signal,noise,ccq,tx,rx,ping,loss,jitter';
    const rows = runs.flatMap((r) => r.results.map((x) => [r.deviceName, r.start, r.end, x.channel, x.freq, x.eff, x.dl, x.ul, x.signal, x.noise, x.ccq, x.tx, x.rx, x.ping, x.loss, x.jitter].join(',')));
    download('nanolink-report.csv', [h, ...rows].join('\n'), 'text/csv');
  };
  const shared = bestShared(runs);
  const printPdf = () => window.print();
  return (
    <>
      <h1 className="text-xl font-bold">التقارير</h1>
      <div className="flex flex-wrap gap-2">
        <Btn onClick={csv} disabled={!runs.length}>تصدير CSV</Btn>
        <Btn onClick={() => download('nanolink-report.json', JSON.stringify(runs, null, 2), 'application/json')} disabled={!runs.length}>تصدير JSON</Btn>
        <Btn kind="sec" onClick={printPdf} disabled={!runs.length}>طباعة / حفظ PDF</Btn>
      </div>
      {msg && <div className="rounded-lg bg-yellow-500/20 p-3 text-sm text-yellow-200">{msg}</div>}
      {shared && <div className="text-sm">أفضل قناة مشتركة محافظة: <b>{shared.channel}</b> — كفاءة الحد الأدنى {shared.eff}%، تنزيل {shared.dl} Mbps، رفع {shared.ul} Mbps.</div>}
      {!runs.length && <Card className="text-sm text-slate-300">لا توجد تقارير بعد. شغّل «اختبار القنوات مع فصل مؤقت» لإنشاء تقرير.</Card>}
      {runs.map((r) => (
        <div key={r.id} className="space-y-3">
          <Card className="text-sm">
            <b>{r.deviceName}</b> — القنوات المختبرة: {r.results.length}
            <div className="text-slate-400">البداية: {new Date(r.start).toLocaleString('ar-EG')} | النهاية: {new Date(r.end).toLocaleString('ar-EG')}</div>
            {r.errors.length > 0 && <div className="mt-1 text-red-300">الأخطاء: {r.errors.join(' ؛ ')}</div>}
          </Card>
          <ResultsTable results={r.results} />
        </div>
      ))}
    </>
  );
}
