import { FormEvent, useState } from 'react';
import { Btn, Card, Field, inp } from '../components/ui';
import { CertificateInfo, connectReal, ConnectInput, DeviceProtocol, probeDeviceCertificate, RealConnection } from '../services/real';
import { formatFingerprint, getPin, savePin } from '../services/pins';

interface PendingCertificate { input: ConnectInput; info: CertificateInfo; previous: string; }

export default function Connect({ onConnected }: { onConnected: (connection: RealConnection) => void }) {
  const [ip, setIp] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [protocol, setProtocol] = useState<DeviceProtocol>('https');
  const [port, setPort] = useState('443');
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [pending, setPending] = useState<PendingCertificate | null>(null);
  async function finishConnection(input: ConnectInput, tlsPin = '') {
    const connection = await connectReal(input, tlsPin);
    // The fingerprint is remembered only after a successful login, so a wrong password never "approves" a device.
    if (tlsPin) savePin(input.ip, input.port, tlsPin);
    setPassword('');
    setPending(null);
    onConnected(connection);
  }

  async function submit(event: FormEvent) {
    event.preventDefault();
    if (busy) return;
    setBusy(true);
    setError('');
    const input: ConnectInput = { ip: ip.trim(), username: username.trim(), password, protocol, port };
    try {
      if (protocol === 'https') {
        const info = await probeDeviceCertificate(input);
        const saved = getPin(input.ip, input.port);
        if (saved === info.sha256.toUpperCase()) await finishConnection(input, info.sha256);
        else setPending({ input, info, previous: saved }); // first contact, or the certificate changed: ask the user
      } else {
        await finishConnection(input);
      }
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : 'تعذر الاتصال. تحقق من بيانات الجهاز والشبكة.');
    } finally {
      setBusy(false);
    }
  }

  async function approveCertificate() {
    if (!pending || busy) return;
    setBusy(true);
    setError('');
    try { await finishConnection(pending.input, pending.info.sha256); }
    catch (reason) {
      setPending(null);
      setError(reason instanceof Error ? reason.message : 'تعذر الاتصال. تحقق من بيانات الجهاز والشبكة.');
    } finally { setBusy(false); }
  }

  if (pending) {
    const changed = pending.previous !== '';
    return (
      <main className="flex min-h-screen items-center justify-center bg-slate-950 p-4" dir="rtl">
        <section className="w-full max-w-md space-y-4">
          <div className="text-center">
            <div className="text-2xl font-bold text-blue-400">NanoLink</div>
            <h1 className="mt-2 text-xl font-bold">{changed ? 'تغيّرت شهادة العلبة' : 'تأكيد شهادة العلبة'}</h1>
          </div>
          <Card className="space-y-3">
            <p className={`rounded-lg p-3 text-sm ${changed ? 'bg-red-500/10 text-red-200' : 'bg-amber-500/10 text-amber-200'}`}>
              {changed
                ? 'الشهادة التي تعرضها العلبة الآن تختلف عن الشهادة التي وافقت عليها سابقًا. قد يكون السبب إعادة ضبط الجهاز أو تحديث نظامه، وقد يكون جهازًا آخر يتظاهر بأنه العلبة. لم تُرسل أي بيانات دخول بعد.'
                : 'العلبة تستخدم شهادة ذاتية التوقيع لا يمكن التحقق منها عبر جهة شهادات. قارن البصمة أدناه مع الظاهرة في واجهة الجهاز إن أمكن، ثم وافق. لم تُرسل أي بيانات دخول بعد.'}
            </p>
            <div>
              <div className="text-xs text-slate-400">بصمة SHA-256 للشهادة الحالية</div>
              <div dir="ltr" className="mt-1 break-all rounded-lg bg-slate-900 p-2 font-mono text-xs">{formatFingerprint(pending.info.sha256)}</div>
            </div>
            {changed && <div>
              <div className="text-xs text-slate-400">البصمة التي وافقت عليها سابقًا</div>
              <div dir="ltr" className="mt-1 break-all rounded-lg bg-slate-900 p-2 font-mono text-xs text-slate-300">{formatFingerprint(pending.previous)}</div>
            </div>}
            <dl className="space-y-1 text-xs text-slate-300">
              <div className="flex gap-2"><dt className="text-slate-400">الموضوع:</dt><dd dir="ltr" className="break-all">{pending.info.subject}</dd></div>
              <div className="flex gap-2"><dt className="text-slate-400">الجهة المصدِرة:</dt><dd dir="ltr" className="break-all">{pending.info.issuer}</dd></div>
              <div className="flex gap-2"><dt className="text-slate-400">صالحة حتى:</dt><dd dir="ltr">{pending.info.validUntil}</dd></div>
            </dl>
            <div className="flex flex-wrap gap-2">
              <Btn kind={changed ? 'red' : 'pri'} onClick={approveCertificate} disabled={busy}>{busy ? 'جارٍ تسجيل الدخول...' : changed ? 'أثق بالشهادة الجديدة وأتابع' : 'أثق بهذه الشهادة وأتابع'}</Btn>
              <Btn kind="sec" onClick={() => setPending(null)} disabled={busy}>إلغاء</Btn>
            </div>
          </Card>
        </section>
      </main>
    );
  }

  return (
    <main className="flex min-h-screen items-center justify-center bg-slate-950 p-4" dir="rtl">
      <section className="w-full max-w-md space-y-4">
        <div className="text-center">
          <div className="text-2xl font-bold text-blue-400">NanoLink</div>
          <h1 className="mt-2 text-xl font-bold">الاتصال بعلبة الشبكة</h1>
          <p className="mt-2 text-sm text-slate-300">أدخل بيانات العلبة التي تملك صلاحية إدارتها. سيقرأ التطبيق معلوماتها بعد نجاح المصادقة.</p>
        </div>
        <Card>
          <form className="space-y-4" onSubmit={submit}>
            <Field label="عنوان IP للعلبة">
              <input autoFocus required inputMode="decimal" autoComplete="off" className={inp} dir="ltr" placeholder="192.168.1.20" value={ip} onChange={(event) => setIp(event.target.value)} />
            </Field>
            <Field label="اسم المستخدم">
              <input required autoComplete="username" className={inp} dir="ltr" value={username} onChange={(event) => setUsername(event.target.value)} />
            </Field>
            <Field label="كلمة المرور">
              <input required type="password" autoComplete="current-password" className={inp} dir="ltr" value={password} onChange={(event) => setPassword(event.target.value)} />
            </Field>
            <button type="button" className="text-sm text-blue-300 underline" onClick={() => setShowAdvanced((value) => !value)}>
              {showAdvanced ? 'إخفاء إعدادات الاتصال' : 'إعدادات الاتصال المتقدمة'}
            </button>
            {showAdvanced && <div className="grid grid-cols-2 gap-3">
              <Field label="البروتوكول">
                <select className={inp} value={protocol} onChange={(event) => { const value = event.target.value as DeviceProtocol; setProtocol(value); setPort(value === 'https' ? '443' : '80'); }}>
                  <option value="https">HTTPS — مشفر</option>
                  <option value="http">HTTP — غير مشفر</option>
                </select>
              </Field>
              <Field label="المنفذ">
                <input required inputMode="numeric" className={inp} dir="ltr" value={port} onChange={(event) => setPort(event.target.value)} />
              </Field>
              {protocol === 'http' && <p className="col-span-2 rounded-lg bg-amber-500/10 p-2 text-xs text-amber-200">تنبيه: HTTP يرسل بيانات الدخول دون تشفير. استخدمه فقط على شبكة موثوقة، وفضّل HTTPS متى أمكن.</p>}
            </div>}
            {error && <div role="alert" className="rounded-lg border border-red-500/30 bg-red-500/10 p-3 text-sm text-red-200">{error}</div>}
            <Btn disabled={busy}>{busy ? 'جارٍ التحقق من الجهاز...' : 'اتصال وفحص الدخول'}</Btn>
          </form>
        </Card>
        <p className="text-center text-xs text-slate-500">كلمة المرور لا تُرسل إلى خدمة خارجية ولا تُحفظ في التخزين الدائم. شهادة العلبة ذاتية التوقيع، فيعرض التطبيق بصمتها لتوافق عليها عند أول اتصال ثم يتحقق من تطابقها في كل اتصال لاحق؛ ولا يعطّل التحقق من الشهادات لأي اتصال آخر.</p>
      </section>
    </main>
  );
}
