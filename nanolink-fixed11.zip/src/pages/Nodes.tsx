import { useState } from 'react';
import { useStore } from '../hooks/useStore';
import { Badge, Btn, Card, Field, inp } from '../components/ui';
import { Role } from '../types';
import { scan, synth } from '../services/simulator';
import { statusLabel } from '../utils/format';

const empty = { name: '', ip: '', user: '', pass: '', parentId: 'main', role: 'Station' as Role, model: 'NanoStation 5AC Loco', notes: '' };

export default function Nodes() {
  const { devices, setDevices } = useStore();
  const [f, setF] = useState(empty);
  const [edit, setEdit] = useState<string | null>(null);
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState('');
  const set = (k: string, v: string) => setF((x) => ({ ...x, [k]: v }));

  function save() {
    if (!f.name || !/^\d{1,3}(\.\d{1,3}){3}$/.test(f.ip)) { setErr('أدخل اسمًا وعنوان IP صحيحًا.'); return; }
    if (edit) {
      setDevices((ds) => ds.map((d) => (d.id === edit ? { ...d, name: f.name, ip: f.ip, parentId: f.parentId, role: f.role, model: f.model, notes: f.notes } : d)));
    } else {
      const q = 70;
      const hex = Math.floor(Math.random() * 255).toString(16).padStart(2, '0').toUpperCase();
      setDevices((ds) => [...ds, { id: 'n' + Date.now(), name: f.name, ip: f.ip, mac: '02:00:00:00:00:' + hex, model: f.model, airos: '8.7.11', role: f.role, parentId: f.parentId, notes: f.notes, status: 'connected', q, uptime: '0 يوم', clients: 0, ...synth(q, 36, 0) }]);
    }
    setF(empty); setEdit(null); setErr('');
  }
  async function doScan(id: string) {
    const d = devices.find((x) => x.id === id)!;
    setBusy(id); setErr('');
    try { const r = await scan(d); setDevices((ds) => ds.map((x) => (x.id === id ? r : x))); }
    catch (e) { setErr((e as Error).message); setDevices((ds) => ds.map((x) => (x.id === id ? { ...x, status: 'timeout' } : x))); }
    setBusy('');
  }
  const remove = (id: string) => setDevices((ds) => { const p = ds.find((x) => x.id === id)?.parentId ?? null; return ds.filter((x) => x.id !== id).map((x) => (x.parentId === id ? { ...x, parentId: p } : x)); });

  return (
    <>
      <h1 className="text-xl font-bold">العلب المرتبطة</h1>
      <Card className="grid gap-3 md:grid-cols-2">
        <Field label="اسم الفرع"><input className={inp} value={f.name} onChange={(e) => set('name', e.target.value)} /></Field>
        <Field label="عنوان IP"><input className={inp} dir="ltr" value={f.ip} onChange={(e) => set('ip', e.target.value)} /></Field>
        <Field label="اسم المستخدم"><input className={inp} dir="ltr" value={f.user} onChange={(e) => set('user', e.target.value)} /></Field>
        <Field label="كلمة المرور"><input type="password" autoComplete="off" className={inp} value={f.pass} onChange={(e) => set('pass', e.target.value)} /></Field>
        <Field label="العلبة الأب">
          <select className={inp} value={f.parentId} onChange={(e) => set('parentId', e.target.value)}>{devices.filter((d) => d.id !== edit).map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}</select>
        </Field>
        <Field label="الدور">
          <select className={inp} value={f.role} onChange={(e) => set('role', e.target.value)}><option>Access Point</option><option>Station</option><option>Repeater</option></select>
        </Field>
        <Field label="الموديل"><input className={inp} value={f.model} onChange={(e) => set('model', e.target.value)} /></Field>
        <Field label="ملاحظات"><input className={inp} value={f.notes} onChange={(e) => set('notes', e.target.value)} /></Field>
        <div className="flex gap-2"><Btn onClick={save}>{edit ? 'حفظ التعديل' : 'إضافة فرع'}</Btn>{edit && <Btn kind="sec" onClick={() => { setEdit(null); setF(empty); }}>إلغاء</Btn>}</div>
      </Card>
      {err && <div className="rounded-lg bg-red-500/20 p-3 text-sm text-red-200">{err}</div>}
      <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
        {devices.filter((d) => !d.isMain).map((d) => (
          <Card key={d.id} className="space-y-1 text-sm">
            <div className="flex items-center justify-between"><b>{d.name}</b><Badge eff={d.eff} status={d.status} /></div>
            <div>IP: <span dir="ltr">{d.ip}</span></div>
            <div>MAC: <span dir="ltr">{d.mac}</span></div>
            <div>الموديل: {d.model}</div>
            <div>الدور: {d.role}</div>
            <div>حالة الاتصال: {statusLabel[d.status]}</div>
            <div>القناة الحالية: {d.status === 'offline' ? '—' : d.channel}</div>
            <div>الكفاءة: {d.status === 'offline' ? '—' : `${d.eff}%`}</div>
            <div className="flex gap-2 pt-2">
              <Btn onClick={() => doScan(d.id)} disabled={busy === d.id}>{busy === d.id ? '...' : 'فحص'}</Btn>
              <Btn kind="sec" onClick={() => { setEdit(d.id); setF({ ...empty, name: d.name, ip: d.ip, parentId: d.parentId ?? 'main', role: d.role, model: d.model, notes: d.notes }); }}>تعديل</Btn>
              <Btn kind="red" onClick={() => remove(d.id)}>حذف</Btn>
            </div>
          </Card>
        ))}
      </div>
    </>
  );
}
