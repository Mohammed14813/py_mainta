import { useStore } from '../hooks/useStore';
import { Badge, Card } from '../components/ui';
import { Device } from '../types';

function Node({ d, all }: { d: Device; all: Device[] }) {
  const kids = all.filter((x) => x.parentId === d.id);
  return (
    <div>
      <div className="flex flex-wrap items-center gap-2 rounded-lg bg-slate-900 p-2 text-sm">
        <b>{d.isMain ? 'العلبة الرئيسية' : `الفرع: ${d.name}`}</b>
        <span className="text-slate-400" dir="ltr">{d.ip}</span>
        <span className="text-slate-400">{d.role}</span>
        <Badge eff={d.eff} status={d.status} />
      </div>
      {kids.length > 0 && <div className="mr-4 mt-2 space-y-2 border-r-2 border-slate-600 pr-3">{kids.map((k) => <Node key={k.id} d={k} all={all} />)}</div>}
    </div>
  );
}
export default function Tree() {
  const { devices } = useStore();
  return (
    <>
      <h1 className="text-xl font-bold">شجرة الشبكة</h1>
      <Card>{devices.filter((d) => d.parentId === null).map((d) => <Node key={d.id} d={d} all={devices} />)}</Card>
    </>
  );
}
