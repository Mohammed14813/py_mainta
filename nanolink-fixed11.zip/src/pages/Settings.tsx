import { Btn, Card } from '../components/ui';
import { useStore } from '../hooks/useStore';

export default function Settings() {
  const { sim } = useStore();
  return (
    <>
      <h1 className="text-xl font-bold">الإعدادات</h1>
      <Card className="space-y-2 text-sm">
        <div>وضع المحاكاة: <b className="text-yellow-300">{sim ? 'مفعّل' : 'معطّل'}</b></div>
        <div className="text-slate-300">لا يوجد اتصال بأي جهاز حقيقي، ولا تُحفظ كلمات المرور، ولا تُرسل بيانات إلى خدمات خارجية.</div>
        <div className="text-slate-300">تكامل NanoStation الحقيقي سيضاف لاحقًا بعد معرفة الموديلات وإصدار airOS.</div>
        <div className="rounded-lg border border-yellow-500/40 bg-yellow-500/10 p-3 text-yellow-200">تطبيق القناة الحقيقي مقفل حاليًا للحماية. نتائج الاختبار والتوصيات لا تغيّر أي إعداد.</div>
        <Btn disabled>Apply — غير متاح في وضع المحاكاة</Btn>
      </Card>
    </>
  );
}
