import { useStore } from '../hooks/useStore';
import { Stat } from '../components/ui';

export default function Dashboard() {
  const { devices, sim, lastScan } = useStore();
  const live = devices.filter((d) => d.status === 'connected' || d.status === 'problem');
  const eff = live.length ? Math.round(live.reduce((s, d) => s + d.eff, 0) / live.length) : 0;
  const main = devices.find((d) => d.isMain);
  return (
    <>
      <h1 className="text-xl font-bold">لوحة التحكم</h1>
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Stat label="عدد العلب الكلي" value={devices.length} />
        <Stat label="العلب المتصلة" value={devices.filter((d) => d.status === 'connected').length} color="text-emerald-400" />
        <Stat label="العلب التي بها مشكلة" value={devices.filter((d) => d.status !== 'connected').length} color="text-red-400" />
        <Stat label="الكفاءة العامة" value={`${eff}%`} color="text-blue-400" />
        <Stat label="القناة الحالية" value={main ? `${main.channel} (${main.freq} MHz)` : '—'} />
        <Stat label="آخر فحص" value={<span className="text-base">{lastScan}</span>} />
        <Stat label="وضع المحاكاة" value={sim ? 'فعال' : 'معطّل'} color="text-yellow-300" />
      </div>
    </>
  );
}
