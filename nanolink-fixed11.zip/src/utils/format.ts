import { Run, Status } from '../types';
export const rating = (e: number, s?: Status) => {
  if (s === 'offline') return { label: 'فقدان اتصال', cls: 'bg-red-500/20 text-red-300' };
  if (s === 'timeout') return { label: 'Timeout', cls: 'bg-red-500/20 text-red-300' };
  if (e >= 85) return { label: 'ممتاز', cls: 'bg-emerald-500/20 text-emerald-300' };
  if (e >= 70) return { label: 'جيد', cls: 'bg-blue-500/20 text-blue-300' };
  if (e >= 50) return { label: 'متوسط', cls: 'bg-yellow-500/20 text-yellow-300' };
  return { label: 'ضعيف', cls: 'bg-red-500/20 text-red-300' };
};
export const statusLabel: Record<Status, string> = { connected: 'متصل', problem: 'مشكلة', offline: 'فقدان اتصال', timeout: 'Timeout' };
export const sleep = (ms: number) => new Promise<void>((r) => setTimeout(r, ms));
export function download(name: string, text: string, mime: string) {
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob(['\ufeff' + text], { type: mime }));
  a.download = name; a.click(); URL.revokeObjectURL(a.href);
}
export function bestShared(runs: Run[]): { channel: number; eff: number; dl: number; ul: number; ping: number; loss: number; score: number } | null {
  type Series = { eff: number[]; dl: number[]; ul: number[]; ping: number[]; loss: number[] };
  const m = new Map<number, Series>();
  runs.forEach((r) => r.results.forEach((x) => {
    const current = m.get(x.channel) ?? { eff: [], dl: [], ul: [], ping: [], loss: [] };
    current.eff.push(x.eff); current.dl.push(x.dl); current.ul.push(x.ul); current.ping.push(x.ping); current.loss.push(x.loss);
    m.set(x.channel, current);
  }));
  const score = (x: Series) => {
    const eff = Math.min(...x.eff);
    const dl = Math.min(...x.dl);
    const ul = Math.min(...x.ul);
    const ping = Math.max(...x.ping);
    const loss = Math.max(...x.loss);
    return eff * 0.55 + Math.min(100, dl) * 0.2 + Math.min(100, ul) * 0.15 + Math.max(0, 10 - ping) * 0.8 - loss * 2;
  };
  let best: { channel: number; eff: number; dl: number; ul: number; ping: number; loss: number; score: number } | null = null;
  for (const [channel, x] of m.entries()) {
    const candidate = { channel, eff: Math.round(Math.min(...x.eff)), dl: Math.round(Math.min(...x.dl)), ul: Math.round(Math.min(...x.ul)), ping: Math.round(Math.max(...x.ping)), loss: +Math.max(...x.loss).toFixed(1), score: score(x) };
    if (!best || candidate.score > best.score) best = candidate;
  }
  return best;
}
