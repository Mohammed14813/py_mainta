import { createContext, useContext, useState, ReactNode, Dispatch, SetStateAction } from 'react';
import { Device, Run } from '../types';
import { MOCK } from '../mock/devices';

interface S {
  devices: Device[]; setDevices: Dispatch<SetStateAction<Device[]>>;
  runs: Run[]; addRun: (r: Run) => void;
  sim: boolean; setSim: (b: boolean) => void;
  lastScan: string; setLastScan: (s: string) => void;
}
const Ctx = createContext<S>(null as unknown as S);
export const useStore = () => useContext(Ctx);

export function StoreProvider({ children }: { children: ReactNode }) {
  const [devices, setDevices] = useState<Device[]>(MOCK);
  const [runs, setRuns] = useState<Run[]>([]);
  const [sim, setSim] = useState(true);
  const [lastScan, setLastScan] = useState('—');
  return <Ctx.Provider value={{ devices, setDevices, runs, addRun: (r) => setRuns((x) => [r, ...x]), sim, setSim, lastScan, setLastScan }}>{children}</Ctx.Provider>;
}
