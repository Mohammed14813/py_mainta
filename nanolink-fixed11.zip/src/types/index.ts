export type Role = 'Access Point' | 'Station' | 'Repeater';
export type Status = 'connected' | 'problem' | 'offline' | 'timeout';
export type PageId = 'dashboard' | 'main' | 'nodes' | 'tree' | 'safe' | 'test' | 'speed' | 'reports' | 'settings';
export interface Radio { channel: number; freq: number; width: number; signal: number; noise: number; ccq: number; amq: number; amc: number; tx: number; rx: number; dl: number; ul: number; ping: number; loss: number; jitter: number; eff: number; }
export interface Metrics extends Radio { uptime: string; clients: number; }
export interface Device extends Metrics { id: string; name: string; ip: string; mac: string; model: string; airos: string; role: Role; parentId: string | null; notes: string; status: Status; isMain?: boolean; q: number; }
export interface ChannelResult { channel: number; freq: number; eff: number; dl: number; ul: number; signal: number; noise: number; ccq: number; tx: number; rx: number; ping: number; loss: number; jitter: number; status: Status; }
export interface Run { id: string; deviceId: string; deviceName: string; start: string; end: string; results: ChannelResult[]; errors: string[]; }
