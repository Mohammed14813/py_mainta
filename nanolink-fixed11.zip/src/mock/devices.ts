import { Device, Role, Status } from '../types';
import { synth } from '../services/simulator';

function mk(id: string, name: string, ip: string, model: string, role: Role, parentId: string | null, status: Status, q: number, channel: number, clients: number, mac: string, isMain = false): Device {
  return { id, name, ip, mac: 'F0:9F:C2:1A:2B:' + mac, model, airos: '8.7.11', role, parentId, notes: '', status, q, isMain, clients, uptime: `${(q % 20) + 1} يوم ${q % 24} ساعة`, ...synth(q, channel, 0) };
}
export const MOCK: Device[] = [
  mk('main', 'العلبة الرئيسية', '192.168.88.2', 'NanoStation 5AC Loco', 'Access Point', null, 'connected', 92, 36, 6, '01', true),
  mk('n1', 'Nano-01', '192.168.88.11', 'NanoStation 5AC Loco', 'Station', 'main', 'connected', 88, 36, 1, '11'),
  mk('n2', 'Nano-02', '192.168.88.12', 'NanoStation M5', 'Repeater', 'n1', 'connected', 74, 40, 3, '12'),
  mk('n3', 'Nano-03', '192.168.88.13', 'NanoStation M5', 'Station', 'n2', 'problem', 42, 44, 1, '13'),
  mk('n4', 'Nano-04', '192.168.88.14', 'NanoStation 5AC Loco', 'Repeater', 'main', 'connected', 81, 149, 4, '14'),
  mk('n5', 'Nano-05', '192.168.88.15', 'NanoStation M5', 'Station', 'n4', 'problem', 35, 157, 1, '15'),
  mk('n6', 'Nano-06', '192.168.88.16', 'NanoStation M5', 'Station', 'main', 'offline', 0, 36, 0, '16'),
  mk('n7', 'Nano-07', '192.168.88.17', 'NanoStation 5AC Loco', 'Station', 'n4', 'timeout', 60, 153, 0, '17'),
];
