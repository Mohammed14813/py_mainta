export default {
  logoUrl: "https://cdn.simpleicons.org/ubiquiti"
};
