export interface SpeedResult {
  /** Exactly what the device's Speed Test tool displayed, label → value. Nothing is computed or converted. */
  values: Array<{ label: string; value: string }>;
}
export interface SpeedTarget { ip: string; username: string; password: string; port: string; }

/** The device's own channel list does not offer this frequency. Nothing was changed on the device. */
export class ChannelNotAllowed extends Error {
  constructor(message: string) { super(message); this.name = 'ChannelNotAllowed'; }
}
/** kind: credentials = the tool said the login was refused; unreachable = it could not reach the unit; other = anything else. */
export class SpeedTestError extends Error {
  constructor(readonly kind: 'credentials' | 'unreachable' | 'other', message: string) { super(message); this.name = 'SpeedTestError'; }
}
