// Read-only discovery of the device's OWN web UI: which pages exist and which forms (target URL + field names)
// the Wireless / Tools pages use. Nothing is written. Values are never copied except an allow-list of
// radio-setting names, and anything that looks like a secret or identity is dropped.
import type { RealConnection } from './real';

export interface FormInfo { page: string; action: string; method: string; fields: Array<{ name: string; type: string; value?: string }>; selects: Array<{ name: string; options: string[] }>; }
export interface DiscoveryResult { label: string; indexStatus: number; links: string[]; pages: Array<{ path: string; status: number }>; forms: FormInfo[]; controls: Array<{ path: string; items: string[] }>; scriptHints: string[]; code: Array<{ source: string; text: string }>; notes: string[]; }

const INTEREST = /wireless|wlan|wifi|speed|ping|tool|ptest|link|channel|radio|config/i;
/** Pages that CHANGE the device when merely opened (apply.cgi commits pending config). Never fetched. */
export const NEVER_OPEN = /airview|survey|align|discover|apply|discard|reboot|reset|restart|upgrade|firmware|fwupdate|logout|kick|default|cfg|backup|delete|remove|signal-?test|ping.?test.*action/i;
const SECRET_NAME = /pass|pwd|key|psk|wpa|secret|token|user|login|serial|mac|ssid|essid|name/i;
const SAFE_VALUE_NAME = /freq|chan|width|bw|country|mode|ieee|dfs/i;
const PATH = /^\/?[A-Za-z0-9_\-./]+\.(?:cgi|php|html?|asp)(?:\?[A-Za-z0-9_=&.\-]*)?$/i;

const normalise = (href: string): string | null => {
  const clean = href.trim().replace(/^https?:\/\/[^/]+/i, '').replace(/^\.\//, '');
  if (!clean || clean.startsWith('#') || /^(javascript|mailto):/i.test(clean) || !PATH.test(clean)) return null;
  return clean.startsWith('/') ? clean : `/${clean}`;
};

function collectLinks(html: string, doc: Document): string[] {
  const found = new Set<string>();
  doc.querySelectorAll('a[href],iframe[src],frame[src]').forEach((element) => {
    const path = normalise(element.getAttribute('href') ?? element.getAttribute('src') ?? '');
    if (path) found.add(path);
  });
  for (const match of html.matchAll(/["']([A-Za-z0-9_\-./]+\.cgi(?:\?[A-Za-z0-9_=&.\-]*)?)["']/g)) { const path = normalise(match[1]); if (path) found.add(path); }
  return [...found];
}

function collectForms(page: string, doc: Document): FormInfo[] {
  return [...doc.querySelectorAll('form')].map((form) => ({
    page, action: form.getAttribute('action') || page, method: (form.getAttribute('method') || 'GET').toUpperCase(),
    fields: [...form.querySelectorAll('input,textarea')].filter((el) => el.getAttribute('name')).map((el) => {
      const name = el.getAttribute('name') as string;
      const type = (el.getAttribute('type') || 'text').toLowerCase();
      const showValue = type !== 'password' && !SECRET_NAME.test(name.replace(SAFE_VALUE_NAME, '')) && SAFE_VALUE_NAME.test(name);
      return { name, type, value: showValue ? el.getAttribute('value') ?? undefined : undefined };
    }),
    selects: [...form.querySelectorAll('select')].filter((el) => el.getAttribute('name')).map((el) => ({
      name: el.getAttribute('name') as string,
      options: SAFE_VALUE_NAME.test(el.getAttribute('name') as string) ? [...el.querySelectorAll('option')].map((o) => o.getAttribute('value') ?? '').slice(0, 60) : [],
    })),
  }));
}

/** Field/button ids and names of a page (Speed Test is often AJAX with no <form>). Names only, never values. */
function collectControls(doc: Document): string[] {
  return [...doc.querySelectorAll('input,select,button,textarea')].slice(0, 80).map((el) => {
    const tag = el.tagName.toLowerCase();
    const bits = [tag, el.getAttribute('id') ? `#${el.getAttribute('id')}` : '', el.getAttribute('name') ? `[name=${el.getAttribute('name')}]` : '', el.getAttribute('type') ? `[${el.getAttribute('type')}]` : ''];
    if (tag === 'button' || el.getAttribute('type') === 'button') bits.push(`"${(el.textContent || el.getAttribute('value') || '').trim().slice(0, 20)}"`);
    return bits.join('');
  }).filter((text) => text.length > 6);
}

const LIB_SCRIPT = /jquery|jqplot|flot|highcharts|chart|d3|moment|bootstrap/i;
const JS_URL = /["'`]([A-Za-z0-9_\-./]+\.cgi[^"'`\s]{0,60})["'`]/g;
const JS_CALL = /(\$\.(?:ajax|post|get|getJSON)|XMLHttpRequest|fetch)\s*\(/g;

/** Reads the page's inline scripts and its own (same-origin, non-library) .js files for endpoint hints. Read only. */
async function scanScripts(connection: RealConnection, page: string, html: string, doc: Document, result: DiscoveryResult): Promise<void> {
  if (!/speed|tool|ptest|wireless|link|index/i.test(page)) return;
  const sources: Array<[string, string]> = [[page + ' (inline)', [...doc.querySelectorAll('script:not([src])')].map((e) => e.textContent ?? '').join('\n')]];
  const srcs = [...doc.querySelectorAll('script[src]')].map((e) => normalise(e.getAttribute('src') ?? '') ?? (/^\/?[A-Za-z0-9_\-./]+\.js$/i.test(e.getAttribute('src') ?? '') ? `/${(e.getAttribute('src') as string).replace(/^\//, '')}` : null))
    .filter((src): src is string => !!src && src.endsWith('.js') && !LIB_SCRIPT.test(src)).slice(0, 5);
  for (const src of srcs) {
    try { const response = await connection.getPage(src); if (response.status === 200) sources.push([src, response.text.slice(0, 400_000)]); } catch { /* skip unreadable script */ }
  }
  void html;
  // Static device scripts only (never inline page scripts: those can carry server-rendered settings/secrets).
  const squash = (text: string) => text.replace(/\s+/g, ' ');
  const around = (text: string, pattern: RegExp, radius: number, max: number): string[] => {
    const spans: Array<[number, number]> = [];
    for (const m of text.matchAll(pattern)) {
      const at = m.index ?? 0; const a = Math.max(0, at - radius); const b = Math.min(text.length, at + radius);
      const last = spans[spans.length - 1];
      if (last && a <= last[1]) last[1] = b; else spans.push([a, b]);
      if (spans.length >= max) break;
    }
    return spans.map(([a, b]) => squash(text.slice(a, b)));
  };
  for (const [name, text] of sources.slice(1)) {
    if (/sptest/i.test(name)) result.code.push({ source: name, text: squash(text).slice(0, 30_000) });
    else if (/link|wireless|util|index/i.test(name) || /link|wireless/i.test(page)) {
      const hits = around(text, /chan_freq|chanbw|extchannel|ieee_mode|channel_scan_list|apply|discard|\.submit\(/g, 500, 8);
      if (hits.length) result.code.push({ source: name, text: hits.join(' ⟪…⟫ ').slice(0, 9_000) });
    }
  }
  const hints = new Set(result.scriptHints);
  for (const [name, text] of sources) {
    for (const m of text.matchAll(JS_URL)) hints.add(`${name}: ${m[1]}`);
    for (const m of text.matchAll(JS_CALL)) { const at = m.index ?? 0; hints.add(`${name}: ${text.slice(Math.max(0, at - 20), at + 140).replace(/\s+/g, ' ')}`); }
  }
  result.scriptHints = [...hints].slice(0, 80);
}

export async function discoverPaths(connection: RealConnection, label: string): Promise<DiscoveryResult> {
  const result: DiscoveryResult = { label, indexStatus: 0, links: [], pages: [], forms: [], controls: [], scriptHints: [], code: [], notes: [] };
  const parser = new DOMParser();
  const index = await connection.getPage('/index.cgi');
  result.indexStatus = index.status;
  const indexDoc = parser.parseFromString(index.text, 'text/html');
  result.links = collectLinks(index.text, indexDoc).slice(0, 80);
  result.forms.push(...collectForms('/index.cgi', indexDoc));
  if (!result.links.length) result.notes.push(connection.flavor === 'v8'
    ? 'واجهة airOS 8 تُبنى بجافاسكربت ولا تكشف صفحاتها ونماذجها في HTML؛ يلزم سجل HAR لهذا النوع.'
    : 'لم تظهر روابط صفحات في index.cgi.');
  // The menu is often built by the device's own JS (e.g. Speed Test opened by window.open): read those scripts too.
  await scanScripts(connection, '/index.cgi', index.text, indexDoc, result);
  const fromScripts = result.scriptHints.map((hint) => /: ([A-Za-z0-9_\-./]+\.cgi)/.exec(hint)?.[1]).filter((v): v is string => !!v).map((v) => (v.startsWith('/') ? v : `/${v}`));
  const toRead = [...new Set([...result.links, ...fromScripts])].filter((link) => INTEREST.test(link) && !NEVER_OPEN.test(link)).slice(0, 12);
  for (const path of toRead) {
    try {
      const page = await connection.getPage(path);
      result.pages.push({ path, status: page.status });
      if (page.status === 200) {
        const doc = parser.parseFromString(page.text, 'text/html');
        result.forms.push(...collectForms(path, doc));
        result.controls.push({ path, items: collectControls(doc) });
        await scanScripts(connection, path, page.text, doc, result);
      }
    } catch (error) { result.notes.push(`تعذرت قراءة ${path}: ${error instanceof Error ? error.message : String(error)}`); }
  }
  return result;
}

export function discoveryReport(results: DiscoveryResult[]): string {
  const lines: string[] = ['— اكتشاف مسارات واجهة الجهاز (قراءة فقط، دون أسرار) —'];
  for (const r of results) {
    lines.push('', `## ${r.label}`, `index.cgi: HTTP ${r.indexStatus}`, `الروابط: ${r.links.join(' ، ') || '—'}`);
    r.pages.forEach((p) => lines.push(`صفحة ${p.path}: HTTP ${p.status}`));
    r.forms.forEach((f) => {
      lines.push(`نموذج في ${f.page} → ${f.method} ${f.action}`);
      lines.push(`  حقول: ${f.fields.map((x) => `${x.name}[${x.type}]${x.value !== undefined ? `=${x.value}` : ''}`).join(' , ') || '—'}`);
      f.selects.filter((x) => x.options.length).forEach((x) => lines.push(`  قائمة ${x.name}: ${x.options.join(' , ')}`));
    });
    r.controls.forEach((c) => lines.push(`عناصر ${c.path}: ${c.items.join(' | ') || '—'}`));
    r.scriptHints.forEach((h) => lines.push(`سكربت: ${h}`));
    r.code.forEach((c) => lines.push('', `### كود ${c.source}`, c.text));
    r.notes.forEach((n) => lines.push(`ملاحظة: ${n}`));
  }
  return lines.join('\n');
}
