import { Capacitor, registerPlugin } from '@capacitor/core';

export type DeviceProtocol = 'https' | 'http';
/** v8 = airOS 8.x (JSON /api/auth + X-CSRF-ID). v6 = airOS 5/6 (multipart /login.cgi). */
export type AirOsFlavor = 'v8' | 'v6';
export interface ConnectInput {
  ip: string;
  username: string;
  password: string;
  protocol: DeviceProtocol;
  port: string;
  /** Short network timeouts: for probing units that may not be reachable from the phone. */
  quick?: boolean;
}
export interface CertificateInfo {
  sha256: string;
  subject: string;
  issuer: string;
  validUntil: string;
}
export interface AirOsSnapshot {
  model: string;
  family: 'M2' | 'M5' | 'غير معروف';
  firmware: string;
  status: Record<string, unknown>;
  publicInfo: Record<string, unknown>;
  /** Stations read from the optional /sta.cgi endpoint (may be empty). */
  extraStations?: unknown[];
  readAt: string;
  /** Non-fatal problems (for example an optional endpoint that this firmware does not have). */
  warnings?: string[];
}
export interface RealConnection {
  ip: string;
  protocol: DeviceProtocol;
  port: number;
  family: AirOsSnapshot['family'];
  model: string;
  firmware: string;
  flavor: AirOsFlavor;
  initialSnapshot: AirOsSnapshot;
  readStatus: () => Promise<AirOsSnapshot>;
  /** GET of an HTML/text page of the device's own web UI (read only). Used for path discovery. */
  getPage: (path: string) => Promise<{ status: number; text: string; contentType: string }>;
  /** Registers ONE form-target path that postForm may write to (never apply/reboot/reset/upgrade style paths). */
  allowWrite: (path: string) => void;
  /** What the hidden-WebView helper needs to open the device's pages with this session (cookies are copied, never logged). */
  webSession: () => { baseUrl: string; cookies: string[]; tlsPin: string; username: string; password: string };
  /** POST of a form to a path registered with allowWrite. */
  postForm: (path: string, body: string, contentType: string) => Promise<{ status: number; location: string }>;
  /** GET /apply.cgi — commits the changes staged by postForm. */
  applyPending: () => Promise<{ status: number }>;
}

interface NativeResponse {
  data: unknown;
  status: number;
  headers?: Record<string, string>;
  /** One entry per Set-Cookie header (never merged), provided by AirOsHttpPlugin. */
  setCookies?: string[];
}
interface AirOsNativePlugin {
  probeCertificate(options: { url: string; connectTimeoutMs?: number; readTimeoutMs?: number }): Promise<CertificateInfo>;
  request(options: { url: string; method: 'GET' | 'POST'; headers: Record<string, string>; data?: string; tlsPin?: string; connectTimeoutMs?: number; readTimeoutMs?: number }): Promise<NativeResponse>;
}
const AirOsHttp = registerPlugin<AirOsNativePlugin>('AirOsHttp');
/** Short timeouts for probing a unit that may be unreachable from the phone: fail in seconds, not half a minute. */
const QUICK_TIMEOUTS = { connectTimeoutMs: 3000, readTimeoutMs: 6000 };

/* ───────────────────────── errors ───────────────────────── */

/** An error whose message is already user-facing (Arabic) and must not be re-classified. */
class AirOsError extends Error {
  constructor(message: string) { super(message); this.name = 'AirOsError'; }
}
/**
 * The device rejected the username/password. `definitive` is false only when the answer is ambiguous
 * (a bare 401/403 from /api/auth can also come from firmware that has no such endpoint).
 */
export class AuthRejected extends AirOsError {
  constructor(message: string, readonly definitive = true) { super(message); this.name = 'AuthRejected'; }
}
/** The session cookie / CSRF token is missing or no longer accepted. */
class SessionExpired extends AirOsError {}
/** This firmware does not implement the endpoint used by the attempted login style. */
class FlavorUnsupported extends AirOsError {}

/* ───────────────────────── helpers ───────────────────────── */

function isPrivateIPv4(value: string): boolean {
  const parts = value.trim().split('.');
  if (parts.length !== 4 || parts.some((part) => !/^\d{1,3}$/.test(part) || Number(part) > 255)) return false;
  const [a, b] = parts.map(Number);
  return a === 10 || a === 192 && b === 168 || a === 172 && b >= 16 && b <= 31 || a === 169 && b === 254;
}
function validateInput(input: ConnectInput): number {
  if (!isPrivateIPv4(input.ip)) throw new Error('أدخل عنوان IPv4 خاصًا بالشبكة المحلية، مثل 192.168.1.20 أو 10.0.0.5.');
  if (!input.username.trim()) throw new Error('أدخل اسم المستخدم.');
  if (!input.password) throw new Error('أدخل كلمة المرور.');
  const port = Number(input.port);
  if (!Number.isInteger(port) || port < 1 || port > 65535) throw new Error('رقم المنفذ غير صالح.');
  if (!Capacitor.isNativePlatform()) throw new Error('لحماية بيانات الدخول، الاتصال المباشر متاح من تطبيق Android المثبّت فقط.');
  return port;
}
function flattenValues(value: unknown, path = ''): Array<[string, string]> {
  if (value === null || value === undefined) return [];
  if (typeof value !== 'object') return [[path.toLowerCase(), String(value)]];
  if (Array.isArray(value)) return value.flatMap((item, index) => flattenValues(item, `${path}.${index}`));
  return Object.entries(value as Record<string, unknown>).flatMap(([key, item]) => flattenValues(item, path ? `${path}.${key}` : key));
}
function findValue(data: Record<string, unknown>, keyPattern: RegExp): string {
  return flattenValues(data).find(([key, value]) => keyPattern.test(key) && value.trim() !== '')?.[1] ?? '';
}
function pick(sources: Array<Record<string, unknown>>, patterns: RegExp[]): string {
  for (const pattern of patterns) {
    for (const source of sources) {
      const found = findValue(source, pattern);
      if (found) return found;
    }
  }
  return '';
}
function headerValue(headers: Record<string, string> | undefined, name: string): string {
  return Object.entries(headers ?? {}).find(([key]) => key.toLowerCase() === name)?.[1] ?? '';
}

// airOS reports the model as host.devmodel and the firmware as host.fwversion in status.cgi.
const MODEL_PATTERNS = [/(^|\.)host\.devmodel$/i, /(^|\.)(devmodel|boardname|board|devicemodel|model|product)$/i];
const FIRMWARE_PATTERNS = [/(^|\.)host\.fwversion$/i, /(^|\.)(fwversion|firmware|version|build)$/i];

// Matches "NanoStation M5", "NSM5", "LocoM2", "Rocket M5", "Bullet M2HP", "M5" …
const FAMILY_PATTERN = /(?:\b(?:ns|lm|loco|lc|nb|pbe|rocket|bullet|airgrid|ag|nanostation|nanobridge|powerbeam|picostation)\s*m\s*|\bm)([25])(?:hp)?\b/;
function familyFromText(text: string): AirOsSnapshot['family'] | null {
  const match = FAMILY_PATTERN.exec(text.toLowerCase());
  if (!match) return null;
  return match[1] === '2' ? 'M2' : 'M5';
}
function detectFamily(model: string, details: Record<string, unknown>, status: Record<string, unknown>): AirOsSnapshot['family'] {
  const fromModel = familyFromText(model);
  if (fromModel) return fromModel;
  const detailText = flattenValues(details).map(([, value]) => value).join(' ');
  const statusHostText = flattenValues(status).filter(([key]) => key.startsWith('host.')).map(([, value]) => value).join(' ');
  return familyFromText(detailText) ?? familyFromText(statusHostText) ?? 'غير معروف';
}


/**
 * airOS 5/6 status.cgi sometimes returns valid JSON wrapped in noise: a BOM, leaked header lines
 * ("Content-Type: ..."), leading blank lines, or trailing text. Try strict parsing first, then fall back to
 * the outermost {...} block. Still throws when no JSON object can be recovered.
 */
function parseLooseJson(text: string): unknown {
  const cleaned = text.replace(/^\uFEFF/, '').trim();
  try { return JSON.parse(cleaned); } catch { /* try to recover below */ }
  const start = cleaned.indexOf('{');
  const end = cleaned.lastIndexOf('}');
  if (start >= 0 && end > start) {
    const block = cleaned.slice(start, end + 1);
    try { return JSON.parse(block); } catch { /* fall through */ }
    // Some firmware emits trailing commas before } or ].
    return JSON.parse(block.replace(/,\s*([}\]])/g, '$1'));
  }
  throw new SyntaxError('no JSON object');
}

/* ───────────────────────── cookies ───────────────────────── */

/** Keeps every cookie by name; a later Set-Cookie only replaces the cookie it names. */
class CookieJar {
  private cookies = new Map<string, string>();
  set(name: string, value: string) { this.cookies.set(name, value); }
  clear() { this.cookies.clear(); }
  has(): boolean { return this.cookies.size > 0; }
  names(): string[] { return [...this.cookies.keys()]; }
  pairs(): Array<[string, string]> { return [...this.cookies]; }
  header(): string { return [...this.cookies].map(([name, value]) => `${name}=${value}`).join('; '); }
  store(setCookies: string[]) {
    for (const line of setCookies) {
      const [pair, ...attributes] = line.split(';').map((part) => part.trim());
      const eq = pair.indexOf('=');
      if (eq <= 0) continue;
      const name = pair.slice(0, eq).trim();
      const value = pair.slice(eq + 1).trim();
      const maxAge = attributes.map((attribute) => /^max-age=(-?\d+)$/i.exec(attribute)?.[1]).find((match) => match !== undefined);
      const expiresAt = attributes.find((attribute) => /^expires=/i.test(attribute));
      const expired = (maxAge !== undefined && Number(maxAge) <= 0)
        || (expiresAt !== undefined && Date.parse(expiresAt.slice(expiresAt.indexOf('=') + 1)) < Date.now());
      if (expired || value === '') this.cookies.delete(name);
      else this.cookies.set(name, value);
    }
  }
}
// Fallback for a plugin build that only returns the merged "set-cookie" header.
function splitSetCookie(raw: string): string[] {
  return raw ? raw.split(/,\s*(?=[!#$%&'*+\-.^_`|~0-9A-Za-z]+=)/).filter(Boolean) : [];
}

/* ───────────────────────── user-facing network errors ───────────────────────── */

function errorForNetwork(error: unknown, protocol: DeviceProtocol): Error {
  if (error instanceof AirOsError) return error;
  const raw = error instanceof Error ? error.message : String(error);
  const requestContext = raw.match(/\[(?:GET|POST) ([^\]]+)\]/i)?.[1];
  if (/certificate changed after approval/i.test(raw)) return new Error('تغيّرت شهادة العلبة بعد الموافقة عليها. لم تُرسل بيانات الدخول. تحقق من الجهاز ثم أعد تأكيد الشهادة.');
  if (/SSLHandshakeException|CertPathValidatorException|certificate|trust anchor|SSLHandshake/i.test(raw)) {
    return new Error(`تعذر إكمال مصافحة HTTPS مع العلبة. التفاصيل التقنية: ${raw}`);
  }
  if (/ConnectException|ECONNREFUSED|Connection refused/i.test(raw)) return new Error(`تم الوصول إلى الشبكة لكن المنفذ ${protocol === 'https' ? '443/HTTPS' : '80/HTTP'} يرفض الاتصال. تحقق من منفذ الإدارة والبروتوكول.`);
  if (/SocketTimeoutException|timeout|timed out/i.test(raw)) {
    const stage = requestContext ? ` أثناء طلب ${requestContext}` : '';
    return new Error(`انتهت المهلة${stage}. العلبة لم ترد في الوقت المحدد؛ تحقق من الإشارة ومن أن واجهة الإدارة لا تنشغل بمستخدم آخر.`);
  }
  if (/UnknownHostException|unable to resolve/i.test(raw)) return new Error('تعذر العثور على عنوان الجهاز. راجع عنوان IP.');
  if (/failed to fetch|network|cleartext/i.test(raw)) return new Error(protocol === 'https'
    ? 'تعذر إكمال اتصال HTTPS. تحقق من منفذ الإدارة أو أعد تأكيد شهادة الجهاز.'
    : 'تعذر إكمال اتصال HTTP. تحقق من الشبكة ومنفذ الإدارة.');
  return new Error(raw || 'تعذر الاتصال بالجهاز.');
}

/* ───────────────────────── certificate probe ───────────────────────── */

export async function probeDeviceCertificate(input: ConnectInput): Promise<CertificateInfo> {
  const port = validateInput(input);
  if (input.protocol !== 'https') throw new Error('فحص الشهادة متاح عند اختيار HTTPS فقط.');
  try {
    // TLS handshake only: no HTTP request is sent and no credentials leave the app.
    return await AirOsHttp.probeCertificate({ url: `https://${input.ip}:${port}/`, ...(input.quick ? QUICK_TIMEOUTS : {}) });
  } catch (error) {
    const detail = error instanceof Error ? error.message : String(error);
    throw errorForNetwork(new Error(`[GET / TLS-handshake] ${detail}`), 'https');
  }
}

/* ───────────────────────── connection ───────────────────────── */

interface RawResponse { status: number; headers: Record<string, string>; text: string; location: string; }
interface SendOptions {
  method?: 'GET' | 'POST';
  body?: string;
  contentType?: string;
  /** true (default): XHR-style JSON request. false: browser navigation / form post. */
  ajax?: boolean;
  referer?: string;
}

/**
 * Read-only guard: after the session is open the app may only GET. The sole POST targets are the two
 * login endpoints; anything else (Apply/Change style form posts, settings writes) is refused here,
 * before it can reach the device.
 */
const POST_ALLOWED_PATHS = new Set(['/api/auth', '/login.cgi']);
const LOGIN_FORM = /<input[^>]+name\s*=\s*["']?password/i;
const HTML_PAGE = /<\s*(?:!doctype|html|form|body)\b/i;

export async function connectReal(input: ConnectInput, tlsPin = ''): Promise<RealConnection> {
  const port = validateInput(input);
  if (input.protocol === 'https' && !/^[A-Fa-f0-9]{64}$/.test(tlsPin)) throw new Error('يلزم تأكيد شهادة HTTPS الخاصة بالعلبة قبل تسجيل الدخول.');
  const baseUrl = `${input.protocol}://${input.ip}:${port}`;
  const username = input.username.trim();
  const jar = new CookieJar();
  let csrfId = '';
  let flavor = null as AirOsFlavor | null; // assigned from closures, so keep the declared union
  const writeAllowed = new Set<string>();
  const cacheBuster = (path: string) => `${path}${path.includes('?') ? '&' : '?'}_=${Date.now()}`;

  /** One HTTP exchange. Never throws for an HTTP status; throws only for transport failures. */
  const send = async (path: string, options: SendOptions = {}): Promise<RawResponse> => {
    const method = options.method ?? 'GET';
    if (method === 'POST' && !POST_ALLOWED_PATHS.has(path.split('?')[0]) && !writeAllowed.has(path.split('?')[0])) {
      throw new AirOsError(`وضع القراءة فقط: رُفض إرسال POST إلى ${path.split('?')[0]}. التطبيق لا يغيّر إعدادات الجهاز.`);
    }
    const ajax = options.ajax ?? true;
    const headers: Record<string, string> = {
      Accept: ajax ? 'application/json, text/javascript, */*; q=0.01' : 'text/html,application/xhtml+xml,*/*;q=0.8',
      'Cache-Control': 'no-cache, no-store',
      Pragma: 'no-cache',
      Referer: options.referer ?? `${baseUrl}/index.cgi`,
    };
    // Browser-like headers: python-airos needed these for airOS 6 (XM) status.cgi; the native default UA is not a browser.
    headers['User-Agent'] = 'Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36';
    headers['Accept-Language'] = 'en-US,en;q=0.9';
    headers['Sec-Fetch-Dest'] = ajax ? 'empty' : 'document';
    headers['Sec-Fetch-Mode'] = ajax ? 'cors' : 'navigate';
    headers['Sec-Fetch-Site'] = 'same-origin';
    if (ajax) headers['X-Requested-With'] = 'XMLHttpRequest';
    if (method === 'POST') headers.Origin = baseUrl;
    if (options.body !== undefined) headers['Content-Type'] = options.contentType ?? 'application/json';
    if (jar.has()) headers.Cookie = jar.header();
    if (csrfId) headers['X-CSRF-ID'] = csrfId;
    let response: NativeResponse;
    try {
      response = await AirOsHttp.request({
        url: `${baseUrl}${path}`, method, headers, data: options.body,
        tlsPin: input.protocol === 'https' ? tlsPin : undefined,
        ...(input.quick ? QUICK_TIMEOUTS : {}),
      });
    } catch (error) {
      const detail = error instanceof Error ? error.message : String(error);
      throw new Error(`[${method} ${path.split('?')[0]}] ${detail}`);
    }
    jar.store(response.setCookies ?? splitSetCookie(headerValue(response.headers, 'set-cookie')));
    const nextCsrf = headerValue(response.headers, 'x-csrf-id');
    if (nextCsrf) csrfId = nextCsrf;
    const text = typeof response.data === 'string' ? response.data : response.data == null ? '' : JSON.stringify(response.data);
    return { status: response.status, headers: response.headers ?? {}, text, location: headerValue(response.headers, 'location') };
  };

  const describe304 = (path: string, raw: RawResponse): string => {
    const parts = [
      `ETag=${headerValue(raw.headers, 'etag') || '—'}`,
      `Last-Modified=${headerValue(raw.headers, 'last-modified') || '—'}`,
      `Server=${headerValue(raw.headers, 'server') || '—'}`,
      `الكوكيز المرسلة=${jar.names().join(',') || 'لا شيء'}`,
      `X-CSRF-ID=${csrfId ? 'موجود' : 'غير موجود'}`,
    ];
    return `رد الجهاز بالرمز 304 Not Modified على المسار ${path.split('?')[0]} حتى بعد إعادة المحاولة بمعامل منع التخزين المؤقت. `
      + `هذا ليس تحويلًا (302)؛ التطبيق لا يرسل أي ترويسة شرطية، فالرد صادر من الجهاز نفسه. تفاصيل التشخيص: ${parts.join(' | ')}`;
  };

  /** GET → parsed JSON object. Retries once on 304, classifies session loss. */
  const getJson = async (path: string): Promise<Record<string, unknown>> => {
    let raw = await send(cacheBuster(path));
    if (raw.status === 304) raw = await send(cacheBuster(path));
    if (raw.status === 304) throw new AirOsError(describe304(path, raw));
    const route = path.split('?')[0];
    if (raw.status === 401 || raw.status === 403) throw new SessionExpired(`رفض الجهاز الطلب ${route} (HTTP ${raw.status}). الجلسة غير مقبولة أو الحساب بلا صلاحية.`);
    if (raw.status >= 300 && raw.status < 400) {
      if (/login|auth/i.test(raw.location) || raw.location === '') throw new SessionExpired(`أعاد الجهاز توجيه ${route} إلى صفحة الدخول؛ الجلسة غير مؤسسة (HTTP ${raw.status}).`);
      throw new AirOsError(`أعاد الجهاز توجيه ${route} إلى ${raw.location} (HTTP ${raw.status}). إن كان العنوان يبدأ بـ https فاختر HTTPS والمنفذ 443.`);
    }
    if (raw.status < 200 || raw.status >= 300) throw new AirOsError(`رد الجهاز على ${route} برمز HTTP ${raw.status}.`);
    // An empty answer (typically HTTP 204) means the device dropped/never activated the session: re-login, do not just fail.
    if (raw.text.trim() === '') throw new SessionExpired(`ردّ الجهاز على ${route} بجواب فارغ (HTTP ${raw.status})؛ الجلسة غير نشطة وسيُعاد تسجيل الدخول.`);
    let parsed: unknown;
    try { parsed = parseLooseJson(raw.text); }
    catch {
      if (LOGIN_FORM.test(raw.text)) throw new SessionExpired(`أعاد الجهاز صفحة الدخول بدل بيانات ${route}؛ الجلسة غير مؤسسة.`);
      const ctype = headerValue(raw.headers, 'content-type') || '—';
      const head = raw.text.replace(/\s+/g, ' ').trim().slice(0, 160) || '(فارغ)';
      throw new AirOsError(`استجاب الجهاز على ${route} بمحتوى ليس JSON${HTML_PAGE.test(raw.text) ? ' (صفحة HTML)' : ''}. [HTTP ${raw.status}، النوع=${ctype}، الطول=${raw.text.length}، البداية: ${head}]`);
    }
    if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) throw new AirOsError(`صيغة استجابة ${route} غير مدعومة.`);
    return parsed as Record<string, unknown>;
  };

  /** Compact technical trace appended to ambiguous login failures so the real cause is visible. */
  const trace = (label: string, raw: RawResponse) =>
    `[${label}: HTTP ${raw.status}${raw.location ? `، Location=${raw.location}` : ''}، كوكيز=${jar.names().join(',') || 'لا شيء'}${LOGIN_FORM.test(raw.text) ? '، عاد نموذج الدخول' : ''}]`;

  /* ── airOS 8.x: POST /api/auth ── */
  const loginV8 = async () => {
    const credentials = { username, password: input.password };
    const jsonLogin = () => send('/api/auth', { method: 'POST', body: JSON.stringify(credentials), contentType: 'application/json', referer: `${baseUrl}/` });
    let raw = await jsonLogin();
    if ([400, 405, 415].includes(raw.status)) {
      raw = await send('/api/auth', {
        method: 'POST', body: new URLSearchParams(credentials).toString(),
        contentType: 'application/x-www-form-urlencoded; charset=UTF-8', referer: `${baseUrl}/`,
      });
    }
    if (raw.status === 404 || raw.status === 501) throw new FlavorUnsupported('هذا الجهاز لا يوفّر /api/auth (غالبًا airOS 5/6).');
    if (raw.status >= 300 && raw.status < 400 && /login\.cgi/i.test(raw.location)) throw new FlavorUnsupported('وجّه الجهاز /api/auth إلى login.cgi (airOS 5/6).');
    if (raw.status === 401 || raw.status === 403) throw new AuthRejected(`رفض الجهاز الدخول عبر /api/auth ${trace('v8', raw)}.`, false);
    if (raw.status < 200 || raw.status >= 400) throw new AirOsError(`رد الجهاز على /api/auth برمز HTTP ${raw.status}.`);
    if (HTML_PAGE.test(raw.text)) throw new FlavorUnsupported('رد /api/auth بصفحة HTML وليس JSON (airOS 5/6).');
    if (raw.text.trim()) {
      try {
        const body = JSON.parse(raw.text) as Record<string, unknown>;
        const authError = findValue(body, /(^|\.)(error|message)$/i);
        if (authError && /invalid|incorrect|failed|denied|خطأ/i.test(authError)) throw new AuthRejected('اسم المستخدم أو كلمة المرور غير صحيحين.');
      } catch (error) { if (error instanceof AuthRejected) throw error; /* non-JSON body: judged by the status fetch */ }
    }
  };

  /** The web UI opens index.cgi right after logging in; python-airos does the same to activate the session. */
  const activateV6Session = async () => { await send('/index.cgi', { ajax: false, referer: `${baseUrl}/login.cgi` }); };

  /* ── airOS 5/6: POST /login.cgi ── */
  const loginV6 = async () => {
    const pre = await send('/login.cgi', { ajax: false, referer: `${baseUrl}/` });
    if (pre.status === 404) throw new FlavorUnsupported('هذا الجهاز لا يوفّر /login.cgi.');
    const boundary = `----NanoLink${Date.now().toString(16)}${Math.random().toString(16).slice(2, 10)}`;
    const part = (name: string, value: string) => `--${boundary}\r\nContent-Disposition: form-data; name="${name}"\r\n\r\n${value}\r\n`;
    const multipart = part('uri', '/index.cgi') + part('username', username) + part('password', input.password) + `--${boundary}--\r\n`;
    const urlencoded = new URLSearchParams({ uri: '/index.cgi', username, password: input.password }).toString();

    /** One login POST. Returns null on success, or the failure to report. */
    const attempt = async (style: 'multipart' | 'urlencoded'): Promise<AuthRejected | null> => {
      const raw = await send('/login.cgi', {
        method: 'POST', ajax: false, referer: `${baseUrl}/login.cgi`,
        body: style === 'multipart' ? multipart : urlencoded,
        contentType: style === 'multipart' ? `multipart/form-data; boundary=${boundary}` : 'application/x-www-form-urlencoded',
      });
      if (raw.status === 404) throw new FlavorUnsupported('هذا الجهاز لا يوفّر /login.cgi.');
      // Only an explicit error marker proves a wrong password; a bare bounce back to the login page is ambiguous
      // (rate limit, session limit, missing cookie), so it is reported with a trace instead of blaming the password.
      const explicitBad = /errmsg|invalid|incorrect|wrong|failed/i.test(raw.location) || /invalid\s+(?:credentials|user|password)|incorrect|wrong\s+(?:user|password)/i.test(raw.text);
      const label = `v6-${style}`;
      if (raw.status === 401 || raw.status === 403) return new AuthRejected(`رفض الجهاز الدخول ${trace(label, raw)}.`, explicitBad);
      if (raw.status >= 300 && raw.status < 400) {
        if (/login\.cgi/i.test(raw.location)) {
          return new AuthRejected(explicitBad ? 'اسم المستخدم أو كلمة المرور غير صحيحين.' : `أعاد الجهاز صفحة الدخول بعد الإرسال دون تأكيد سبب واضح ${trace(label, raw)}.`, explicitBad);
        }
      } else if (raw.status === 200) {
        if (LOGIN_FORM.test(raw.text)) {
          return new AuthRejected(explicitBad ? 'اسم المستخدم أو كلمة المرور غير صحيحين.' : `أعاد الجهاز نموذج الدخول دون رسالة خطأ واضحة ${trace(label, raw)}.`, explicitBad);
        }
      } else {
        throw new AirOsError(`رد الجهاز على /login.cgi برمز HTTP ${raw.status}.`);
      }
      return null;
    };

    let failure = await attempt('multipart');
    // Retry once in the other body style only when the first answer was ambiguous (never after an explicit wrong password,
    // so a real bad password is not sent twice and does not double the device's lockout counter).
    if (failure && !failure.definitive) failure = await attempt('urlencoded');
    if (failure) throw failure;
    await activateV6Session();
  };

  /** Logs in (trying the known style, else v8 then v6) and returns the first valid status.cgi. */
  const establish = async (): Promise<Record<string, unknown>> => {
    const order: AirOsFlavor[] = flavor ? [flavor] : ['v8', 'v6'];
    const failures: AirOsError[] = [];
    for (const candidate of order) {
      jar.clear();
      csrfId = '';
      jar.set('ok', '1'); // the airOS login page sets this "cookies enabled" marker from JavaScript
      try {
        if (candidate === 'v8') await loginV8(); else await loginV6();
        let status: Record<string, unknown>;
        try { status = await getJson('/status.cgi'); }
        catch (error) {
          // python-airos logs empty status answers right after an airOS 6 login: re-activate the session and retry once.
          if (candidate !== 'v6' || error instanceof AuthRejected) throw error;
          await activateV6Session();
          await new Promise((resolve) => setTimeout(resolve, 500));
          status = await getJson('/status.cgi');
        }
        flavor = candidate;
        return status;
      } catch (error) {
        if (!(error instanceof AirOsError)) throw error;                         // transport failure: stop at once
        if (error instanceof AuthRejected && error.definitive) throw error;      // wrong password: no second login style
        failures.push(error);
      }
    }
    const rejected = failures.find((failure) => failure instanceof AuthRejected);
    const meaningful = failures.find((failure) => !(failure instanceof FlavorUnsupported));
    if (rejected) {
      const details = failures.map((failure) => failure.message).join(' ‖ ');
      throw new AuthRejected(`تعذّر تسجيل الدخول. كلمة المرور خاطئة محتمل، لكن الجهاز لم يؤكد ذلك. قد يكون السبب حدًّا أقصى للجلسات أو حظرًا مؤقتًا بعد محاولات فاشلة؛ انتظر دقيقتين أو سجّل خروج من واجهة الجهاز ثم أعد المحاولة. التفاصيل: ${details}`, false);
    }
    throw meaningful ?? new AirOsError('نمط المصادقة في هذا الجهاز غير مدعوم: لا /api/auth ولا /login.cgi. أرسل إصدار airOS الظاهر في واجهة الجهاز.');
  };

  // airOS 5/6 has no /api/info/public (it answers 404). Once we know that, stop asking on every refresh.
  let publicInfoUnsupported = false;
  const fetchPublicInfo = async (warnings: string[]): Promise<Record<string, unknown>> => {
    if (publicInfoUnsupported || flavor === 'v6') return {};
    try { return await getJson('/api/info/public'); }
    catch (error) {
      // Optional endpoint: it must never block the connection.
      const detail = error instanceof Error ? error.message : String(error);
      // 404 / non-JSON page = this firmware simply does not have the endpoint: not a problem worth a warning.
      if (/HTTP 404|HTTP 501|ليس JSON|لا يدعم هذا الإصدار/.test(detail)) { publicInfoUnsupported = true; return {}; }
      warnings.push(`تعذّرت قراءة /api/info/public (اختياري): ${detail}`);
      return {};
    }
  };

  /** Optional supplement: /sta.cgi lists associated stations (with IP and signal) on airOS 5/6/8.x. GET only. */
  let staUnsupported = false;
  const fetchStations = async (): Promise<unknown[]> => {
    if (staUnsupported) return [];
    try {
      let raw = await send(cacheBuster('/sta.cgi'));
      if (raw.status === 304) raw = await send(cacheBuster('/sta.cgi'));
      if (raw.status === 404 || raw.status === 501) { staUnsupported = true; return []; }
      if (raw.status < 200 || raw.status >= 300) return [];
      const parsed = JSON.parse(raw.text) as unknown;
      if (Array.isArray(parsed)) return parsed;
      if (parsed && typeof parsed === 'object') {
        const obj = parsed as Record<string, unknown>;
        for (const key of ['sta', 'stations']) if (Array.isArray(obj[key])) return obj[key] as unknown[];
        const wireless = obj.wireless as Record<string, unknown> | undefined;
        if (wireless && Array.isArray(wireless.sta)) return wireless.sta as unknown[];
      }
      return [];
    } catch (error) {
      if (error instanceof SyntaxError) { staUnsupported = true; return []; } // not JSON: this firmware has no such endpoint
      return [];                                                              // optional: never blocks the connection
    }
  };

  const buildSnapshot = (status: Record<string, unknown>, publicInfo: Record<string, unknown>, extraStations: unknown[], warnings: string[], previous?: { model: string; firmware: string }): AirOsSnapshot => {
    const model = pick([status, publicInfo], MODEL_PATTERNS) || previous?.model || 'لم يحدده الجهاز';
    const firmware = pick([status, publicInfo], FIRMWARE_PATTERNS) || previous?.firmware || 'غير متاح';
    return { model, family: detectFamily(model, publicInfo, status), firmware, status, publicInfo, extraStations, readAt: new Date().toISOString(), warnings };
  };

  try {
    const status = await establish();
    const warnings: string[] = [];
    const publicInfo = await fetchPublicInfo(warnings);
    const extraStations = await fetchStations();
    const snapshot = buildSnapshot(status, publicInfo, extraStations, warnings);
    return {
      ip: input.ip, protocol: input.protocol, port, flavor: flavor as AirOsFlavor,
      family: snapshot.family, model: snapshot.model, firmware: snapshot.firmware, initialSnapshot: snapshot,
      getPage: async (path: string) => {
        if (!/^\/[A-Za-z0-9_\-./]*(\?[A-Za-z0-9_=&.\-]*)?$/.test(path)) throw new AirOsError('مسار غير صالح.');
        if (/airview|survey|align|discover|apply|discard|reboot|reset|restart|upgrade|firmware|logout|kick|default|cfg|backup|delete|remove/i.test(path.split('?')[0])) throw new AirOsError('وضع القراءة فقط: هذه الصفحة تغيّر الجهاز بمجرد فتحها، فلن تُفتح.');
        try {
          const fetchPage = async () => {
            let raw = await send(cacheBuster(path), { ajax: false });
            if (raw.status === 304) raw = await send(cacheBuster(path), { ajax: false });
            return raw;
          };
          let raw: RawResponse | null = null;
          for (let attempt = 1; attempt <= 3 && raw === null; attempt += 1) {
            try { raw = await fetchPage(); }
            catch (error) { // the loco M5 web server is slow: retry timeouts, fail on anything else
              if (attempt === 3 || !/timeout|timed out/i.test(error instanceof Error ? error.message : String(error))) throw error;
              await new Promise((resolve) => setTimeout(resolve, 1500 * attempt));
            }
          }
          if (raw === null) throw new AirOsError('لم يرد الجهاز.');
          if (raw.status === 200 && LOGIN_FORM.test(raw.text) && !/login/i.test(path)) { await establish(); raw = await fetchPage(); }
          return { status: raw.status, text: raw.text, contentType: headerValue(raw.headers, 'content-type') };
        } catch (error) { throw errorForNetwork(error, input.protocol); }
      },
      webSession: () => ({ baseUrl, cookies: jar.pairs().map(([name, value]) => `${name}=${value}; Path=/`), tlsPin: input.protocol === 'https' ? tlsPin : '', username: input.username.trim(), password: input.password }),
      allowWrite: (path: string) => {
        const clean = path.split('?')[0];
        if (!/^\/[A-Za-z0-9_\-./]+\.(?:cgi|php|asp)$/i.test(clean) || /apply|discard|reboot|reset|restart|upgrade|firmware|logout|kick|default|cfg|backup|delete|remove|login/i.test(clean)) throw new AirOsError(`لا يُسمح بالكتابة إلى ${clean}.`);
        writeAllowed.add(clean);
      },
      postForm: async (path: string, body: string, contentType: string) => {
        try {
          const raw = await send(path, { method: 'POST', ajax: false, body, contentType, referer: `${baseUrl}${path}` });
          if (raw.status === 401 || raw.status === 403 || (raw.status === 200 && LOGIN_FORM.test(raw.text))) throw new SessionExpired('رفض الجهاز الإرسال: الجلسة غير مقبولة.');
          return { status: raw.status, location: raw.location };
        } catch (error) { throw errorForNetwork(error, input.protocol); }
      },
      applyPending: async () => {
        try { const raw = await send(cacheBuster('/apply.cgi'), { ajax: false }); return { status: raw.status }; }
        catch (error) { throw errorForNetwork(error, input.protocol); }
      },
      readStatus: async () => {
        try {
          let nextStatus: Record<string, unknown>;
          try { nextStatus = await getJson('/status.cgi'); }
          catch (error) {
            if (!(error instanceof SessionExpired)) throw error;
            nextStatus = await establish(); // log in again only when the device dropped the session
          }
          const nextWarnings: string[] = [];
          const nextPublicInfo = await fetchPublicInfo(nextWarnings);
          const nextStations = await fetchStations();
          return buildSnapshot(nextStatus, nextPublicInfo, nextStations, nextWarnings, { model: snapshot.model, firmware: snapshot.firmware });
        } catch (error) { throw errorForNetwork(error, input.protocol); }
      },
    };
  } catch (error) { throw errorForNetwork(error, input.protocol); }
}
