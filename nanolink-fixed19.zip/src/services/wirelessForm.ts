// Learns the Wireless form straight from the device's own page (airOS 5/6 style HTML) and builds the
// frequency change from it: read the form, change ONLY the frequency field, post the form back, apply, verify.
// Guards: the frequency shown by the form must equal the real frequency from status.cgi (proves the form values
// are server-rendered and complete); the new value must be one of the device's own options; nothing is guessed.
import type { RealConnection } from './real';
import { parseMain } from './airosView';
import { NEVER_OPEN } from './discovery';
import type { DeviceActions } from './campaign';

export interface WirelessForm {
  page: string; action: string; enctype: string;
  pairs: Array<[string, string]>;
  freqField: string;
  /** frequency (MHz) → option value the device itself uses */
  options: Map<number, string>;
  currentMHz: number | null;
  /** Named selects with no <option> in the HTML: the page fills them with JavaScript, so the HTML state is incomplete. */
  emptySelects: string[];
}
const FREQ_NAME = /^(freq|frequency|centerfreq|center_freq|freqmhz|freq_mhz|chfreq|channel_freq|chan_freq)$/i;
const PAGE_HINT = /wireless|wlan|link|radio|config/i;

const mhzIn = (text: string): number | null => { const m = /(?:^|\D)(2[3-9]\d\d|[3-6]\d{3}|7[01]\d\d)(?:\D|$)/.exec(text); return m ? Number(m[1]) : null; };

export function serialize(form: Element): Array<[string, string]> {
  const out: Array<[string, string]> = [];
  form.querySelectorAll('input,select,textarea').forEach((el) => {
    const name = el.getAttribute('name');
    if (!name || el.hasAttribute('disabled')) return;
    const tag = el.tagName.toLowerCase();
    if (tag === 'select') {
      const options = [...el.querySelectorAll('option')];
      const chosen = options.filter((o) => o.hasAttribute('selected'));
      const use = el.hasAttribute('multiple') ? chosen : [chosen[0] ?? options[0]].filter(Boolean);
      use.forEach((o) => out.push([name, o.getAttribute('value') ?? o.textContent ?? '']));
    } else if (tag === 'textarea') out.push([name, el.textContent ?? '']);
    else {
      const type = (el.getAttribute('type') || 'text').toLowerCase();
      if (['button', 'submit', 'reset', 'image', 'file'].includes(type)) return;
      if ((type === 'checkbox' || type === 'radio') && !el.hasAttribute('checked')) return;
      out.push([name, el.getAttribute('value') ?? (type === 'checkbox' || type === 'radio' ? 'on' : '')]);
    }
  });
  return out;
}

export async function learnWirelessForm(conn: RealConnection): Promise<WirelessForm> {
  if (conn.flavor === 'v8') throw new Error('واجهة airOS 8 لا تكشف نموذجها في HTML؛ هذا النوع يحتاج سجل HAR.');
  const parser = new DOMParser();
  const index = await conn.getPage('/index.cgi');
  const links = new Set<string>();
  const add = (v: string | null) => { const c = (v ?? '').trim().replace(/^https?:\/\/[^/]+/i, '').replace(/^\.\//, ''); if (/^\/?[A-Za-z0-9_\-./]+\.cgi$/i.test(c)) links.add(c.startsWith('/') ? c : `/${c}`); };
  parser.parseFromString(index.text, 'text/html').querySelectorAll('a[href],iframe[src],frame[src]').forEach((e) => add(e.getAttribute('href') ?? e.getAttribute('src')));
  for (const m of index.text.matchAll(/["']([A-Za-z0-9_\-./]+\.cgi)["']/g)) add(m[1]);
  const candidates = [...links].filter((l) => PAGE_HINT.test(l) && !NEVER_OPEN.test(l)).slice(0, 8);
  const seen: string[] = [];
  for (const page of candidates) {
    const response = await conn.getPage(page);
    if (response.status !== 200) continue;
    const doc = parser.parseFromString(response.text, 'text/html');
    for (const form of [...doc.querySelectorAll('form')]) {
      const pairs = serialize(form);
      seen.push(...pairs.map(([n]) => n));
      const freqSelect = [...form.querySelectorAll('select,input')].find((e) => FREQ_NAME.test(e.getAttribute('name') ?? ''));
      if (!freqSelect) continue;
      if ((form.getAttribute('method') || 'GET').toUpperCase() !== 'POST') continue;
      const freqField = freqSelect.getAttribute('name') as string;
      const options = new Map<number, string>();
      freqSelect.querySelectorAll('option').forEach((o) => {
        const value = o.getAttribute('value') ?? '';
        const mhz = mhzIn(value) ?? mhzIn(o.textContent ?? '');
        if (mhz !== null) options.set(mhz, value);
      });
      const currentValue = pairs.find(([n]) => n === freqField)?.[1] ?? '';
      const currentMHz = [...options].find(([, v]) => v === currentValue)?.[0] ?? mhzIn(currentValue);
      const emptySelects = [...form.querySelectorAll('select')].filter((el) => el.getAttribute('name') && el.querySelectorAll('option').length === 0).map((el) => el.getAttribute('name') as string);
      return { emptySelects, page, action: form.getAttribute('action') || page, enctype: (form.getAttribute('enctype') || 'application/x-www-form-urlencoded').toLowerCase(), pairs, freqField, options, currentMHz };
    }
  }
  throw new Error(`لم أجد نموذج Wireless فيه حقل تردد معروف. الصفحات المقروءة: ${candidates.join('، ') || '—'}. أسماء الحقول التي رأيتها: ${[...new Set(seen)].slice(0, 40).join('، ') || '—'}.`);
}

/** Why this form must NOT be posted, or null when every safety check passes. */
export async function sanityProblem(conn: RealConnection, form: WirelessForm): Promise<string | null> {
  const status = parseMain((await conn.readStatus()).status);
  if (status.frequencyMHz.value === null) return 'تعذر قراءة التردد الحقيقي من status.cgi للمقارنة.';
  if (form.currentMHz !== status.frequencyMHz.value) return `التردد في النموذج (${form.currentMHz ?? '—'}) لا يطابق التردد الحقيقي (${status.frequencyMHz.value}). الصفحة تملأ قيمها بجافاسكربت على الأرجح، فلن يُرسل النموذج حتى لا تُمسح إعدادات.`;
  if (form.emptySelects.length) return `هذه الصفحة تملأ بعض حقولها بجافاسكربت (${form.emptySelects.slice(0, 6).join('، ')}). قراءة HTML وحدها لا تعطي حالة النموذج كاملة (وكذلك خانات الاختيار)، وإعادة إرساله قد تغيّر إعدادات أخرى. لن يُرسل شيء.`;
  if (form.pairs.length < 3) return 'النموذج فيه حقول قليلة جدًا؛ غالبًا قُرئ ناقصًا.';
  return null;
}

export function buildBody(form: WirelessForm, mhz: number): { body: string; contentType: string; from: string; to: string } {
  const value = form.options.get(mhz);
  if (value === undefined) throw new Error(`القناة ${mhz} MHz ليست ضمن خيارات الجهاز نفسه.`);
  const pairs = form.pairs.map(([n, v]) => (n === form.freqField ? [n, value] as [string, string] : [n, v] as [string, string]));
  const from = form.pairs.find(([n]) => n === form.freqField)?.[1] ?? '';
  if (form.enctype.startsWith('multipart')) {
    const boundary = `----NanoLink${Date.now().toString(16)}${Math.random().toString(16).slice(2, 8)}`;
    const body = pairs.map(([n, v]) => `--${boundary}\r\nContent-Disposition: form-data; name="${n}"\r\n\r\n${v}\r\n`).join('') + `--${boundary}--\r\n`;
    return { body, contentType: `multipart/form-data; boundary=${boundary}`, from, to: value };
  }
  return { body: pairs.map(([n, v]) => `${encodeURIComponent(n)}=${encodeURIComponent(v)}`).join('&'), contentType: 'application/x-www-form-urlencoded', from, to: value };
}

/**
 * Frequency changes learned from the device's own form. `useApply=false` presses only the equivalent of «OK/Change»
 * (the form POST); `useApply=true` additionally commits with /apply.cgi. Speed Test is not part of this: the ranking
 * then uses link quality read from each unit.
 */
export function makeLearnedActions(useApply: boolean): DeviceActions {
  return {
    available: true,
    reason: '',
    async setFrequency(main, mhz) {
      const form = await learnWirelessForm(main);
      const problem = await sanityProblem(main, form);
      if (problem) throw new Error(problem);
      const request = buildBody(form, mhz);
      const action = form.action.startsWith('/') ? form.action : `/${form.action}`;
      main.allowWrite(action);
      const posted = await main.postForm(action, request.body, request.contentType);
      if (posted.status >= 400) throw new Error(`رفض الجهاز النموذج (HTTP ${posted.status}).`);
      if (useApply) {
        const applied = await main.applyPending();
        if (applied.status >= 400) throw new Error(`رفض الجهاز التطبيق (HTTP ${applied.status}).`);
      }
    },
    async runSpeedTest() { return { values: [] }; },
  };
}
