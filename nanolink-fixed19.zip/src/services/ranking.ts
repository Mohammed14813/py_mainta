// Ranks channels per unit (and for the whole network) from what was actually measured.
// Basis per unit: Speed Test download+upload when every channel has numeric values for it; otherwise link
// quality (signal, CCQ, TX/RX) read from the unit. Nothing is estimated for a channel that was not measured.
import type { CampaignOutcome, ChannelUnitResult } from './campaign';

export interface Metrics { signal: number | null; ccq: number | null; tx: number | null; rx: number | null; down: number | null; up: number | null; total: number | null; }
export interface RankedChannel { frequencyMHz: number; score: number; metrics: Metrics; basis: 'speed' | 'link'; samples: number; }
export interface UnitRanking { unitKey: string; unitName: string; ranked: RankedChannel[]; }
export interface SharedBest { frequencyMHz: number; worstRank: number; averageRank: number; }

const num = (value?: string): number | null => { const m = /-?\d+(?:\.\d+)?/.exec(value ?? ''); return m ? Number(m[0]) : null; };

export function metricsOf(unit: ChannelUnitResult): Metrics {
  const fields = unit.reading?.fields ?? [];
  const speed = unit.speed?.values ?? [];
  const field = (pattern: RegExp) => num(fields.find((item) => pattern.test(item.label))?.value);
  const spd = (pattern: RegExp) => num(speed.find((item) => pattern.test(item.label))?.value);
  const signal = field(/الإشارة/);
  return {
    signal: signal !== null && signal >= -130 && signal <= 0 ? signal : null,
    ccq: field(/^CCQ$/), tx: field(/TX/), rx: field(/RX/),
    down: spd(/^rx|down|download|تنزيل/i), up: spd(/^tx|(^|\W)up|upload|رفع/i), total: spd(/^total/i),
  };
}
const speedScore = (m: Metrics) => m.total ?? (m.down ?? 0) + (m.up ?? 0);
const linkScore = (m: Metrics) => (m.signal ?? -100) + 100 + (m.ccq ?? 0) * 0.3 + ((m.tx ?? 0) + (m.rx ?? 0)) * 0.05;

export function rankUnits(outcome: CampaignOutcome): UnitRanking[] {
  const perUnit = new Map<string, { name: string; items: Array<{ f: number; m: Metrics }> }>();
  for (const run of outcome.runs) for (const unit of run.units) {
    if (!unit.ok) continue;
    const entry = perUnit.get(unit.unitKey) ?? { name: unit.unitName, items: [] };
    entry.items.push({ f: run.frequencyMHz, m: metricsOf(unit) });
    perUnit.set(unit.unitKey, entry);
  }
  const avg = (values: Array<number | null>): number | null => { const v = values.filter((x): x is number => x !== null); return v.length ? +(v.reduce((a, b) => a + b, 0) / v.length).toFixed(2) : null; };
  return [...perUnit].map(([unitKey, { name, items }]) => {
    // repeated passes over the same channel are averaged
    const byChannel = new Map<number, Metrics[]>();
    items.forEach((item) => byChannel.set(item.f, [...(byChannel.get(item.f) ?? []), item.m]));
    const merged = [...byChannel].map(([f, list]) => ({ f, samples: list.length, m: { signal: avg(list.map((x) => x.signal)), ccq: avg(list.map((x) => x.ccq)), tx: avg(list.map((x) => x.tx)), rx: avg(list.map((x) => x.rx)), down: avg(list.map((x) => x.down)), up: avg(list.map((x) => x.up)), total: avg(list.map((x) => x.total)) } as Metrics }));
    const useSpeed = merged.length > 0 && merged.every((item) => item.m.total !== null || item.m.down !== null || item.m.up !== null);
    const ranked = merged
      .map((item) => ({ frequencyMHz: item.f, metrics: item.m, samples: item.samples, basis: useSpeed ? 'speed' as const : 'link' as const, score: +(useSpeed ? speedScore(item.m) : linkScore(item.m)).toFixed(1) }))
      .sort((a, b) => b.score - a.score);
    return { unitKey, unitName: name, ranked };
  });
}

/** The AP has ONE channel for everyone, so the shared pick minimises the worst rank any unit gives it. */
export function sharedBest(rankings: UnitRanking[]): SharedBest | null {
  if (!rankings.length) return null;
  const common = rankings[0].ranked.map((r) => r.frequencyMHz).filter((f) => rankings.every((u) => u.ranked.some((r) => r.frequencyMHz === f)));
  const candidates = common.map((f) => {
    const ranks = rankings.map((u) => u.ranked.findIndex((r) => r.frequencyMHz === f) + 1);
    return { frequencyMHz: f, worstRank: Math.max(...ranks), averageRank: +(ranks.reduce((a, b) => a + b, 0) / ranks.length).toFixed(2) };
  });
  candidates.sort((a, b) => a.worstRank - b.worstRank || a.averageRank - b.averageRank);
  return candidates[0] ?? null;
}

export function buildRankingReport(outcome: CampaignOutcome): string {
  const rankings = rankUnits(outcome);
  if (!rankings.length) return '';
  const lines = ['— أقوى القنوات لكل علبة —'];
  for (const unit of rankings) {
    lines.push(`${unit.unitName} (${unit.ranked[0]?.basis === 'speed' ? 'حسب Speed Test' : 'حسب جودة الرابط'}):`);
    unit.ranked.slice(0, 3).forEach((r, i) => lines.push(`  ${i + 1}) ${r.frequencyMHz} MHz — ${r.score}`));
  }
  const best = sharedBest(rankings);
  if (best) lines.push('', `أفضل قناة مشتركة: ${best.frequencyMHz} MHz (أسوأ ترتيب عند أي علبة: ${best.worstRank}، المتوسط ${best.averageRank})`);
  return lines.join('\n');
}
