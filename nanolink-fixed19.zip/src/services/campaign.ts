// Multi-channel campaign: for each frequency, change the main node's channel temporarily, wait for the units to
// come back, read/speed-test every valid unit, and ALWAYS put the original channel back at the end.
//
// The two device writes (set frequency, run Speed Test) are injected through DeviceActions. They are NOT
// implemented against a real device yet because their airOS endpoints are unconfirmed (see deviceActions.ts).
// Everything around them (original-channel backup, wait-for-recovery, rollback timeout, verification) is here
// and covered by a simulated test.

import { parseMain } from './airosView';
import type { RealConnection } from './real';
import type { UnitReading } from './fleet';
import type { SpeedResult, SpeedTarget } from './speedTypes';
import { ChannelNotAllowed } from './speedTypes';
import { readingFrom } from './fleet';

export type { SpeedResult, SpeedTarget } from './speedTypes';
export interface DeviceActions {
  /** false when this environment cannot drive the device pages (e.g. not inside the Android app); the campaign refuses to start. */
  available: boolean;
  reason: string;
  /** Changes the main node's channel. Throws ChannelNotAllowed when the device does not offer the frequency. */
  setFrequency(main: RealConnection, mhz: number): Promise<void>;
  /** Runs the main node's Speed Test tool toward a unit. */
  runSpeedTest(main: RealConnection, target: SpeedTarget): Promise<SpeedResult>;
}
/** Thrown by actions that are not wired to a confirmed device endpoint. Nothing was changed on the device. */
export class ActionsUnavailable extends Error {
  constructor(message: string) { super(message); this.name = 'ActionsUnavailable'; }
}

/** `connection` is optional: a unit may be reachable only through the main node's Speed Test tool. */
export interface CampaignUnit { key: string; name: string; target: SpeedTarget; connection?: RealConnection; }
export interface ChannelUnitResult {
  unitKey: string; unitName: string; ok: boolean; error?: string;
  reading?: UnitReading; speed?: SpeedResult;
}
export interface ChannelRun {
  frequencyMHz: number; startedAt: string;
  /** The units reappeared on this channel within the recovery timeout. */
  recovered: boolean; error?: string; units: ChannelUnitResult[];
}
export interface CampaignOutcome {
  originalMHz: number | null;
  runs: ChannelRun[];
  /** true when the original channel was put back and verified (or when nothing was ever changed). */
  restored: boolean;
  restoreError?: string;
  /** Set when the campaign did not run to the end (refused to start, stopped, rollback after a failure). */
  aborted?: string;
  /** The device was never written to. */
  untouched: boolean;
}
export interface CampaignOptions {
  main: RealConnection;
  units: CampaignUnit[];
  channels: number[];
  actions: DeviceActions;
  onProgress?: (message: string) => void;
  /** Called after every unit result so the UI can rank channels while the campaign is still running. */
  onUpdate?: (snapshot: CampaignOutcome) => void;
  shouldStop?: () => boolean;
  /** How long the units get to come back after a channel change before the campaign rolls back. */
  recoveryTimeoutMs?: number;
  /** Keep cycling through the channels until stopped (or until a whole pass gets no usable channel). */
  repeat?: boolean;
  /** Extra wait after the units are back, so the link settles before it is measured. */
  settleMs?: number;
  /** Called with the original channel BEFORE anything is changed (so it can be persisted for crash recovery). */
  onOriginal?: (mhz: number) => void;
  /** Called when the run is over and the device is back on its original channel (or was never touched). */
  onSettledSafe?: () => void;
  /** Called when one channel is fully measured on all units. */
  onChannelDone?: (run: ChannelRun) => void;
  pollMs?: number;
  sleep?: (ms: number) => Promise<void>;
  now?: () => Date;
}

const defaultSleep = (ms: number) => new Promise<void>((resolve) => setTimeout(resolve, ms));

export async function runCampaign(options: CampaignOptions): Promise<CampaignOutcome> {
  const { main, units, channels, actions } = options;
  const sleep = options.sleep ?? defaultSleep;
  const now = options.now ?? (() => new Date());
  const progress = options.onProgress ?? (() => undefined);
  const update = () => options.onUpdate?.(JSON.parse(JSON.stringify(outcome)) as CampaignOutcome);
  const recoveryTimeoutMs = options.recoveryTimeoutMs ?? 120_000;
  const pollMs = options.pollMs ?? 4_000;
  const settleMs = options.settleMs ?? 10_000;
  const outcome: CampaignOutcome = { originalMHz: null, runs: [], restored: true, untouched: true };

  if (!actions.available) { outcome.aborted = actions.reason; return outcome; }
  if (!units.length) { outcome.aborted = 'لا توجد علب صحيحة البيانات لاختبارها.'; return outcome; }
  if (!channels.length) { outcome.aborted = 'لم تُحدَّد قنوات للاختبار.'; return outcome; }

  // 1) Back up the original channel and the number of units that are linked right now.
  let expectedStations = 0;
  try {
    const snapshot = await main.readStatus();
    const view = parseMain(snapshot.status, snapshot.extraStations);
    outcome.originalMHz = view.frequencyMHz.value;
    expectedStations = view.stations.length;
  } catch (error) {
    outcome.aborted = `تعذر قراءة حالة العلبة الرئيسية قبل البدء: ${error instanceof Error ? error.message : String(error)}`;
    return outcome;
  }
  if (outcome.originalMHz === null) { outcome.aborted = 'تعذر تحديد القناة الأصلية، فلا يمكن ضمان الرجوع إليها. لم يُغيَّر شيء.'; return outcome; }
  if (expectedStations === 0) { outcome.aborted = 'لا توجد محطات مرتبطة الآن؛ لن يبدأ الاختبار لأن الرجوع لا يمكن التحقق منه.'; return outcome; }
  const original = outcome.originalMHz;
  options.onOriginal?.(original);

  /** Polls the main node until it reports `targetMHz` with all the units linked again. */
  const waitForRecovery = async (targetMHz: number): Promise<boolean> => {
    let waited = 0;
    while (waited <= recoveryTimeoutMs) {
      try {
        const snapshot = await main.readStatus();
        const view = parseMain(snapshot.status, snapshot.extraStations);
        if (view.frequencyMHz.value === targetMHz && view.stations.length >= expectedStations) return true;
      } catch { /* the main node may be unreachable while it re-tunes: keep waiting */ }
      await sleep(pollMs);
      waited += pollMs;
    }
    return false;
  };
  const currentFrequency = async (): Promise<number | null> => {
    try { return parseMain((await main.readStatus()).status).frequencyMHz.value; } catch { return null; }
  };

  // 2) Per-channel loop; the `finally` below restores the original channel whatever happens.
  let changedDevice = false;
  try {
    do {
    let recoveredInPass = 0;
    for (const target of channels) {
      if (options.shouldStop?.()) { outcome.aborted = 'أوقفت الاختبار يدويًا.'; break; }
      if (target === original) continue;
      const run: ChannelRun = { frequencyMHz: target, startedAt: now().toISOString(), recovered: false, units: [] };
      outcome.runs.push(run);
      progress(`تغيير التردد مؤقتًا إلى ${target} MHz…`);
      try {
        await actions.setFrequency(main, target);
        changedDevice = true;
      } catch (error) {
        if (error instanceof ActionsUnavailable) { run.error = error.message; outcome.aborted = error.message; break; }
        if (error instanceof ChannelNotAllowed) { run.error = error.message; progress(error.message); continue; } // nothing changed: skip to the next channel
        run.error = `فشل تغيير التردد: ${error instanceof Error ? error.message : String(error)}`;
        // The write may or may not have been applied: check before deciding whether a rollback is needed.
        if ((await currentFrequency()) !== original) changedDevice = true;
        outcome.aborted = 'توقف الاختبار بعد فشل تغيير التردد؛ جارٍ التراجع إلى القناة الأصلية.';
        break;
      }
      progress(`انتظار عودة العلب على ${target} MHz…`);
      run.recovered = await waitForRecovery(target);
      if (!run.recovered) {
        run.error = `لم تعد كل العلب خلال المهلة على ${target} MHz.`;
        outcome.aborted = 'لم تعد العلب في المهلة؛ تم التراجع إلى القناة الأصلية بدل متابعة القنوات.';
        break;
      }
      if (settleMs > 0) { progress(`انتظار استقرار الرابط على ${target} MHz…`); await sleep(settleMs); }
      for (const unit of units) {
        if (options.shouldStop?.()) break;
        progress(`فحص ${unit.name} على ${target} MHz…`);
        const result: ChannelUnitResult = { unitKey: unit.key, unitName: unit.name, ok: false };
        try {
          if (unit.connection) { // optional extra reading when the phone can reach the unit directly
            try { result.reading = readingFrom(await unit.connection.readStatus()); } catch { /* the Speed Test below is what counts */ }
          }
          result.speed = await actions.runSpeedTest(main, unit.target);
          result.ok = true;
        } catch (error) {
          result.error = error instanceof Error ? error.message : String(error);
        }
        run.units.push(result);
        update();
      }
      options.onChannelDone?.(run);
      recoveredInPass += 1;
    }
    if (!outcome.aborted && recoveredInPass === 0) outcome.aborted = 'لم تنجح أي قناة في هذه الدورة؛ توقف التكرار.';
    } while (options.repeat && !outcome.aborted && !options.shouldStop?.());
  } finally {
    if (changedDevice) {
      outcome.untouched = false;
      outcome.restored = false;
      for (let attempt = 1; attempt <= 3 && !outcome.restored; attempt += 1) {
        progress(`إرجاع القناة الأصلية ${original} MHz (محاولة ${attempt}/3)…`);
        try {
          await actions.setFrequency(main, original);
          outcome.restored = await waitForRecovery(original);
        } catch (error) {
          outcome.restoreError = error instanceof Error ? error.message : String(error);
        }
      }
      if (!outcome.restored) {
        outcome.restoreError = `${outcome.restoreError ? `${outcome.restoreError} — ` : ''}لم يتأكد الرجوع إلى ${original} MHz. افتح العلبة الرئيسية يدويًا وأعد القناة فورًا.`;
      } else {
        outcome.restoreError = undefined;
      }
    }
  }
  if (outcome.untouched || outcome.restored) options.onSettledSafe?.();
  return outcome;
}

export function buildCampaignReport(outcome: CampaignOutcome): string {
  const lines: string[] = ['— نتائج الفحص عبر القنوات —'];
  lines.push(`القناة الأصلية: ${outcome.originalMHz ?? 'غير معروفة'} MHz`);
  if (outcome.aborted) lines.push(`ملاحظة: ${outcome.aborted}`);
  if (!outcome.untouched) lines.push(`إرجاع القناة الأصلية: ${outcome.restored ? 'تم وتحقق' : `لم يتأكد! ${outcome.restoreError ?? ''}`}`);
  lines.push('');
  for (const run of outcome.runs) {
    lines.push(`القناة ${run.frequencyMHz} MHz — عودة العلب: ${run.recovered ? 'نعم' : 'لا'}${run.error ? ` — ${run.error}` : ''}`);
    for (const unit of run.units) {
      if (!unit.ok) { lines.push(`  ${unit.unitName}: فشل — ${unit.error ?? ''}`); continue; }
      lines.push(`  ${unit.unitName}:`);
      unit.speed?.values.forEach((value) => lines.push(`    ${value.label}: ${value.value}`));
      if (unit.reading) lines.push(`    التردد المقروء: ${unit.reading.frequencyMHz ?? 'غير متاح'} MHz`);
    }
    lines.push('');
  }
  return lines.join('\n');
}
