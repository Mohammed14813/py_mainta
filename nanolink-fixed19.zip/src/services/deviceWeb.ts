// Drives the device's OWN web pages (Wireless, Speed Test) in a hidden WebView, so the page's JavaScript does what
// it does in a browser. The app only fills fields and clicks the same buttons a person would:
//   - channel: choose the frequency on the Wireless page and press «Change» (no Apply)
//   - Speed Test: destination IP, user, password, remote web port, then «Run Test»
import { Capacitor, registerPlugin } from '@capacitor/core';
import { parseMain } from './airosView';
import type { RealConnection } from './real';
import { ChannelNotAllowed, SpeedResult, SpeedTarget, SpeedTestError } from './speedTypes';

interface DeviceWebPlugin {
  open(options: { url: string; cookies: string[]; tlsPin?: string; timeoutMs?: number }): Promise<void>;
  eval(options: { script: string }): Promise<{ value: string }>;
  close(): Promise<void>;
}
const DeviceWeb = registerPlugin<DeviceWebPlugin>('DeviceWeb');

export const deviceWebAvailable = (): boolean => Capacitor.isPluginAvailable('DeviceWeb');
const sleep = (ms: number) => new Promise<void>((resolve) => setTimeout(resolve, ms));

/** `body` is a function body returning a JSON-serialisable value. */
async function evalJson<T>(body: string): Promise<T | null> {
  const { value } = await DeviceWeb.eval({ script: `(function(){try{return JSON.stringify((function(){${body}})());}catch(e){return JSON.stringify({__error:String(e&&e.message||e)});}})()` });
  if (!value || value === 'null') return null;
  const text = JSON.parse(value) as string; // evaluateJavascript hands back the returned string JSON-encoded
  return text ? (JSON.parse(text) as T) : null;
}
async function waitFor<T>(body: string, done: (value: T | null) => boolean, timeoutMs: number, everyMs = 1000): Promise<T | null> {
  const end = Date.now() + timeoutMs;
  let last: T | null = null;
  while (Date.now() < end) {
    try { last = await evalJson<T>(body); if (done(last)) return last; } catch { /* the page is navigating: try again */ }
    await sleep(everyMs);
  }
  return last;
}

async function ensureLoggedIn(path: string, session: ReturnType<RealConnection['webSession']>): Promise<void> {
  const state = await evalJson<{ login: boolean }>(`return {login: !!document.querySelector('form[action*="login.cgi"]') || /login\\.cgi/.test(location.pathname)};`);
  if (!state?.login) return;
  await evalJson(`var f=document.querySelector('form[action*="login.cgi"]')||document.forms[0];var u=f.querySelector('input[name=username]')||f.querySelector('input[type=text]');var p=f.querySelector('input[type=password]');u.value=${JSON.stringify(session.username)};p.value=${JSON.stringify(session.password)};setTimeout(function(){f.submit();},50);return 1;`);
  await sleep(4000);
  await evalJson(`setTimeout(function(){location.href=${JSON.stringify(path)};},50);return 1;`);
  await sleep(3000);
}

async function withPage<T>(conn: RealConnection, path: string, work: () => Promise<T>): Promise<T> {
  if (!deviceWebAvailable()) throw new Error('هذه الميزة تعمل داخل تطبيق أندرويد فقط.');
  await conn.readStatus(); // refreshes the session first, so the cookies handed to the WebView are valid
  const session = conn.webSession();
  await DeviceWeb.open({ url: `${session.baseUrl}${path}`, cookies: session.cookies, tlsPin: session.tlsPin || undefined, timeoutMs: 60_000 });
  try {
    await ensureLoggedIn(path, session);
    return await work();
  } finally { try { await DeviceWeb.close(); } catch { /* ignore */ } }
}

const mhzOf = (...texts: string[]): number | null => {
  for (const text of texts) { const m = /(?:^|\D)(2[3-9]\d\d|[3-6]\d{3}|7[01]\d\d)(?:\D|$)/.exec(text); if (m) return Number(m[1]); }
  return null;
};

/* ───────────── channel ───────────── */

interface ChannelPage { cur: string; opts: Array<{ v: string; t: string }>; }
const READY_CHANNEL = `var s=document.getElementById('chan_freq');return {n:s?s.options.length:-1,rs:document.readyState};`;
const READ_CHANNEL = `var s=document.getElementById('chan_freq');var o=s.options[s.selectedIndex];return {cur:o?(o.value+'|'+o.text):'',opts:Array.prototype.map.call(s.options,function(x){return {v:x.value,t:x.text};})};`;

async function loadChannelPage(): Promise<ChannelPage> {
  const ready = await waitFor<{ n: number; rs: string }>(READY_CHANNEL, (v) => !!v && v.n > 0 && v.rs === 'complete', 60_000);
  if (!ready || ready.n <= 0) throw new Error('صفحة Wireless لم تعرض قائمة القنوات في الوقت المحدد (الجهاز بطيء أو الجلسة غير مقبولة).');
  const page = await evalJson<ChannelPage>(READ_CHANNEL);
  if (!page) throw new Error('تعذرت قراءة قائمة القنوات من صفحة Wireless.');
  return page;
}

/** Frequencies the device itself offers on its Wireless page. */
export async function readChannelOptions(conn: RealConnection): Promise<number[]> {
  return withPage(conn, '/link.cgi', async () => {
    const page = await loadChannelPage();
    return [...new Set(page.opts.map((option) => mhzOf(option.v, option.t)).filter((v): v is number => v !== null))].sort((a, b) => a - b);
  });
}

/** Same as a person: pick the frequency on the Wireless page and press «Change». Throws ChannelNotAllowed if not offered. */
export async function setChannelViaPage(conn: RealConnection, mhz: number): Promise<void> {
  await withPage(conn, '/link.cgi', async () => {
    const page = await loadChannelPage();
    const options = page.opts.map((option) => ({ value: option.v, mhz: mhzOf(option.v, option.t) }));
    const real = parseMain((await conn.readStatus()).status).frequencyMHz.value;
    const shown = mhzOf(...page.cur.split('|'));
    if (shown !== real) throw new Error(`التردد الظاهر في صفحة Wireless (${shown ?? '—'}) لا يطابق التردد الحقيقي (${real ?? '—'}). لن يُغيَّر شيء.`);
    const target = options.find((option) => option.mhz === mhz);
    if (!target) throw new ChannelNotAllowed(`القناة ${mhz} MHz ليست في قائمة قنوات الجهاز.`);
    const set = await evalJson<{ ok: boolean; why?: string }>(`var s=document.getElementById('chan_freq');var v=${JSON.stringify(target.value)};s.value=v;if(s.value!==v)return {ok:false,why:'value'};s.dispatchEvent(new Event('change',{bubbles:true}));if(window.jQuery){window.jQuery(s).trigger('change');}var f=s.form;var b=f&&(f.querySelector('input[type=submit]')||f.querySelector('button[type=submit]'));if(!b)return {ok:false,why:'submit'};window.__nl=1;setTimeout(function(){b.click();},300);return {ok:true};`);
    if (!set?.ok) throw new Error(`تعذر ضبط القناة في صفحة Wireless (${set?.why ?? 'غير معروف'}).`);
    const reloaded = await waitFor<{ gone: boolean; rs: string }>(`return {gone:typeof window.__nl==='undefined',rs:document.readyState};`, (v) => !!v && v.gone && v.rs === 'complete', 60_000, 1500);
    if (!reloaded?.gone) throw new Error('لم يتأكد إرسال نموذج Wireless (لم تُعد الصفحة تحميل نفسها).');
  });
}

/* ───────────── speed test ───────────── */

const num = (text?: string | null) => (text ? text.replace(',', '') : null);

/** Runs the main node's «Network Speed Test» toward a unit and returns exactly what the tool displays. */
export async function runSpeedViaPage(conn: RealConnection, target: SpeedTarget, timeoutMs = 150_000): Promise<SpeedResult> {
  return withPage(conn, '/sptest.cgi', async () => {
    const ready = await waitFor<{ ok: boolean }>(`return {ok:!!document.getElementById('runtest')&&!!document.getElementById('dst_addr_input')&&document.readyState==='complete'};`, (v) => !!v?.ok, 60_000);
    if (!ready?.ok) throw new SpeedTestError('other', 'صفحة Speed Test لم تُحمَّل في الوقت المحدد.');
    const filled = await evalJson<{ ok: boolean }>(`function setv(id,v){var e=document.getElementById(id);if(!e)return false;e.removeAttribute('disabled');e.value=v;e.dispatchEvent(new Event('input',{bubbles:true}));e.dispatchEvent(new Event('change',{bubbles:true}));return true;}var sel=document.getElementById('dst_addr_select');if(sel){var man=Array.prototype.filter.call(sel.options,function(o){return /manual/i.test(o.text)||/manual/i.test(o.value);})[0];if(man&&sel.value!==man.value){sel.value=man.value;sel.dispatchEvent(new Event('change',{bubbles:true}));if(window.jQuery)window.jQuery(sel).trigger('change');}}var ok=setv('dst_addr_input',${JSON.stringify(target.ip)})&&setv('auth_user',${JSON.stringify(target.username)})&&setv('auth_password',${JSON.stringify(target.password)})&&setv('launcher_port',${JSON.stringify(target.port)});return {ok:ok};`);
    if (!filled?.ok) throw new SpeedTestError('other', 'تعذر تعبئة حقول أداة Speed Test.');
    await evalJson(`setTimeout(function(){document.getElementById('runtest').click();},300);return 1;`);

    const started = Date.now();
    let previous = '';
    let stable = 0;
    while (Date.now() - started < timeoutMs) {
      await sleep(2000);
      let state: { t: string; dis: boolean } | null = null;
      try { state = await evalJson<{ t: string; dis: boolean }>(`var b=document.getElementById('runtest');return {t:document.body?document.body.innerText.slice(0,3000):'',dis:!!(b&&b.disabled)};`); } catch { continue; }
      if (!state) continue;
      const error = /Error:?\s*([^\n]+)/i.exec(state.t);
      if (error) {
        const message = error[1].trim();
        if (/credentials?|invalid|password|login/i.test(message)) throw new SpeedTestError('credentials', 'اليوزر أو الباسورد خطأ (رفضتهما الأداة).');
        if (/unreach|time ?out|connect|route|refused/i.test(message)) throw new SpeedTestError('unreachable', `تعذر الوصول إلى العلبة: ${message}`);
        throw new SpeedTestError('other', `خطأ من الأداة: ${message}`);
      }
      const rx = /RX:\s*([\d.,]+)\s*([A-Za-z]+)/i.exec(state.t);
      const tx = /TX:\s*([\d.,]+)\s*([A-Za-z]+)/i.exec(state.t);
      const total = /Total:\s*([\d.,]+)\s*([A-Za-z]+)/i.exec(state.t);
      if (rx && tx && total) {
        const key = `${rx[1]}|${tx[1]}|${total[1]}`;
        stable = key === previous ? stable + 1 : 0;
        previous = key;
        if (stable >= 2 && (!state.dis || stable >= 4) && Date.now() - started > 6000) {
          return { values: [
            { label: 'RX', value: `${num(rx[1])} ${rx[2]}` },
            { label: 'TX', value: `${num(tx[1])} ${tx[2]}` },
            { label: 'Total', value: `${num(total[1])} ${total[2]}` },
          ] };
        }
      }
    }
    throw new SpeedTestError('other', 'انتهت مهلة الأداة دون نتيجة.');
  });
}

/** Password check through the tool: numbers back = the unit accepted the login; "credentials invalid" = wrong password. */
export async function verifyViaTool(conn: RealConnection, target: SpeedTarget): Promise<{ auth: 'ok' | 'bad' | 'error'; message: string; speed?: SpeedResult; port: string }> {
  const ports = [...new Set([target.port || '80', '80', '443'])];
  let last = 'تعذر الفحص.';
  for (const port of ports) {
    try {
      const speed = await runSpeedViaPage(conn, { ...target, port });
      return { auth: 'ok', message: `نجح اختبار الأداة على المنفذ ${port} (اليوزر والباسورد مقبولان).`, speed, port };
    } catch (error) {
      if (error instanceof SpeedTestError) {
        if (error.kind === 'credentials') return { auth: 'bad', message: error.message, port };
        last = error.message;
        continue; // unreachable/other: try the other web port
      }
      return { auth: 'error', message: error instanceof Error ? error.message : String(error), port };
    }
  }
  return { auth: 'error', message: last, port: target.port };
}
