package com.nanolink.channelanalyzer;

import android.os.Bundle;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(AirOsHttpPlugin.class);
        registerPlugin(DeviceWebPlugin.class);
        super.onCreate(savedInstanceState);
    }
}
