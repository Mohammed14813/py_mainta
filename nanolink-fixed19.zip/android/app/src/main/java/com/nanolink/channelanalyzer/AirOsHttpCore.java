package com.nanolink.channelanalyzer;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.URL;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

/**
 * Network core for talking to a Ubiquiti airOS device on the local network.
 *
 * Deliberately free of Capacitor / org.json types so it can be unit-tested on a plain JVM.
 *
 * TLS model: the device presents a self-signed certificate, so normal CA validation cannot work.
 * Instead of disabling verification, every HTTPS request is bound to ONE exact leaf certificate
 * (SHA-256 fingerprint) that the user approved. The TLS handshake only completes if the server
 * presents that exact certificate (and therefore holds its private key). Nothing else is trusted,
 * and the relaxed SSLSocketFactory is installed on the single connection, never process-wide.
 */
final class AirOsHttpCore {
    static final int CONNECT_TIMEOUT_MS = 7000;
    static final int READ_TIMEOUT_MS = 10000;
    static final int MAX_BODY_BYTES = 2 * 1024 * 1024;
    static final int MAX_REQUEST_BYTES = 64 * 1024;

    private static final Pattern HEADER_NAME = Pattern.compile("[!#$%&'*+.^_`|~0-9A-Za-z-]+");
    private static final Pattern CHARSET = Pattern.compile("charset=\"?([^;\\s\"]+)", Pattern.CASE_INSENSITIVE);
    private static final Pattern HEX64 = Pattern.compile("[0-9A-F]{64}");
    /** Set by the connection layer itself; a caller must not override them. */
    private static final Set<String> RESERVED_HEADERS = new HashSet<>(Arrays.asList("host", "content-length", "connection", "transfer-encoding"));

    /** Hostname is a private IPv4 literal; identity is established by the certificate pin, not by name. */
    private static final HostnameVerifier PINNED_ONLY = new HostnameVerifier() {
        @Override public boolean verify(String hostname, SSLSession session) { return true; }
    };

    static final class Response {
        int status;
        final Map<String, String> headers = new LinkedHashMap<>();
        /** One entry per Set-Cookie header. Never merged: Expires dates contain commas. */
        final List<String> setCookies = new ArrayList<>();
        String body = "";
    }

    private AirOsHttpCore() {}

    /* ───────────── request ───────────── */

    static Response execute(String urlText, String method, Map<String, String> headers, String data, String tlsPin) throws Exception {
        return execute(urlText, method, headers, data, tlsPin, CONNECT_TIMEOUT_MS, READ_TIMEOUT_MS);
    }

    static Response execute(String urlText, String method, Map<String, String> headers, String data, String tlsPin, int connectMs, int readMs) throws Exception {
        URL url = new URL(urlText);
        requirePrivateLan(url);
        return executeUnchecked(url, method, headers, data, tlsPin, connectMs, readMs);
    }

    /** Same as {@link #execute} without the LAN-address rule; package-private so tests can use 127.0.0.1. */
    static Response executeUnchecked(URL url, String methodName, Map<String, String> headers, String data, String tlsPin) throws Exception {
        return executeUnchecked(url, methodName, headers, data, tlsPin, CONNECT_TIMEOUT_MS, READ_TIMEOUT_MS);
    }

    static Response executeUnchecked(URL url, String methodName, Map<String, String> headers, String data, String tlsPin, int connectMs, int readMs) throws Exception {
        String method = methodName == null ? "GET" : methodName.toUpperCase(Locale.ROOT);
        if (!method.equals("GET") && !method.equals("POST")) throw new IllegalArgumentException("Only GET and POST requests are permitted.");
        HttpURLConnection connection;
        if ("https".equalsIgnoreCase(url.getProtocol())) {
            if (tlsPin == null || tlsPin.isEmpty()) throw new CertificateException("The HTTPS certificate has not been approved for this session.");
            HttpsURLConnection https = (HttpsURLConnection) url.openConnection();
            https.setSSLSocketFactory(pinnedContext(tlsPin).getSocketFactory());
            https.setHostnameVerifier(PINNED_ONLY);
            connection = https;
        } else if ("http".equalsIgnoreCase(url.getProtocol())) {
            connection = (HttpURLConnection) url.openConnection();
        } else {
            throw new IllegalArgumentException("Only HTTP and HTTPS are supported.");
        }
        try {
            connection.setConnectTimeout(connectMs);
            connection.setReadTimeout(readMs);
            // The device itself may answer 304; the app never sends validators, and nothing may be cached.
            connection.setUseCaches(false);
            connection.setDefaultUseCaches(false);
            connection.setInstanceFollowRedirects(false);
            connection.setRequestMethod(method);
            if (headers != null) {
                for (Map.Entry<String, String> header : headers.entrySet()) {
                    String name = header.getKey();
                    String value = header.getValue() == null ? "" : header.getValue();
                    if (name == null || !HEADER_NAME.matcher(name).matches()) throw new IllegalArgumentException("Invalid header name.");
                    if (value.indexOf('\r') >= 0 || value.indexOf('\n') >= 0) throw new IllegalArgumentException("Invalid header value for " + name + ".");
                    if (RESERVED_HEADERS.contains(name.toLowerCase(Locale.ROOT))) continue;
                    connection.setRequestProperty(name, value);
                }
            }
            if ("POST".equals(method) && data != null) {
                byte[] bytes = data.getBytes(StandardCharsets.UTF_8);
                if (bytes.length > MAX_REQUEST_BYTES) throw new IllegalArgumentException("Request body is too large.");
                connection.setDoOutput(true);
                try (OutputStream output = connection.getOutputStream()) {
                    output.write(bytes);
                }
            }
            Response response = new Response();
            try {
                response.status = connection.getResponseCode();
            } catch (IOException error) {
                // Android's HttpURLConnection throws on a 401 that carries no WWW-Authenticate header.
                String message = error.getMessage();
                if (message != null && message.toLowerCase(Locale.ROOT).contains("authentication challenge")) {
                    response.status = 401;
                    return response;
                }
                throw error;
            }
            readHeaders(connection, response);
            response.body = readBody(connection, response.status);
            return response;
        } finally {
            connection.disconnect();
        }
    }

    private static void readHeaders(HttpURLConnection connection, Response response) {
        for (int index = 1; ; index++) {
            String key = connection.getHeaderFieldKey(index);
            String value = connection.getHeaderField(index);
            if (key == null && value == null) break;
            if (key == null || value == null) continue;
            String existing = response.headers.get(key);
            response.headers.put(key, existing == null ? value : existing + ", " + value);
        }
        for (Map.Entry<String, List<String>> field : connection.getHeaderFields().entrySet()) {
            if (field.getKey() != null && field.getKey().equalsIgnoreCase("Set-Cookie") && field.getValue() != null) {
                response.setCookies.addAll(field.getValue());
            }
        }
    }

    private static String readBody(HttpURLConnection connection, int status) throws IOException {
        if (status == 304 || status == 204) return "";
        InputStream stream = status >= 400 ? connection.getErrorStream() : connection.getInputStream();
        if (stream == null) return "";
        try {
            ByteArrayOutputStream output = new ByteArrayOutputStream();
            byte[] buffer = new byte[4096];
            int read;
            while ((read = stream.read(buffer)) != -1) {
                if (output.size() + read > MAX_BODY_BYTES) throw new IOException("The device response is larger than " + MAX_BODY_BYTES + " bytes.");
                output.write(buffer, 0, read);
            }
            return new String(output.toByteArray(), charsetOf(connection.getContentType()));
        } finally {
            stream.close();
        }
    }

    private static Charset charsetOf(String contentType) {
        if (contentType != null) {
            Matcher matcher = CHARSET.matcher(contentType);
            if (matcher.find()) {
                try { return Charset.forName(matcher.group(1)); } catch (Exception ignored) { /* fall through to UTF-8 */ }
            }
        }
        return StandardCharsets.UTF_8;
    }

    /* ───────────── TLS ───────────── */

    /**
     * Performs a TLS handshake ONLY and returns the server's leaf certificate. No HTTP request is
     * sent, so no data of any kind leaves the app toward a server that has not been approved yet.
     */
    static X509Certificate fetchLeafCertificate(String host, int port) throws Exception {
        return fetchLeafCertificate(host, port, CONNECT_TIMEOUT_MS, READ_TIMEOUT_MS);
    }

    static X509Certificate fetchLeafCertificate(String host, int port, int connectMs, int readMs) throws Exception {
        final X509Certificate[][] captured = new X509Certificate[1][];
        X509TrustManager capture = new X509TrustManager() {
            @Override public void checkClientTrusted(X509Certificate[] chain, String authType) {}
            @Override public void checkServerTrusted(X509Certificate[] chain, String authType) {
                if (chain != null && chain.length > 0) captured[0] = chain; // read-only: the user decides afterwards
            }
            @Override public X509Certificate[] getAcceptedIssuers() { return new X509Certificate[0]; }
        };
        SSLContext context = SSLContext.getInstance("TLS");
        context.init(null, new TrustManager[] { capture }, new SecureRandom());
        SSLSocket socket = (SSLSocket) context.getSocketFactory().createSocket();
        try {
            socket.connect(new InetSocketAddress(host, port), connectMs);
            socket.setSoTimeout(readMs);
            socket.startHandshake();
        } finally {
            try { socket.close(); } catch (IOException ignored) { /* nothing to recover */ }
        }
        if (captured[0] == null) throw new CertificateException("The device did not present an X.509 certificate.");
        return captured[0][0];
    }

    /** An SSLContext that accepts exactly one leaf certificate, identified by its SHA-256 fingerprint. */
    static SSLContext pinnedContext(String fingerprint) throws Exception {
        final String expected = normalizeFingerprint(fingerprint);
        X509TrustManager pinned = new X509TrustManager() {
            @Override public void checkClientTrusted(X509Certificate[] chain, String authType) throws CertificateException {
                throw new CertificateException("Client certificates are not used.");
            }
            @Override public void checkServerTrusted(X509Certificate[] chain, String authType) throws CertificateException {
                if (chain == null || chain.length == 0) throw new CertificateException("No device certificate was presented.");
                String actual;
                try {
                    actual = sha256Fingerprint(chain[0]);
                } catch (Exception error) {
                    throw new CertificateException("Could not verify the device certificate.", error);
                }
                // Self-signed airOS certificates are often expired or issued before the device clock was set,
                // so validity dates are intentionally not part of the decision; the exact pin is.
                if (!MessageDigest.isEqual(expected.getBytes(StandardCharsets.US_ASCII), actual.getBytes(StandardCharsets.US_ASCII))) {
                    throw new CertificateException("The device certificate changed after approval. Review it again before logging in.");
                }
            }
            @Override public X509Certificate[] getAcceptedIssuers() { return new X509Certificate[0]; }
        };
        SSLContext context = SSLContext.getInstance("TLS");
        context.init(null, new TrustManager[] { pinned }, new SecureRandom());
        return context;
    }

    static String normalizeFingerprint(String fingerprint) {
        String normalized = fingerprint == null ? "" : fingerprint.replace(":", "").replaceAll("\\s", "").toUpperCase(Locale.ROOT);
        if (!HEX64.matcher(normalized).matches()) throw new IllegalArgumentException("The certificate fingerprint must be 64 hexadecimal characters (SHA-256).");
        return normalized;
    }

    static String sha256Fingerprint(X509Certificate certificate) throws Exception {
        byte[] digest = MessageDigest.getInstance("SHA-256").digest(certificate.getEncoded());
        StringBuilder output = new StringBuilder();
        for (byte value : digest) output.append(String.format(Locale.ROOT, "%02X", value & 0xff));
        return output.toString();
    }

    /* ───────────── address rules ───────────── */

    static void requirePrivateLanHttps(URL url) {
        if (!"https".equalsIgnoreCase(url.getProtocol())) throw new IllegalArgumentException("Certificate inspection requires HTTPS.");
        requirePrivateLan(url);
    }

    static void requirePrivateLan(URL url) {
        if (!"http".equalsIgnoreCase(url.getProtocol()) && !"https".equalsIgnoreCase(url.getProtocol())) throw new IllegalArgumentException("Unsupported protocol.");
        if (url.getUserInfo() != null) throw new IllegalArgumentException("Credentials in the URL are not allowed.");
        String host = url.getHost();
        if (host == null || !host.matches("[0-9]{1,3}(\\.[0-9]{1,3}){3}")) throw new IllegalArgumentException("Enter a private IPv4 address.");
        String[] octets = host.split("\\.");
        int a = Integer.parseInt(octets[0]);
        int b = Integer.parseInt(octets[1]);
        int c = Integer.parseInt(octets[2]);
        int d = Integer.parseInt(octets[3]);
        if (a > 255 || b > 255 || c > 255 || d > 255) throw new IllegalArgumentException("Invalid IPv4 address.");
        boolean privateAddress = a == 10 || (a == 192 && b == 168) || (a == 172 && b >= 16 && b <= 31) || (a == 169 && b == 254);
        if (!privateAddress) throw new IllegalArgumentException("Only private LAN addresses are allowed.");
    }

    static String safeMessage(Exception error) {
        String message = error.getMessage();
        return message == null || message.isEmpty() ? error.getClass().getSimpleName() : error.getClass().getSimpleName() + ": " + message;
    }
}
