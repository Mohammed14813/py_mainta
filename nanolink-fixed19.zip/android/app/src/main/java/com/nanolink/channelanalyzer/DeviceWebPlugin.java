package com.nanolink.channelanalyzer;

import android.net.Uri;
import android.net.http.SslCertificate;
import android.net.http.SslError;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.JsPromptResult;
import android.webkit.JsResult;
import android.webkit.SslErrorHandler;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import java.net.URL;
import java.security.MessageDigest;

/**
 * Runs the device's OWN web pages in a hidden WebView so that the page's JavaScript does exactly what it does in a
 * browser (change channel with the Wireless form's "Change" button, run the Speed Test tool). The app only fills
 * fields and clicks, through {@code eval}. Restrictions: private LAN addresses only, navigation limited to the same
 * host and port, HTTPS only when the certificate matches the pin the user approved, JS dialogs are auto-accepted.
 */
@CapacitorPlugin(name = "DeviceWeb")
public class DeviceWebPlugin extends Plugin {

    private WebView web;
    private String pin = "";
    private String allowedHost = "";
    private int allowedPort = -1;
    private PluginCall pendingOpen;
    private Runnable loadTimeout;
    private final Handler handler = new Handler(Looper.getMainLooper());

    @PluginMethod
    public void open(final PluginCall call) {
        final String urlText = call.getString("url", "");
        final String tlsPin = call.getString("tlsPin", "");
        final JSArray cookies = call.getArray("cookies", new JSArray());
        final int timeoutMs = call.getInt("timeoutMs", 40000);
        final URL url;
        try {
            url = new URL(urlText);
            AirOsHttpCore.requirePrivateLan(url);
        } catch (Exception error) {
            call.reject(AirOsHttpCore.safeMessage(error));
            return;
        }
        if ("https".equalsIgnoreCase(url.getProtocol()) && (tlsPin == null || tlsPin.isEmpty())) {
            call.reject("HTTPS needs an approved certificate pin.");
            return;
        }
        getActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    destroyWeb();
                    pin = tlsPin == null ? "" : AirOsHttpCore.normalizeFingerprint(tlsPin);
                    allowedHost = url.getHost();
                    allowedPort = url.getPort() == -1 ? url.getDefaultPort() : url.getPort();
                    pendingOpen = call;
                    CookieManager manager = CookieManager.getInstance();
                    manager.setAcceptCookie(true);
                    String origin = url.getProtocol() + "://" + url.getHost() + (url.getPort() == -1 ? "" : ":" + url.getPort()) + "/";
                    for (int i = 0; i < cookies.length(); i += 1) {
                        String cookie = cookies.optString(i, "");
                        if (!cookie.isEmpty()) manager.setCookie(origin, cookie);
                    }
                    manager.flush();

                    web = new WebView(getContext());
                    WebSettings settings = web.getSettings();
                    settings.setJavaScriptEnabled(true);
                    settings.setDomStorageEnabled(true);
                    settings.setAllowFileAccess(false);
                    settings.setAllowContentAccess(false);
                    settings.setCacheMode(WebSettings.LOAD_NO_CACHE);
                    web.setAlpha(0.01f);
                    web.setWebChromeClient(new AutoAcceptChrome());
                    web.setWebViewClient(new GuardedClient());
                    getActivity().addContentView(web, new ViewGroup.LayoutParams(2, 2));
                    loadTimeout = new Runnable() {
                        @Override
                        public void run() { finishOpen(false, "Page load timed out."); }
                    };
                    handler.postDelayed(loadTimeout, timeoutMs);
                    web.loadUrl(urlText);
                } catch (Exception error) {
                    pendingOpen = null;
                    call.reject(AirOsHttpCore.safeMessage(error));
                }
            }
        });
    }

    @PluginMethod
    public void eval(final PluginCall call) {
        final String script = call.getString("script", "");
        getActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (web == null) {
                    call.reject("No page is open.");
                    return;
                }
                web.evaluateJavascript(script, new android.webkit.ValueCallback<String>() {
                    @Override
                    public void onReceiveValue(String value) {
                        JSObject result = new JSObject();
                        result.put("value", value == null ? "null" : value);
                        call.resolve(result);
                    }
                });
            }
        });
    }

    @PluginMethod
    public void close(final PluginCall call) {
        getActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                destroyWeb();
                call.resolve();
            }
        });
    }

    @Override
    protected void handleOnDestroy() {
        destroyWeb();
        super.handleOnDestroy();
    }

    /* ───────────── internals (UI thread) ───────────── */

    private void finishOpen(boolean ok, String message) {
        if (loadTimeout != null) handler.removeCallbacks(loadTimeout);
        loadTimeout = null;
        PluginCall call = pendingOpen;
        pendingOpen = null;
        if (call == null) return;
        if (ok) call.resolve();
        else call.reject(message);
    }

    private void destroyWeb() {
        if (loadTimeout != null) handler.removeCallbacks(loadTimeout);
        loadTimeout = null;
        pendingOpen = null;
        if (web != null) {
            try {
                web.stopLoading();
                View parent = (View) web.getParent();
                if (parent instanceof ViewGroup) ((ViewGroup) parent).removeView(web);
                web.destroy();
            } catch (Exception ignored) {
                // best effort
            }
            web = null;
        }
        try {
            CookieManager.getInstance().removeAllCookies(null);
            CookieManager.getInstance().flush();
        } catch (Exception ignored) {
            // best effort
        }
    }

    private boolean sameOrigin(Uri uri) {
        if (uri == null || uri.getHost() == null) return false;
        int port = uri.getPort() == -1 ? ("https".equalsIgnoreCase(uri.getScheme()) ? 443 : 80) : uri.getPort();
        return uri.getHost().equals(allowedHost) && port == allowedPort;
    }

    private final class GuardedClient extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
            return !sameOrigin(request.getUrl()); // true = block navigation away from the device
        }

        @Override
        public void onPageFinished(WebView view, String url) {
            if (pendingOpen != null) finishOpen(true, "");
        }

        @Override
        public void onReceivedSslError(WebView view, SslErrorHandler sslHandler, SslError error) {
            try {
                if (!pin.isEmpty()) {
                    Bundle state = SslCertificate.saveState(error.getCertificate());
                    byte[] der = state.getByteArray("x509-certificate");
                    if (der != null) {
                        byte[] digest = MessageDigest.getInstance("SHA-256").digest(der);
                        StringBuilder hex = new StringBuilder();
                        for (byte b : digest) hex.append(String.format("%02X", b));
                        if (hex.toString().equals(pin)) {
                            sslHandler.proceed();
                            return;
                        }
                    }
                }
            } catch (Exception ignored) {
                // fall through to cancel
            }
            sslHandler.cancel();
            if (pendingOpen != null) finishOpen(false, "Certificate does not match the approved pin.");
        }
    }

    private static final class AutoAcceptChrome extends WebChromeClient {
        @Override
        public boolean onJsAlert(WebView view, String url, String message, JsResult result) {
            result.confirm();
            return true;
        }

        @Override
        public boolean onJsConfirm(WebView view, String url, String message, JsResult result) {
            result.confirm();
            return true;
        }

        @Override
        public boolean onJsPrompt(WebView view, String url, String message, String defaultValue, JsPromptResult result) {
            result.confirm(defaultValue == null ? "" : defaultValue);
            return true;
        }

        @Override
        public boolean onJsBeforeUnload(WebView view, String url, String message, JsResult result) {
            result.confirm();
            return true;
        }
    }
}
